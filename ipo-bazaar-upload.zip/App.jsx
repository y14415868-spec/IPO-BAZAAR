import React, { useMemo, useState, useRef, useEffect } from "react";
import {
  Home as HomeIcon,
  BarChart2,
  ClipboardList,
  Moon,
  TrendingUp,
  Search,
  Bell,
  Inbox,
  ClipboardCheck,
  Banknote,
  Package,
  Heart,
  ArrowRight,
  ArrowLeft,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Share2,
  PieChart,
  IndianRupee,
  Landmark,
  Globe,
  FileText,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  BookOpen,
  ExternalLink,
  Info,
  X,
  User,
  MessageSquare,
  Lock,
  HelpCircle,
  Users,
  Star,
  Check,
  Shield,
  Eye,
  EyeOff,
  Pencil,
  LogOut,
  Camera,
  Image as ImageIcon,
  Trash2,
} from "lucide-react";

/* ---------------------------------------------------------------
   THEME TOKENS
   Two-color system: blue + white/black. Light and dark variants
   share the same blue so the brand reads identically in both modes.
----------------------------------------------------------------*/
const themes = {
  light: {
    bg: "#FFFFFF",
    surface: "#F6F8FC",
    nav: "#FFFFFF",
    navBorder: "#E7ECF3",
    textPrimary: "#0E1420",
    textSecondary: "#7C8494",
    border: "#E7ECF3",
    blue: "#175CFF",
    blueSoft: "rgba(23, 92, 255, 0.10)",
    iconMuted: "#AAB2C0",
    headBlue: "#0B3B8C",
  },
  dark: {
    bg: "#07090D",
    surface: "#0F131A",
    nav: "#0B0E14",
    navBorder: "#1B212C",
    textPrimary: "#F5F7FA",
    textSecondary: "#8891A0",
    border: "#1B212C",
    blue: "#4C86FF",
    blueSoft: "rgba(76, 134, 255, 0.16)",
    iconMuted: "#4B5262",
    headBlue: "#6FA1FF",
  },
};

const TABS = [
  { key: "home", label: "Home", icon: HomeIcon },
  { key: "subscription", label: "Subscription", icon: BarChart2 },
  { key: "allotment", label: "Allotment", icon: ClipboardList },
  { key: "calendar", label: "Calendar", icon: Calendar },
  { key: "settings", label: "User", icon: User },
];

/* ---------------------------------------------------------------
   IPO ACCENT COLORS
   Fixed semantic accents that stay the same in both light and
   dark mode — green for GMP/UPCOMING, blue for the primary action
   and OPEN, red for CLOSED, negative GMP, and a saved wishlist.
   Everything else (card background, borders, text) now follows
   the app's light/dark theme via the `t` prop.
----------------------------------------------------------------*/
const cardColors = {
  blue: "#2E7CFF",
  blueSoft: "rgba(46, 124, 255, 0.14)",
  green: "#22CE83",
  greenSoft: "rgba(34, 206, 131, 0.14)",
  red: "#EF4444",
  redSoft: "rgba(239, 68, 68, 0.14)",
  yellow: "#D4A017",
  yellowSoft: "rgba(212, 160, 23, 0.14)",
  neutral: "#8B96AC",
  neutralSoft: "rgba(139, 150, 172, 0.14)",
  orange: "#F97316",
  orangeSoft: "rgba(249, 115, 22, 0.14)",
  purple: "#8B5CF6",
  purpleSoft: "rgba(139, 92, 246, 0.14)",
  pink: "#EC4899",
  pinkSoft: "rgba(236, 72, 153, 0.14)",
  lightPink: "#F9A8D4",
  lightPinkSoft: "rgba(249, 168, 212, 0.2)",
};

const STATUS_META = {
  upcoming: { label: "UPCOMING", bg: cardColors.yellowSoft, fg: cardColors.yellow },
  open: { label: "OPEN", bg: cardColors.greenSoft, fg: cardColors.green },
  closed: { label: "CLOSED", bg: cardColors.redSoft, fg: cardColors.red },
};

/* Subscription screen uses its own status pill colors:
   green for Open/Live, red for Closed, blue for Listed. */
const SUB_STATUS_META = {
  open: { label: "Live", bg: cardColors.greenSoft, fg: cardColors.green },
  closed: { label: "Closed", bg: cardColors.redSoft, fg: cardColors.red },
  listed: { label: "Listed", bg: cardColors.blueSoft, fg: cardColors.blue },
};

/* Green for a positive subscription change, red for negative. */
function subTone(percentage) {
  return String(percentage).trim().startsWith("-")
    ? cardColors.red
    : cardColors.green;
}

/* ---------------------------------------------------------------
   IPO DATA
   Single source of truth — filtered by status, never duplicated
   into separate screens. Ready to be swapped for a Firebase
   collection later without touching the UI below.
----------------------------------------------------------------*/
const IPO_DATA = [];

const STATUS_TABS = [
  { key: "upcoming", label: "Upcoming" },
  { key: "open", label: "Open" },
  { key: "closed", label: "Closed" },
];

/* ---------------------------------------------------------------
   IPO DETAIL DATA
   Extra fields for the IPO Detail screen, keyed by the same id
   used in IPO_DATA. A missing field/section here means that
   section is hidden for that IPO — nothing is ever faked.
----------------------------------------------------------------*/
const IPO_DETAILS = {};

const LEARN_TOPICS = [
  {
    key: "what-is-ipo",
    question: "What is this IPO?",
    answer:
      "An IPO (Initial Public Offering) is the process through which a private company offers its shares to the public for the first time. Investors can apply for shares during the IPO, and after the issue, the shares are listed on a stock exchange.",
  },
  {
    key: "what-company-does",
    question: "What does the company do?",
    answer:
      "The company operates in its respective business sector and provides its products or services to customers. Investors should understand the company's business model, products, customers and industry before investing.",
  },
  {
    key: "why-ipo",
    question: "Why is the company launching this IPO?",
    answer:
      "A company may launch an IPO to raise funds for purposes such as business expansion, debt repayment, working capital, acquisitions or general corporate needs. The exact use of funds depends on the company's IPO documents.",
  },
  {
    key: "fund-use",
    question: "How will the IPO funds be used?",
    answer:
      "The funds raised through an IPO may be used for purposes such as debt repayment, expansion of existing operations, setting up new facilities, working capital and general corporate purposes. The specific allocation is mentioned in the company's IPO documents.",
  },
  {
    key: "key-risks",
    question: "What are the key risks of this IPO?",
    answer:
      "Every IPO carries risks. These may include business and industry risks, competition, financial performance, debt, dependence on key customers or suppliers, regulatory changes and the possibility that the share price may fall after listing. Investors should review the company's IPO documents before investing.",
  },
];

const DEFAULT_IPO_DISCLAIMER =
  "IPO Bazaar provides information for educational and informational purposes only. This information should not be considered investment advice. Investors should review official IPO documents and conduct their own research before investing.";

/* ---------------------------------------------------------------
   SUBSCRIPTION DATA
   Single source of truth for the Subscription screen — filtered
   by status (open/listed). Ready to be swapped for a Firebase
   collection later without touching the UI below.
----------------------------------------------------------------*/
const SUBSCRIPTION_DATA = [];

const SUB_TABS = [
  { key: "open", label: "Live" },
  { key: "closed", label: "Closed" },
  { key: "listed", label: "Listed" },
];

const SUB_DAYS = ["Day 1", "Day 2", "Day 3"];

/* ---------------------------------------------------------------
   ALLOTMENT DATA
   Single source of truth for the Allotment screen — filtered by
   status (upcoming/available). Registrar URLs are IPO-specific;
   IPO Bazaar never collects PAN or application numbers itself.
----------------------------------------------------------------*/
const ALLOTMENT_DATA = [];

const ALLOT_TABS = [
  { key: "upcoming", label: "Upcoming" },
  { key: "available", label: "Allotment Available" },
];

const ALLOTMENT_STEPS = [
  "Select the IPO from the Allotment Available list",
  "Tap on Check Allotment",
  "You'll be redirected to the official registrar website",
  "Enter your PAN or Application number to check the status",
  "After checking, come back to IPO Bazaar and update your status (Allotted / Not Allotted / Skipped)",
];

const ALLOTMENT_STATUS_OPTIONS = [
  {
    key: "allotted",
    label: "Allotted",
    desc: "I have been allotted shares",
    color: cardColors.green,
    soft: cardColors.greenSoft,
  },
  {
    key: "not_allotted",
    label: "Not Allotted",
    desc: "I have not been allotted shares",
    color: cardColors.red,
    soft: cardColors.redSoft,
  },
  {
    key: "skipped",
    label: "Skipped",
    desc: "I did not apply or want to skip tracking",
    color: cardColors.neutral,
    soft: cardColors.neutralSoft,
  },
];

const ALLOTMENT_FEEDBACK = {
  allotted: "🎉 Congratulations! You've been allotted shares.",
  not_allotted: "Better luck next time — more IPOs are on the way!",
  skipped: "Got it, we've saved your choice to skip tracking.",
};

/* ---------------------------------------------------------------
   NOTIFICATIONS
   Sample notification feed for the bell icon. Ready to be swapped
   for a real push/notification backend later.
----------------------------------------------------------------*/
const NOTIFICATIONS = [];

/* ---------------------------------------------------------------
   CALENDAR DATA
   Event types, sample events, and small date helpers for the
   Calendar screen. Ready to be swapped for Admin Panel data later.
----------------------------------------------------------------*/
const EVENT_TYPE_META = {
  open: { label: "IPO Opens", color: cardColors.green, soft: cardColors.greenSoft },
  close: { label: "IPO Closes", color: cardColors.orange, soft: cardColors.orangeSoft },
  allotment: { label: "Allotment", color: cardColors.blue, soft: cardColors.blueSoft },
  refund: { label: "Refund", color: cardColors.purple, soft: cardColors.purpleSoft },
  demat: { label: "Demat Credit", color: cardColors.neutral, soft: cardColors.neutralSoft },
  listing: { label: "Listing", color: cardColors.pink, soft: cardColors.pinkSoft },
  custom: { label: "Important Date", color: cardColors.yellow, soft: cardColors.yellowSoft },
  holiday: { label: "Market Holiday", color: cardColors.lightPink, soft: cardColors.lightPinkSoft },
};

/* ---------------------------------------------------------------
   CALENDAR EVENTS — derived, not stored.
   The Calendar has no events of its own. Every event shown here is
   computed on demand from IPO_DATA + IPO_DETAILS — the exact same
   records the Admin Panel edits. Add/change/remove a date on an IPO
   (or an admin-added customDates entry) and the next call to
   buildCalendarEvents() reflects it automatically — nothing here
   needs to be kept in sync by hand.
----------------------------------------------------------------*/
const MONTH_INDEX = {
  jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6,
  aug: 7, sep: 8, sept: 8, oct: 9, nov: 10, dec: 11,
};

// Parses "11 Sept" or "17 Sept 2026" style admin-entered dates.
function parseDateLabel(raw) {
  if (!raw) return null;
  const match = String(raw).trim().match(/^(\d{1,2})\s+([A-Za-z]+)\.?(?:\s+(\d{4}))?$/);
  if (!match) return null;
  const month = MONTH_INDEX[match[2].toLowerCase()];
  if (month === undefined) return null;
  return { day: Number(match[1]), month, year: match[3] ? Number(match[3]) : null };
}

// Converts an admin-entered date label to ISO, backfilling a missing year.
function labelToISO(raw, fallbackYear) {
  const parts = parseDateLabel(raw);
  if (!parts) return null;
  return toISODate(new Date(parts.year ?? fallbackYear, parts.month, parts.day));
}

const DATE_EVENT_FIELDS = [
  { field: "openDate", type: "open", time: "Market opens 10:00 AM" },
  { field: "closeDate", type: "close", time: "Bidding closes 5:00 PM" },
  { field: "allotmentDate", type: "allotment", time: "Expected on this date" },
  { field: "refundDate", type: "refund", time: "Refunds / unblocking initiated" },
  { field: "dematDate", type: "demat", time: "Shares credited to demat" },
  { field: "listingDate", type: "listing", time: "Lists on NSE, BSE" },
];

/**
 * Builds the full list of calendar events fresh from IPO_DATA + IPO_DETAILS.
 * - A missing date on an IPO is skipped silently — no fake events.
 * - A Set keyed by ipo+type+date (or ipo+label+date for custom dates)
 *   guarantees no duplicates even if this runs on every refresh.
 */
function buildCalendarEvents() {
  const events = [];
  const seen = new Set();

  IPO_DATA.forEach((base) => {
    const full = { ...base, ...(IPO_DETAILS[base.id] || {}) };

    // openDate/closeDate are often entered without a year ("11 Sept");
    // borrow the year from whichever of this IPO's other dates has one.
    const fallbackYear =
      [full.listingDate, full.allotmentDate, full.refundDate, full.dematDate]
        .map((v) => parseDateLabel(v)?.year)
        .find((y) => Boolean(y)) ?? new Date().getFullYear();

    DATE_EVENT_FIELDS.forEach((def) => {
      const iso = labelToISO(full[def.field], fallbackYear);
      if (!iso) return; // date not set for this IPO — skip, don't fake it
      const key = `${full.id}|${def.type}|${iso}`;
      if (seen.has(key)) return;
      seen.add(key);
      events.push({ id: key, date: iso, type: def.type, title: full.companyName, time: def.time, ipoId: full.id });
    });

    (full.customDates || []).forEach((custom) => {
      const iso = labelToISO(custom.date, fallbackYear);
      if (!iso) return;
      const key = `${full.id}|custom|${custom.label}|${iso}`;
      if (seen.has(key)) return;
      seen.add(key);
      events.push({ id: key, date: iso, type: "custom", title: full.companyName, time: custom.label, ipoId: full.id });
    });
  });

  return events.sort((a, b) => a.date.localeCompare(b.date));
}

function toISODate(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(
    date.getDate()
  ).padStart(2, "0")}`;
}

function buildMonthCells(year, month) {
  const firstWeekday = (new Date(year, month, 1).getDay() + 6) % 7; // Monday = 0
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();
  const cells = [];
  for (let i = firstWeekday - 1; i >= 0; i--) {
    const d = daysInPrevMonth - i;
    cells.push({ date: new Date(year, month - 1, d), inMonth: false });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push({ date: new Date(year, month, d), inMonth: true });
  }
  while (cells.length % 7 !== 0) {
    const d = cells.length - (firstWeekday + daysInMonth) + 1;
    cells.push({ date: new Date(year, month + 1, d), inMonth: false });
  }
  return cells;
}


/* ---------------------------------------------------------------
   REUSABLE: Small square icon button (used in the header)
----------------------------------------------------------------*/
function IconButton({ t, onClick, ariaLabel, children }) {
  return (
    <button
      onClick={onClick}
      aria-label={ariaLabel}
      style={{
        width: 36,
        height: 36,
        borderRadius: 11,
        border: `1px solid ${t.border}`,
        background: t.surface,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        transition: "background 0.25s ease, border-color 0.25s ease",
        flexShrink: 0,
      }}
    >
      {children}
    </button>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: Header
----------------------------------------------------------------*/
function Header({
  t,
  title,
  titleColor,
  subtitle,
  showWordmark,
  showSearch,
  showBell,
  unreadCount,
  onSearchClick,
  onBellClick,
}) {
  return (
    <div
      style={{
        padding: "18px 20px 14px",
        display: "flex",
        flexDirection: "column",
        gap: 4,
        flexShrink: 0,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        {showWordmark ? (
          <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
            <div
              style={{
                width: 36,
                height: 36,
                borderRadius: 10,
                background: t.blue,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <TrendingUp size={20} color="#FFFFFF" strokeWidth={2.4} />
            </div>
            <span
              style={{
                fontSize: 26,
                fontWeight: 700,
                letterSpacing: "-0.02em",
                color: t.headBlue,
              }}
            >
              IPO Bazaar
            </span>
          </div>
        ) : (
          <span
            style={{
              fontSize: 26,
              fontWeight: 700,
              letterSpacing: "-0.02em",
              color: titleColor || t.headBlue,
            }}
          >
            {title}
          </span>
        )}

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {showSearch && (
            <IconButton t={t} onClick={onSearchClick} ariaLabel="Search">
              <Search size={16} color={t.textSecondary} strokeWidth={2} />
            </IconButton>
          )}
          {showBell && (
            <div style={{ position: "relative" }}>
              <IconButton t={t} onClick={onBellClick} ariaLabel="Notifications">
                <Bell size={16} color={t.textSecondary} strokeWidth={2} />
              </IconButton>
              {unreadCount > 0 && (
                <span
                  style={{
                    position: "absolute",
                    top: -3,
                    right: -3,
                    minWidth: 15,
                    height: 15,
                    borderRadius: 999,
                    background: cardColors.red,
                    color: "#FFFFFF",
                    fontSize: 9.5,
                    fontWeight: 800,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: "0 3px",
                    border: `2px solid ${t.bg}`,
                  }}
                >
                  {unreadCount}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {subtitle && (
        <span
          style={{
            fontSize: 14.5,
            fontWeight: 500,
            color: t.textSecondary,
            marginTop: 2,
          }}
        >
          {subtitle}
        </span>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: Notification panel (bell icon dropdown)
----------------------------------------------------------------*/
function NotificationsScreen({ t, notifications, onBack }) {
  return (
    <div
      style={{
        flex: 1,
        overflowY: "auto",
        background: t.bg,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          padding: "18px 16px 4px",
          display: "flex",
          alignItems: "center",
          gap: 12,
        }}
      >
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 24, fontWeight: 800, color: t.textPrimary }}>
          Notifications
        </span>
      </div>

      <div style={{ padding: "14px 16px 28px", display: "flex", flexDirection: "column", gap: 18 }}>
        {notifications.length === 0 ? (
          <div
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 12,
              padding: "48px 30px",
            }}
          >
            <div
              style={{
                width: 56,
                height: 56,
                borderRadius: 16,
                background: t.surface,
                border: `1px solid ${t.border}`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Bell size={24} color={t.textSecondary} strokeWidth={1.6} />
            </div>
            <span style={{ fontSize: 14, fontWeight: 600, color: t.textSecondary }}>
              You're all caught up
            </span>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {notifications.map((n) => (
              <div
                key={n.id}
                style={{
                  background: t.surface,
                  border: `1px solid ${t.border}`,
                  borderRadius: 18,
                  padding: "14px 16px",
                  display: "flex",
                  gap: 10,
                  alignItems: "flex-start",
                }}
              >
                <div
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    background: t.blue,
                    marginTop: 6,
                    flexShrink: 0,
                  }}
                />
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 800, color: t.textPrimary }}>
                    {n.title}
                  </div>
                  <div
                    style={{
                      fontSize: 12.5,
                      color: t.textSecondary,
                      marginTop: 4,
                      lineHeight: 1.45,
                    }}
                  >
                    {n.message}
                  </div>
                  <div style={{ fontSize: 11, color: t.textSecondary, marginTop: 6 }}>
                    {n.time}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: Home search bar
----------------------------------------------------------------*/
function HomeSearchBar({ t, value, onChange, onClose }) {
  return (
    <div
      style={{
        margin: "14px 16px 0",
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: "10px 12px",
        borderRadius: 14,
        background: t.surface,
        border: `1px solid ${t.border}`,
        flexShrink: 0,
      }}
    >
      <Search size={16} color={t.textSecondary} strokeWidth={2} />
      <input
        autoFocus
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search IPOs by company name"
        style={{
          flex: 1,
          border: "none",
          outline: "none",
          background: "transparent",
          fontSize: 13.5,
          fontWeight: 500,
          color: t.textPrimary,
        }}
      />
      <button
        onClick={onClose}
        aria-label="Close search"
        style={{
          background: "none",
          border: "none",
          cursor: "pointer",
          padding: 0,
          display: "flex",
        }}
      >
        <X size={16} color={t.textSecondary} strokeWidth={2.2} />
      </button>
    </div>
  );
}


/* ---------------------------------------------------------------
   REUSABLE: Status filter tabs (Home screen only)
   Follows the app's light/dark theme like everything else.
----------------------------------------------------------------*/
function FilterTabs({ t, active, onChange, counts }) {
  return (
    <div
      style={{
        margin: "14px 16px 0",
        padding: 4,
        borderRadius: 14,
        background: t.surface,
        border: `1px solid ${t.border}`,
        display: "flex",
        gap: 4,
        flexShrink: 0,
      }}
    >
      {STATUS_TABS.map((tab) => {
        const isActive = active === tab.key;
        const count = counts[tab.key] ?? 0;
        return (
          <button
            key={tab.key}
            onClick={() => onChange(tab.key)}
            style={{
              flex: 1,
              border: "none",
              cursor: "pointer",
              padding: "10px 4px",
              borderRadius: 11,
              background: isActive ? t.blue : "transparent",
              color: isActive ? "#FFFFFF" : t.textSecondary,
              fontSize: 12.5,
              fontWeight: 700,
              letterSpacing: "-0.01em",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
              transition: "background 0.25s ease, color 0.25s ease",
            }}
          >
            {tab.label}
            <span
              style={{
                fontSize: 10.5,
                fontWeight: 800,
                padding: "1px 6px",
                borderRadius: 999,
                background: isActive ? "rgba(255, 255, 255, 0.22)" : t.bg,
                color: isActive ? "#FFFFFF" : t.textSecondary,
              }}
            >
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: IPO Card sub-pieces
----------------------------------------------------------------*/
function StatusBadge({ status }) {
  const meta = STATUS_META[status] || STATUS_META.closed;
  return (
    <span
      style={{
        display: "inline-block",
        marginTop: 6,
        padding: "4px 10px",
        borderRadius: 999,
        background: meta.bg,
        color: meta.fg,
        fontSize: 10.5,
        fontWeight: 800,
        letterSpacing: "0.04em",
      }}
    >
      {meta.label}
    </span>
  );
}

function GmpBlock({ gmp, gmpPercentage }) {
  const isPositive = !String(gmpPercentage).trim().startsWith("-");
  const Arrow = isPositive ? ArrowUpRight : ArrowDownRight;
  const tone = isPositive ? cardColors.green : cardColors.red;
  return (
    <div style={{ textAlign: "right", flexShrink: 0 }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          gap: 2,
        }}
      >
        <Arrow size={14} color={tone} strokeWidth={2.6} />
        <span style={{ fontSize: 16, fontWeight: 800, color: tone }}>
          {gmp}
        </span>
      </div>
      <span style={{ fontSize: 12, fontWeight: 700, color: tone }}>
        {gmpPercentage}
      </span>
    </div>
  );
}

function InfoItem({ t, icon: Icon, label, value }) {
  return (
    <div style={{ minWidth: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <Icon size={13.5} color={t.blue} strokeWidth={2} />
        <span
          style={{
            fontSize: 11.5,
            fontWeight: 600,
            color: t.textSecondary,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {label}
        </span>
      </div>
      <span
        style={{
          display: "block",
          marginTop: 3,
          marginLeft: 19.5,
          fontSize: 14,
          fontWeight: 700,
          color: t.textPrimary,
          wordBreak: "break-word",
        }}
      >
        {value}
      </span>
    </div>
  );
}

function SquareIconButton({ t, onClick, ariaLabel, className, children }) {
  return (
    <button
      onClick={onClick}
      aria-label={ariaLabel}
      className={className}
      style={{
        width: 44,
        height: 44,
        flexShrink: 0,
        borderRadius: 13,
        background: t.bg,
        border: `1px solid ${t.border}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        transition: "background 0.2s ease, transform 0.15s ease",
      }}
    >
      {children}
    </button>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: IPOCard — data-driven, ready for Firebase later
----------------------------------------------------------------*/
function IPOCard({
  t,
  id,
  companyName = "Manika Plastech Ltd",
  status = "upcoming",
  openDate = "11 Sept",
  closeDate = "16 Sept",
  issueSize = "₹125.5 Cr",
  lotSize = "348 Shares",
  gmp = "₹13",
  gmpPercentage = "+30.2%",
  isSaved = false,
  isSelected = false,
  onSelect,
  onView,
  onToggleWatchlist,
}) {
  const details = IPO_DETAILS[id] || {};
  const infoItems = [
    { icon: Banknote, label: "Price Band", value: details.priceBand ?? "—" },
    { icon: Package, label: "Lot Size", value: lotSize },
    { icon: IndianRupee, label: "Investment", value: details.minInvestment ?? "—" },
    { icon: Banknote, label: "Issue Size", value: issueSize },
  ];

  return (
    <div
      role="button"
      tabIndex={0}
      className="ipo-card-btn"
      onClick={onSelect}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onSelect?.()}
      style={{
        width: "100%",
        boxSizing: "border-box",
        cursor: "pointer",
        background: isSelected ? cardColors.blueSoft : t.surface,
        border: isSelected ? `1.5px solid ${t.blue}` : `1px solid ${t.border}`,
        borderRadius: 20,
        padding: "18px 18px 16px",
        display: "flex",
        flexDirection: "column",
        gap: 14,
        flexShrink: 0,
        transition: "background 0.15s ease, border-color 0.15s ease",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          gap: 12,
        }}
      >
        <div style={{ minWidth: 0, flex: 1 }}>
          <h3
            style={{
              margin: 0,
              fontSize: 17,
              lineHeight: 1.25,
              fontWeight: 800,
              color: t.textPrimary,
              wordBreak: "break-word",
            }}
          >
            {companyName}
          </h3>
          <StatusBadge status={status} />
        </div>
        <GmpBlock gmp={gmp} gmpPercentage={gmpPercentage} />
      </div>

      {/* IPO date */}
      <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
        <span
          style={{
            fontSize: 13.5,
            fontWeight: 600,
            color: t.textPrimary,
          }}
        >
          {openDate} – {closeDate}
        </span>
      </div>

      <div style={{ height: 1, background: t.border }} />

      {/* Info grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          rowGap: 16,
          columnGap: 12,
        }}
      >
        {infoItems.map((item) => (
          <InfoItem key={item.label} t={t} {...item} />
        ))}
      </div>

      {/* Action row — revealed only once the card is selected */}
      <div
        style={{
          maxHeight: isSelected ? 120 : 0,
          opacity: isSelected ? 1 : 0,
          overflow: "hidden",
          transition: "max-height 0.28s ease, opacity 0.2s ease",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button
            className="ipo-card-btn"
            onClick={(e) => {
              e.stopPropagation();
              onView?.();
            }}
            style={{
              flex: 1,
              height: 46,
              border: "none",
              borderRadius: 13,
              background: t.blue,
              color: "#FFFFFF",
              fontSize: 14,
              fontWeight: 800,
              letterSpacing: "0.02em",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
            }}
          >
            VIEW
            <ArrowRight size={16} color="#FFFFFF" strokeWidth={2.6} />
          </button>

          <SquareIconButton
            t={t}
            className="ipo-card-btn"
            ariaLabel="Watchlist"
            onClick={(e) => {
              e.stopPropagation();
              onToggleWatchlist?.();
            }}
          >
            <Heart
              size={17}
              color={isSaved ? cardColors.red : t.textPrimary}
              fill={isSaved ? cardColors.red : "none"}
              strokeWidth={2}
            />
          </SquareIconButton>
        </div>

        {/* Disclaimer */}
        <p
          style={{
            margin: "14px 0 0",
            fontSize: 10.5,
            fontStyle: "italic",
            textAlign: "center",
            color: t.textSecondary,
            lineHeight: 1.4,
          }}
        >
          * GMP and information are indicative only and should not be
          considered financial or investment advice.
        </p>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: Empty state for a status with no IPOs (Home screen)
----------------------------------------------------------------*/
function IPOEmptyState({ t, status, label: labelOverride }) {
  const label = labelOverride || STATUS_TABS.find((s) => s.key === status)?.label || "";
  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 12,
        padding: "48px 30px",
      }}
    >
      <div
        style={{
          width: 56,
          height: 56,
          borderRadius: 16,
          background: t.surface,
          border: `1px solid ${t.border}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Inbox size={24} color={t.textSecondary} strokeWidth={1.6} />
      </div>
      <span
        style={{
          fontSize: 14,
          fontWeight: 600,
          color: t.textSecondary,
          textAlign: "center",
        }}
      >
        No {label} IPOs
      </span>
    </div>
  );
}

/* ---------------------------------------------------------------
   IPO DETAIL SCREEN — reusable pieces
----------------------------------------------------------------*/
function circleBtnStyle(t) {
  return {
    width: 36,
    height: 36,
    borderRadius: "50%",
    background: t.surface,
    border: `1px solid ${t.border}`,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    flexShrink: 0,
  };
}

/* Shared row style for the "Edit Profile Photo" action sheet. */
const sheetRowStyle = {
  display: "flex",
  alignItems: "center",
  gap: 12,
  width: "100%",
  border: "none",
  background: "transparent",
  borderRadius: 14,
  padding: "13px 6px",
  cursor: "pointer",
  textAlign: "left",
};
function sheetIconWrapStyle(bg) {
  return {
    width: 36,
    height: 36,
    borderRadius: "50%",
    background: bg,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  };
}

function SectionCard({ t, title, titleSize, children }) {
  return (
    <div
      style={{
        background: t.surface,
        border: `1px solid ${t.border}`,
        borderRadius: 18,
        padding: 16,
      }}
    >
      <div style={{ fontSize: titleSize || 13.5, fontWeight: 800, color: t.textPrimary, marginBottom: 12 }}>
        {title}
      </div>
      {children}
    </div>
  );
}

function StatTile({ t, label, value, grow }) {
  return (
    <div
      style={{
        flex: grow ? 1 : "1 1 calc(50% - 5px)",
        minWidth: grow ? 0 : "calc(50% - 5px)",
        background: t.bg,
        border: `1px solid ${t.border}`,
        borderRadius: 14,
        padding: "10px 12px",
      }}
    >
      <div style={{ fontSize: 11, fontWeight: 600, color: t.textSecondary }}>{label}</div>
      <div
        style={{
          fontSize: 14.5,
          fontWeight: 800,
          color: t.textPrimary,
          marginTop: 3,
          wordBreak: "break-word",
        }}
      >
        {value}
      </div>
    </div>
  );
}

function OverviewRow({ t, icon: Icon, label, value }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div
        style={{
          width: 32,
          height: 32,
          borderRadius: 10,
          background: t.bg,
          border: `1px solid ${t.border}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        <Icon size={15} color={t.blue} strokeWidth={2} />
      </div>
      <span style={{ fontSize: 13, fontWeight: 600, color: t.textSecondary, flex: 1 }}>
        {label}
      </span>
      <span style={{ fontSize: 13.5, fontWeight: 800, color: t.textPrimary }}>{value}</span>
    </div>
  );
}

function VerticalTimeline({ t, stages }) {
  return (
    <div>
      {stages.map((stage, i) => {
        const isLast = i === stages.length - 1;
        return (
          <div key={stage.key} style={{ display: "flex", gap: 12 }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
              <div
                style={{
                  width: 14,
                  height: 14,
                  borderRadius: "50%",
                  background: t.blue,
                  border: `2px solid ${t.blue}`,
                  boxSizing: "border-box",
                }}
              />
              {!isLast && (
                <div
                  style={{
                    width: 2,
                    flex: 1,
                    minHeight: 28,
                    background: t.blue,
                    marginTop: 2,
                  }}
                />
              )}
            </div>
            <div style={{ paddingBottom: isLast ? 0 : 18 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: t.textPrimary }}>{stage.label}</div>
              {stage.date && (
                <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 2 }}>
                  {stage.date}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function MiniTrendChart({ t, data }) {
  const max = Math.max(...data.map((d) => d.value));
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 10, height: 80 }}>
      {data.map((d, i) => (
        <div
          key={i}
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 6,
            height: "100%",
            justifyContent: "flex-end",
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: 34,
              borderRadius: 6,
              background: t.blue,
              height: `${Math.max(10, (d.value / max) * 100)}%`,
            }}
          />
          <span style={{ fontSize: 10.5, fontWeight: 600, color: t.textSecondary }}>
            {d.label}
          </span>
        </div>
      ))}
    </div>
  );
}

function parseMoneyToNumber(str) {
  if (!str) return null;
  const match = String(str).replace(/,/g, "").match(/-?\d+(\.\d+)?/);
  return match ? parseFloat(match[0]) : null;
}

function formatMoney(num) {
  if (num === null || Number.isNaN(num)) return null;
  const rounded = Math.round(num * 100) / 100;
  return `₹${rounded.toLocaleString("en-IN")}`;
}

function IPODetailScreen({ t, ipo, onBack }) {
  const [openLearn, setOpenLearn] = useState(null);
  const [showFullAbout, setShowFullAbout] = useState(false);

  const stages = [
    { key: "open", label: "Open", date: ipo.openDate },
    { key: "close", label: "Close", date: ipo.closeDate },
    { key: "allotment", label: "Allotment", date: ipo.allotmentDate },
    { key: "refund", label: "Refund", date: ipo.refundDate },
    { key: "listing", label: "Listing", date: ipo.listingDate },
  ];

  const handleShare = () => {
    if (typeof navigator !== "undefined" && navigator.share) {
      navigator
        .share({ title: ipo.companyName, text: `Check out ${ipo.companyName} on IPO Bazaar` })
        .catch(() => {});
    }
  };

  // GMP x Lot Size, and the estimated gain per lot, are the same
  // figure — derived here rather than stored twice in the data.
  const gmpNum = parseMoneyToNumber(ipo.gmp);
  const lotNum = parseMoneyToNumber(ipo.lotSize);
  const gmpLotValue = gmpNum !== null && lotNum !== null ? formatMoney(gmpNum * lotNum) : null;

  const highlightFields = [
    { icon: Banknote, label: "Issue Size", value: ipo.issueSize },
    { icon: TrendingUp, label: "Fresh Issue", value: ipo.freshIssue },
    { icon: PieChart, label: "OFS", value: ipo.ofs },
    { icon: IndianRupee, label: "Price Band", value: ipo.priceBand },
    { icon: Package, label: "Lot Size", value: ipo.lotSize },
    { icon: IndianRupee, label: "Investment", value: ipo.minInvestment },
    { icon: IndianRupee, label: "Face Value", value: ipo.faceValue },
    { icon: ClipboardCheck, label: "Issue Type", value: ipo.ipoType?.replace(" IPO", "") },
    { icon: Landmark, label: "Listed On", value: ipo.listedOn },
  ].filter((f) => f.value);

  const documents = [
    { label: "HRHP", url: ipo.hrhpUrl },
    { label: "RHP", url: ipo.rhpUrl },
  ].filter((d) => d.url);

  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div
        style={{
          padding: "16px 16px 4px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 10,
        }}
      >
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span
          style={{
            fontSize: 14,
            fontWeight: 700,
            color: t.textPrimary,
            flex: 1,
            textAlign: "center",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {ipo.companyName}
        </span>
        <button onClick={handleShare} aria-label="Share" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <Share2 size={16} color={t.blue} strokeWidth={2.2} />
        </button>
      </div>

      <div style={{ padding: "10px 16px 28px", display: "flex", flexDirection: "column", gap: 16 }}>
        {/* 1. IPO HEADER */}
        <div>
          <div
            style={{
              fontSize: 19,
              fontWeight: 800,
              color: t.textPrimary,
              wordBreak: "break-word",
            }}
          >
            {ipo.companyName} IPO
          </div>
          <div style={{ marginTop: 8 }}>
            <StatusBadge status={ipo.status} />
          </div>
        </div>

        {/* 2. IPO HIGHLIGHTS */}
        {highlightFields.length > 0 && (
          <SectionCard t={t} title="IPO Highlights">
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                rowGap: 16,
                columnGap: 12,
              }}
            >
              {highlightFields.map((f) => (
                <InfoItem key={f.label} t={t} icon={f.icon} label={f.label} value={f.value} />
              ))}
            </div>
          </SectionCard>
        )}

        {/* 3. GMP */}
        {ipo.gmp && (
          <SectionCard t={t} title="Grey Market Premium">
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                rowGap: 16,
                columnGap: 12,
              }}
            >
              <div>
                <div style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary }}>GMP</div>
                <div
                  style={{
                    fontSize: 16,
                    fontWeight: 800,
                    color: subTone(ipo.gmpPercentage),
                    marginTop: 3,
                  }}
                >
                  {ipo.gmp}
                </div>
              </div>
              <div>
                <div style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary }}>GMP %</div>
                <div
                  style={{
                    fontSize: 16,
                    fontWeight: 800,
                    color: subTone(ipo.gmpPercentage),
                    marginTop: 3,
                  }}
                >
                  {ipo.gmpPercentage}
                </div>
              </div>
              {gmpLotValue && (
                <div>
                  <div style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary }}>
                    GMP × Lot Size
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 800, color: t.textPrimary, marginTop: 3 }}>
                    {gmpLotValue}
                  </div>
                </div>
              )}
              {ipo.estimatedListingPrice && (
                <div>
                  <div style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary }}>
                    Est. Listing Price
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 800, color: t.textPrimary, marginTop: 3 }}>
                    {ipo.estimatedListingPrice}
                  </div>
                </div>
              )}
              {gmpLotValue && (
                <div>
                  <div style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary }}>
                    Est. Gain / Lot
                  </div>
                  <div
                    style={{
                      fontSize: 14,
                      fontWeight: 800,
                      color: subTone(ipo.gmpPercentage),
                      marginTop: 3,
                    }}
                  >
                    {gmpLotValue}
                  </div>
                </div>
              )}
              <div>
                <div style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary }}>
                  Est. Gain %
                </div>
                <div
                  style={{
                    fontSize: 14,
                    fontWeight: 800,
                    color: subTone(ipo.gmpPercentage),
                    marginTop: 3,
                  }}
                >
                  {ipo.gmpPercentage}
                </div>
              </div>
            </div>
          </SectionCard>
        )}

        {/* 4. IPO TIMELINE */}
        <SectionCard t={t} title="IPO Timeline">
          <VerticalTimeline t={t} stages={stages} />
        </SectionCard>

        {/* 5. ABOUT COMPANY */}
        {ipo.about && (
          <SectionCard t={t} title="About Company">
            <p style={{ margin: 0, fontSize: 13.5, lineHeight: 1.55, color: t.textPrimary }}>
              {showFullAbout && ipo.aboutFull ? ipo.aboutFull : ipo.about}
            </p>
            {ipo.aboutFull && ipo.aboutFull !== ipo.about && (
              <button
                onClick={() => setShowFullAbout((v) => !v)}
                style={{
                  marginTop: 8,
                  background: "none",
                  border: "none",
                  padding: 0,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <span style={{ fontSize: 12.5, fontWeight: 700, color: t.blue }}>
                  {showFullAbout ? "Show Less" : "Read More"}
                </span>
                <ArrowRight size={13} color={t.blue} strokeWidth={2.4} />
              </button>
            )}
            {ipo.website && (
              <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px solid ${t.border}` }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                    Company Website
                  </span>
                  <a
                    href={ipo.website}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      fontSize: 12.5,
                      fontWeight: 700,
                      color: t.blue,
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                      textDecoration: "none",
                    }}
                  >
                    Visit Website
                    <ArrowRight size={13} strokeWidth={2.4} />
                  </a>
                </div>
                <div
                  style={{
                    marginTop: 4,
                    fontSize: 11.5,
                    color: t.textSecondary,
                    wordBreak: "break-all",
                  }}
                >
                  {ipo.website}
                </div>
              </div>
            )}
          </SectionCard>
        )}

        {/* 6. FINANCIAL SNAPSHOT */}
        {ipo.financials && (
          <SectionCard t={t} title="Financial Snapshot">
            <div style={{ overflowX: "auto" }}>
              <div style={{ minWidth: 320 }}>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: `1.2fr repeat(${ipo.financials.years.length}, 1fr)`,
                    gap: 6,
                    paddingBottom: 8,
                    borderBottom: `1px solid ${t.border}`,
                  }}
                >
                  <span />
                  {ipo.financials.years.map((y) => (
                    <span
                      key={y}
                      style={{
                        fontSize: 11,
                        fontWeight: 700,
                        color: t.textSecondary,
                        textAlign: "right",
                      }}
                    >
                      {y}
                    </span>
                  ))}
                </div>
                {ipo.financials.rows.map((row) => (
                  <div
                    key={row.label}
                    style={{
                      display: "grid",
                      gridTemplateColumns: `1.2fr repeat(${ipo.financials.years.length}, 1fr)`,
                      gap: 6,
                      padding: "10px 0",
                      borderBottom: `1px solid ${t.border}`,
                    }}
                  >
                    <span style={{ fontSize: 12, fontWeight: 700, color: t.textPrimary }}>
                      {row.label}
                    </span>
                    {row.values.map((v, i) => (
                      <span
                        key={i}
                        style={{
                          fontSize: 12,
                          fontWeight: 600,
                          color: v === "—" ? t.textSecondary : t.textPrimary,
                          textAlign: "right",
                        }}
                      >
                        {v}
                      </span>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </SectionCard>
        )}

        {/* 7. SHARE ALLOCATION */}
        {ipo.shareAllocation && (
          <SectionCard t={t} title="Share Allocation">
            <div style={{ display: "flex", gap: 10 }}>
              <CategoryStat t={t} label="QIB" value={ipo.shareAllocation.qib} />
              <CategoryStat t={t} label="HNIs" value={ipo.shareAllocation.hni} />
              <CategoryStat t={t} label="Retail" value={ipo.shareAllocation.retail} />
            </div>
          </SectionCard>
        )}

        {/* 8. IPO BAZAAR ANALYSIS */}
        {(ipo.positives || ipo.negatives) && (
          <SectionCard t={t} title="IPO Bazaar Analysis">
            {ipo.positives && (
              <div style={{ marginBottom: ipo.negatives ? 14 : 0 }}>
                <div
                  style={{
                    fontSize: 12,
                    fontWeight: 700,
                    color: cardColors.green,
                    marginBottom: 8,
                    letterSpacing: "0.02em",
                  }}
                >
                  POSITIVES
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {ipo.positives.map((p, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
                      <CheckCircle2
                        size={15}
                        color={cardColors.green}
                        strokeWidth={2}
                        style={{ marginTop: 1, flexShrink: 0 }}
                      />
                      <span style={{ fontSize: 13, color: t.textPrimary, lineHeight: 1.4 }}>
                        {p}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {ipo.negatives && (
              <div>
                <div
                  style={{
                    fontSize: 12,
                    fontWeight: 700,
                    color: t.blue,
                    marginBottom: 8,
                    letterSpacing: "0.02em",
                  }}
                >
                  NEGATIVES
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {ipo.negatives.map((c, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
                      <AlertTriangle
                        size={15}
                        color={t.blue}
                        strokeWidth={2}
                        style={{ marginTop: 1, flexShrink: 0 }}
                      />
                      <span style={{ fontSize: 13, color: t.textPrimary, lineHeight: 1.4 }}>
                        {c}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </SectionCard>
        )}

        {/* 9. IPO LEARN */}
        <SectionCard t={t} title="IPO Learn">
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {LEARN_TOPICS.map((topic) => {
              const isOpen = openLearn === topic.key;
              return (
                <div
                  key={topic.key}
                  style={{ border: `1px solid ${t.border}`, borderRadius: 14, overflow: "hidden" }}
                >
                  <button
                    onClick={() => setOpenLearn(isOpen ? null : topic.key)}
                    style={{
                      width: "100%",
                      padding: "12px 14px",
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                      background: isOpen ? t.surface : "none",
                      border: "none",
                      cursor: "pointer",
                      transition: "background 0.2s ease",
                    }}
                  >
                    <div
                      style={{
                        width: 30,
                        height: 30,
                        borderRadius: 10,
                        background: cardColors.blueSoft,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                    >
                      <BookOpen size={15} color={t.blue} strokeWidth={2} />
                    </div>
                    <span
                      style={{
                        fontSize: 13,
                        fontWeight: 700,
                        color: t.textPrimary,
                        textAlign: "left",
                        flex: 1,
                      }}
                    >
                      {topic.question}
                    </span>
                    <ChevronDown
                      size={16}
                      color={t.textSecondary}
                      strokeWidth={2.2}
                      style={{
                        transform: isOpen ? "rotate(180deg)" : "none",
                        transition: "transform 0.2s ease",
                        flexShrink: 0,
                      }}
                    />
                  </button>
                  {isOpen && (
                    <div style={{ padding: "0 14px 14px 54px" }}>
                      <span style={{ fontSize: 12.5, color: t.textSecondary, lineHeight: 1.5 }}>
                        {topic.answer}
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </SectionCard>

        {/* 10. DOCUMENTS */}
        {documents.length > 0 && (
          <SectionCard t={t} title="Documents">
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {documents.map((doc) => (
                <a
                  key={doc.label}
                  href={doc.url}
                  target="_blank"
                  rel="noreferrer"
                  className="ipo-card-btn"
                  style={{ display: "flex", alignItems: "center", gap: 12, textDecoration: "none" }}
                >
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 12,
                      background: t.bg,
                      border: `1px solid ${t.border}`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    <FileText size={18} color={t.blue} strokeWidth={2} />
                  </div>
                  <span style={{ fontSize: 13.5, fontWeight: 700, color: t.textPrimary, flex: 1 }}>
                    {doc.label}
                  </span>
                  <span
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: t.blue,
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    View Document
                    <ArrowRight size={13} strokeWidth={2.4} />
                  </span>
                </a>
              ))}
            </div>
          </SectionCard>
        )}

        {/* 11. PROMOTERS */}
        {ipo.promoters && ipo.promoters.length > 0 && (
          <SectionCard t={t} title="Promoters">
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {ipo.promoters.map((name) => (
                <div key={name} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div
                    style={{
                      width: 30,
                      height: 30,
                      borderRadius: 10,
                      background: cardColors.blueSoft,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    <Users size={15} color={t.blue} strokeWidth={2} />
                  </div>
                  <span style={{ fontSize: 13.5, fontWeight: 700, color: t.textPrimary }}>
                    {name}
                  </span>
                </div>
              ))}
            </div>
          </SectionCard>
        )}

        {/* 12. REGISTRAR */}
        {ipo.registrar && (
          <SectionCard t={t} title="Registrar">
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 10,
                  background: cardColors.blueSoft,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                <Landmark size={15} color={t.blue} strokeWidth={2} />
              </div>
              <span style={{ fontSize: 13.5, fontWeight: 700, color: t.textPrimary, flex: 1 }}>
                {ipo.registrar}
              </span>
            </div>
            {ipo.registrarUrl && (
              <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px solid ${t.border}` }}>
                <a
                  href={ipo.registrarUrl}
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    display: "block",
                    fontSize: 12,
                    fontWeight: 600,
                    color: t.blue,
                    textAlign: "right",
                    wordBreak: "break-all",
                    textDecoration: "none",
                  }}
                >
                  {ipo.registrarUrl}
                </a>
              </div>
            )}
          </SectionCard>
        )}

        {/* 13. DISCLAIMER */}
        <SectionCard t={t} title="Disclaimer">
          <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
            <Info size={16} color={t.blue} strokeWidth={2.2} style={{ marginTop: 1, flexShrink: 0 }} />
            <p
              style={{
                margin: 0,
                fontSize: 12,
                color: t.textSecondary,
                lineHeight: 1.55,
              }}
            >
              {ipo.disclaimer || DEFAULT_IPO_DISCLAIMER}
            </p>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   SUBSCRIPTION SCREEN — reusable pieces
----------------------------------------------------------------*/
function SubStatusPill({ status }) {
  const meta = SUB_STATUS_META[status] || SUB_STATUS_META.open;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        padding: "3px 9px",
        borderRadius: 999,
        background: meta.bg,
        color: meta.fg,
        fontSize: 11,
        fontWeight: 800,
        flexShrink: 0,
      }}
    >
      <span
        style={{
          width: 6,
          height: 6,
          borderRadius: 999,
          background: meta.fg,
        }}
      />
      {meta.label}
    </span>
  );
}

function SubTabs({ t, active, onChange, counts }) {
  return (
    <div
      style={{
        margin: "14px 16px 0",
        padding: 4,
        borderRadius: 14,
        background: t.surface,
        border: `1px solid ${t.border}`,
        display: "flex",
        gap: 4,
        flexShrink: 0,
      }}
    >
      {SUB_TABS.map((tab) => {
        const isActive = active === tab.key;
        const count = counts?.[tab.key] ?? 0;
        return (
          <button
            key={tab.key}
            onClick={() => onChange(tab.key)}
            style={{
              flex: 1,
              border: "none",
              cursor: "pointer",
              padding: "10px 4px",
              borderRadius: 11,
              background: isActive ? t.blue : "transparent",
              color: isActive ? "#FFFFFF" : t.textSecondary,
              fontSize: 12.5,
              fontWeight: 700,
              letterSpacing: "-0.01em",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
              transition: "background 0.25s ease, color 0.25s ease",
            }}
          >
            {tab.label}
            <span
              style={{
                fontSize: 10.5,
                fontWeight: 800,
                padding: "1px 6px",
                borderRadius: 999,
                background: isActive ? "rgba(255, 255, 255, 0.22)" : t.bg,
                color: isActive ? "#FFFFFF" : t.textSecondary,
              }}
            >
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
}

function SubscriptionCard({ t, ipo, isSelected, onSelect, onOpen }) {
  const isListed = ipo.status === "listed";
  return (
    <div
      role="button"
      tabIndex={0}
      className="ipo-card-btn"
      onClick={onSelect}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onSelect()}
      style={{
        cursor: "pointer",
        background: isSelected ? cardColors.blueSoft : t.surface,
        border: isSelected ? `1.5px solid ${t.blue}` : `1px solid ${t.border}`,
        borderRadius: 20,
        padding: "16px 18px",
        display: "flex",
        flexDirection: "column",
        gap: 10,
        flexShrink: 0,
        transition: "background 0.15s ease, border-color 0.15s ease",
      }}
    >
      <span
        style={{
          fontSize: 16,
          fontWeight: 800,
          color: t.textPrimary,
          wordBreak: "break-word",
        }}
      >
        {ipo.companyName}
      </span>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 10,
        }}
      >
        <span style={{ fontSize: 13, fontWeight: 600, color: t.textSecondary }}>
          {ipo.openDate} – {ipo.closeDate}
        </span>
        <SubStatusPill status={ipo.status} />
      </div>

      <div style={{ height: 1, background: t.border }} />

      <div>
        <div style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary }}>
          {isListed ? "Final Subscription" : "Overall Subscription"}
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "baseline",
            gap: 8,
            marginTop: 2,
          }}
        >
          <span
            style={{
              fontSize: 24,
              fontWeight: 800,
              color: subTone(ipo.subscriptionChange),
            }}
          >
            {isListed ? ipo.finalSubscription : ipo.overallSubscription}
          </span>
          <span
            style={{
              fontSize: 13,
              fontWeight: 700,
              color: subTone(ipo.subscriptionChange),
            }}
          >
            {ipo.subscriptionChange}
          </span>
        </div>
      </div>

      <div
        style={{
          maxHeight: isSelected ? 60 : 0,
          opacity: isSelected ? 1 : 0,
          overflow: "hidden",
          display: "flex",
          justifyContent: "flex-end",
          transition: "max-height 0.28s ease, opacity 0.2s ease",
        }}
      >
        <button
          className="ipo-card-btn"
          onClick={(e) => {
            e.stopPropagation();
            onOpen();
          }}
          style={{
            marginTop: 4,
            border: "none",
            borderRadius: 999,
            background: t.blue,
            color: "#FFFFFF",
            fontSize: 12.5,
            fontWeight: 800,
            padding: "9px 18px",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
          }}
        >
          View Details
          <ArrowRight size={14} strokeWidth={2.6} />
        </button>
      </div>
    </div>
  );
}

function DayTabs({ t, active, onChange }) {
  return (
    <div
      style={{
        display: "flex",
        gap: 4,
        padding: 4,
        borderRadius: 12,
        background: t.bg,
        border: `1px solid ${t.border}`,
      }}
    >
      {SUB_DAYS.map((day) => {
        const isActive = active === day;
        return (
          <button
            key={day}
            onClick={() => onChange(day)}
            style={{
              flex: 1,
              border: "none",
              cursor: "pointer",
              padding: "8px 0",
              borderRadius: 9,
              background: isActive ? t.blue : "transparent",
              color: isActive ? "#FFFFFF" : t.textSecondary,
              fontSize: 12.5,
              fontWeight: 700,
              transition: "background 0.2s ease, color 0.2s ease",
            }}
          >
            {day}
          </button>
        );
      })}
    </div>
  );
}

function CategoryStat({ t, label, value, valueColor }) {
  return (
    <div
      style={{
        flex: 1,
        background: t.surface,
        border: `1px solid ${t.border}`,
        borderRadius: 14,
        padding: "12px 8px",
        textAlign: "center",
      }}
    >
      <div style={{ fontSize: 10.5, fontWeight: 600, color: t.textSecondary }}>
        {label}
      </div>
      <div
        style={{
          fontSize: 15,
          fontWeight: 800,
          color: valueColor || t.textPrimary,
          marginTop: 4,
        }}
      >
        {value}
      </div>
    </div>
  );
}

function TrackButton({ t, onClick }) {
  return (
    <button
      className="ipo-card-btn"
      onClick={onClick}
      style={{
        width: "100%",
        height: 58,
        border: "none",
        borderRadius: 29,
        background: t.blue,
        color: "#FFFFFF",
        fontSize: 16,
        fontWeight: 800,
        letterSpacing: "0.01em",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 9,
        cursor: "pointer",
        boxShadow: `0 6px 16px ${cardColors.blueSoft}`,
      }}
    >
      <Bell size={19} strokeWidth={2.2} />
      Track This IPO
    </button>
  );
}

function SubscriptionDetails({ t, ipo, onBack }) {
  const isListed = ipo.status === "listed";
  const gainIsNegative = isListed && String(ipo.listingGain).trim().startsWith("-");

  return (
    <div
      style={{
        flex: 1,
        overflowY: "auto",
        padding: "16px 16px 28px",
        display: "flex",
        flexDirection: "column",
        gap: 18,
      }}
    >
      <button
        onClick={onBack}
        aria-label="Back to Subscriptions"
        className="ipo-card-btn"
        style={{
          width: 36,
          height: 36,
          borderRadius: "50%",
          background: t.surface,
          border: `1px solid ${t.border}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          alignSelf: "flex-start",
          padding: 0,
          flexShrink: 0,
        }}
      >
        <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
      </button>

      <div>
        <h2
          style={{
            margin: 0,
            fontSize: 20,
            fontWeight: 800,
            color: t.textPrimary,
            wordBreak: "break-word",
          }}
        >
          {ipo.companyName}
        </h2>
        <div style={{ marginTop: 8 }}>
          <SubStatusPill status={ipo.status} />
        </div>
        {ipo.openDate && ipo.closeDate && (
          <div style={{ marginTop: 8, fontSize: 13.5, fontWeight: 600, color: t.textPrimary }}>
            {ipo.openDate} – {ipo.closeDate}
          </div>
        )}
      </div>

      <div
        style={{
          background: t.surface,
          border: `1px solid ${t.border}`,
          borderRadius: 18,
          padding: "20px 16px",
          textAlign: "center",
        }}
      >
        <span style={{ fontSize: 12, fontWeight: 600, color: t.textSecondary }}>
          {isListed ? "Final Subscription" : "Overall Subscription"}
        </span>
        <div
          style={{
            display: "flex",
            alignItems: "baseline",
            justifyContent: "center",
            gap: 10,
            marginTop: 4,
          }}
        >
          <span
            style={{
              fontSize: 34,
              fontWeight: 800,
              color: subTone(ipo.subscriptionChange),
            }}
          >
            {isListed ? ipo.finalSubscription : ipo.overallSubscription}
          </span>
          <span
            style={{
              fontSize: 15,
              fontWeight: 700,
              color: subTone(ipo.subscriptionChange),
            }}
          >
            {ipo.subscriptionChange}
          </span>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: t.textPrimary }}>
          Day-wise Subscription
        </span>
        <div style={{ overflowX: "auto" }}>
          <div style={{ minWidth: 300 }}>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1.2fr repeat(3, 1fr)",
                gap: 6,
                paddingBottom: 8,
                borderBottom: `1px solid ${t.border}`,
              }}
            >
              <span />
              {SUB_DAYS.map((d) => (
                <span
                  key={d}
                  style={{ fontSize: 11, fontWeight: 700, color: t.textSecondary, textAlign: "right" }}
                >
                  {d}
                </span>
              ))}
            </div>
            {[
              { label: "QIB", key: "qib" },
              { label: "NII/HNI", key: "nii" },
              { label: "Retail", key: "retail" },
            ].map((row) => (
              <div
                key={row.label}
                style={{
                  display: "grid",
                  gridTemplateColumns: "1.2fr repeat(3, 1fr)",
                  gap: 6,
                  padding: "10px 0",
                  borderBottom: `1px solid ${t.border}`,
                }}
              >
                <span style={{ fontSize: 12, fontWeight: 700, color: t.textPrimary }}>
                  {row.label}
                </span>
                {SUB_DAYS.map((d) => (
                  <span
                    key={d}
                    style={{ fontSize: 12, fontWeight: 600, color: t.textPrimary, textAlign: "right" }}
                  >
                    {ipo.days[d]?.[row.key] ?? "—"}
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      {isListed && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: t.textPrimary }}>
            Listing Details
          </span>
          <div style={{ display: "flex", gap: 10 }}>
            <CategoryStat t={t} label="Issue Price" value={ipo.issuePrice} />
            <CategoryStat t={t} label="Listing Price" value={ipo.listingPrice} />
            <CategoryStat
              t={t}
              label="Listing Gain"
              value={ipo.listingGain}
              valueColor={gainIsNegative ? cardColors.red : cardColors.green}
            />
          </div>
        </div>
      )}

      <p
        style={{
          margin: 0,
          fontSize: 10.5,
          fontStyle: "italic",
          textAlign: "center",
          color: t.textSecondary,
          lineHeight: 1.4,
        }}
      >
        * Subscription figures are indicative only and should not be considered
        financial or investment advice.
      </p>
    </div>
  );
}

/* ---------------------------------------------------------------
   ALLOTMENT SCREEN — reusable pieces
----------------------------------------------------------------*/
function AllotmentTabs({ t, active, onChange, counts }) {
  return (
    <div
      style={{
        margin: "14px 16px 0",
        padding: 4,
        borderRadius: 14,
        background: t.surface,
        border: `1px solid ${t.border}`,
        display: "flex",
        gap: 4,
        flexShrink: 0,
      }}
    >
      {ALLOT_TABS.map((tab) => {
        const isActive = active === tab.key;
        const count = counts?.[tab.key] ?? 0;
        return (
          <button
            key={tab.key}
            onClick={() => onChange(tab.key)}
            style={{
              flex: 1,
              border: "none",
              cursor: "pointer",
              padding: "10px 6px",
              borderRadius: 11,
              background: isActive ? t.blue : cardColors.blueSoft,
              color: isActive ? "#FFFFFF" : t.blue,
              fontSize: 12,
              fontWeight: 700,
              letterSpacing: "-0.01em",
              transition: "background 0.25s ease, color 0.25s ease",
            }}
          >
            {tab.label} ({count})
          </button>
        );
      })}
    </div>
  );
}

function AllotmentCard({ t, item, isSelected, onSelect, onOpen, resultStatus }) {
  const isAvailable = item.status === "available";
  const isUpcoming = item.status === "upcoming";
  const resultMeta = resultStatus
    ? ALLOTMENT_STATUS_OPTIONS.find((o) => o.key === resultStatus)
    : null;

  return (
    <div
      role="button"
      tabIndex={0}
      className="ipo-card-btn"
      onClick={onSelect}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onSelect()}
      style={{
        cursor: "pointer",
        background: isSelected ? cardColors.blueSoft : t.surface,
        border: isSelected ? `1.5px solid ${t.blue}` : `1px solid ${t.border}`,
        borderRadius: 20,
        padding: "16px 16px",
        display: "flex",
        alignItems: "center",
        gap: 12,
        flexShrink: 0,
        transition: "background 0.15s ease, border-color 0.15s ease",
      }}
    >
      <div style={{ minWidth: 0, flex: 1 }}>
        <div
          style={{
            fontSize: 15.5,
            fontWeight: 800,
            color: t.textPrimary,
            wordBreak: "break-word",
          }}
        >
          {item.companyName}
        </div>
        <div style={{ marginTop: 4, fontSize: 12.5, fontWeight: 600, color: t.textSecondary }}>
          Allotment: {item.allotmentDate}
        </div>
        {item.registrar && (
          <div style={{ marginTop: 2, fontSize: 12, color: t.textSecondary }}>
            {item.registrar}
          </div>
        )}

        {isAvailable && (
          <div
            style={{
              maxHeight: isSelected ? 60 : 0,
              opacity: isSelected ? 1 : 0,
              overflow: "hidden",
              transition: "max-height 0.28s ease, opacity 0.2s ease",
            }}
          >
            <button
              className="ipo-card-btn"
              onClick={(e) => {
                e.stopPropagation();
                onOpen();
              }}
              style={{
                marginTop: 12,
                border: "none",
                borderRadius: 999,
                background: t.blue,
                color: "#FFFFFF",
                fontSize: 12.5,
                fontWeight: 800,
                padding: "9px 18px",
                cursor: "pointer",
              }}
            >
              Check Allotment
            </button>
          </div>
        )}

        {isUpcoming && (
          <div
            style={{
              maxHeight: isSelected ? 40 : 0,
              opacity: isSelected ? 1 : 0,
              overflow: "hidden",
              transition: "max-height 0.28s ease, opacity 0.2s ease",
            }}
          >
            <span
              style={{
                display: "inline-flex",
                marginTop: 12,
                padding: "5px 12px",
                borderRadius: 999,
                background: cardColors.blueSoft,
                color: t.blue,
                fontSize: 11,
                fontWeight: 800,
                letterSpacing: "0.02em",
                whiteSpace: "nowrap",
              }}
            >
              Allotted Soon
            </span>
          </div>
        )}
      </div>

      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 10, flexShrink: 0 }}>
        {isUpcoming && (
          <span
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 4,
              padding: "4px 10px",
              borderRadius: 999,
              background: cardColors.yellowSoft,
              color: cardColors.yellow,
              fontSize: 10.5,
              fontWeight: 800,
              letterSpacing: "0.02em",
              whiteSpace: "nowrap",
            }}
          >
            {isSelected && <CheckCircle2 size={11} strokeWidth={3} />}
            Upcoming
          </span>
        )}
        {isAvailable && resultMeta && (
          <span
            style={{
              padding: "4px 10px",
              borderRadius: 999,
              background: resultMeta.soft,
              color: resultMeta.color,
              fontSize: 10.5,
              fontWeight: 800,
              letterSpacing: "0.02em",
              whiteSpace: "nowrap",
            }}
          >
            {resultMeta.label}
          </span>
        )}
        {isAvailable && !resultMeta && (
          <span
            style={{
              padding: "4px 10px",
              borderRadius: 999,
              background: cardColors.greenSoft,
              color: cardColors.green,
              fontSize: 10.5,
              fontWeight: 800,
              letterSpacing: "0.02em",
              whiteSpace: "nowrap",
            }}
          >
            Available
          </span>
        )}
      </div>
    </div>
  );
}

function AllotmentDetailScreen({ t, item, onBack, savedStatus, onSaveStatus }) {
  const [pendingStatus, setPendingStatus] = useState(savedStatus || null);

  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "16px 16px 4px" }}>
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
      </div>

      <div style={{ padding: "10px 16px 28px", display: "flex", flexDirection: "column", gap: 18 }}>
        <span
          style={{
            fontSize: 20,
            fontWeight: 800,
            color: t.textPrimary,
            wordBreak: "break-word",
          }}
        >
          {item.companyName}
        </span>

        <SectionCard t={t} title="Allotment Details">
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <OverviewRow t={t} icon={ClipboardCheck} label="Allotment Date" value={item.allotmentDate} />
            {item.listingDate && (
              <OverviewRow t={t} icon={TrendingUp} label="Listing Date" value={item.listingDate} />
            )}
            {item.registrar && (
              <OverviewRow t={t} icon={Landmark} label="Registrar" value={item.registrar} />
            )}
          </div>
        </SectionCard>

        {item.registrarUrl && (
          <a
            href={item.registrarUrl}
            target="_blank"
            rel="noreferrer"
            className="ipo-card-btn"
            style={{
              width: "100%",
              height: 52,
              border: "none",
              borderRadius: 26,
              background: t.blue,
              color: "#FFFFFF",
              fontSize: 15,
              fontWeight: 800,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              cursor: "pointer",
              boxShadow: `0 6px 16px ${cardColors.blueSoft}`,
              textDecoration: "none",
              boxSizing: "border-box",
            }}
          >
            Check Allotment
            <ExternalLink size={16} strokeWidth={2.4} />
          </a>
        )}

        <div
          style={{
            padding: "12px 14px",
            borderRadius: 14,
            background: cardColors.blueSoft,
            display: "flex",
            alignItems: "flex-start",
            gap: 10,
          }}
        >
          <Info size={16} color={t.blue} strokeWidth={2.2} style={{ marginTop: 2, flexShrink: 0 }} />
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 800, color: t.blue, marginBottom: 3 }}>
              Important
            </div>
            <div style={{ fontSize: 12, color: t.textPrimary, lineHeight: 1.45 }}>
              IPO Bazaar does not collect or store any of your PAN or Application details. You
              will be redirected to the official registrar website.
            </div>
          </div>
        </div>

        <SectionCard t={t} title="Update your status here" titleSize={17}>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {ALLOTMENT_STATUS_OPTIONS.map((opt) => {
              const isSelected = pendingStatus === opt.key;
              return (
                <button
                  key={opt.key}
                  className="ipo-card-btn"
                  onClick={() => setPendingStatus(opt.key)}
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                    padding: "12px 14px",
                    borderRadius: 14,
                    border: `1.5px solid ${isSelected ? opt.color : t.border}`,
                    background: isSelected ? opt.soft : t.bg,
                    cursor: "pointer",
                    textAlign: "left",
                  }}
                >
                  <div
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: "50%",
                      border: `2px solid ${opt.color}`,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                    }}
                  >
                    {isSelected && (
                      <div style={{ width: 10, height: 10, borderRadius: "50%", background: opt.color }} />
                    )}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 800, color: opt.color }}>
                      {opt.label}
                    </div>
                    <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 1 }}>
                      {opt.desc}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <button
            className="ipo-card-btn"
            disabled={!pendingStatus}
            onClick={() => pendingStatus && onSaveStatus?.(pendingStatus)}
            style={{
              width: "100%",
              marginTop: 14,
              height: 46,
              border: "none",
              borderRadius: 23,
              background: pendingStatus ? t.blue : cardColors.blueSoft,
              color: pendingStatus ? "#FFFFFF" : t.blue,
              fontSize: 14,
              fontWeight: 800,
              cursor: pendingStatus ? "pointer" : "default",
            }}
          >
            Save My Status
          </button>

          {savedStatus && pendingStatus === savedStatus && (
            <div
              style={{
                marginTop: 10,
                padding: "10px 12px",
                borderRadius: 12,
                background:
                  ALLOTMENT_STATUS_OPTIONS.find((o) => o.key === savedStatus)?.soft,
                fontSize: 12.5,
                fontWeight: 700,
                color: ALLOTMENT_STATUS_OPTIONS.find((o) => o.key === savedStatus)?.color,
                textAlign: "center",
              }}
            >
              {ALLOTMENT_FEEDBACK[savedStatus]}
            </div>
          )}
        </SectionCard>

        <SectionCard t={t} title="How to check your IPO allotment?">
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {ALLOTMENT_STEPS.map((step, i) => (
              <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                <div
                  style={{
                    width: 24,
                    height: 24,
                    borderRadius: "50%",
                    background: t.blue,
                    color: "#FFFFFF",
                    fontSize: 12,
                    fontWeight: 800,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                  }}
                >
                  {i + 1}
                </div>
                <span style={{ fontSize: 13, color: t.textPrimary, lineHeight: 1.45, marginTop: 2 }}>
                  {step}
                </span>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   CALENDAR SCREEN — reusable pieces
----------------------------------------------------------------*/
const TODAY_ISO = "2026-09-13";
const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const WEEKDAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function CalendarSummaryCards({ t, total, opens, upcoming }) {
  const items = [
    { label: "Total Events", value: total },
    { label: "IPO Opens", value: opens },
    { label: "Upcoming", value: upcoming },
  ];
  return (
    <div style={{ display: "flex", gap: 10, padding: "14px 16px 0", flexShrink: 0 }}>
      {items.map((item) => (
        <div
          key={item.label}
          style={{
            flex: 1,
            background: t.surface,
            border: `1px solid ${t.border}`,
            borderRadius: 16,
            padding: "12px 8px",
            textAlign: "center",
          }}
        >
          <div style={{ fontSize: 20, fontWeight: 800, color: t.blue }}>{item.value}</div>
          <div style={{ fontSize: 10, fontWeight: 600, color: t.textSecondary, marginTop: 2 }}>
            {item.label}
          </div>
        </div>
      ))}
    </div>
  );
}

function MonthNav({ t, year, month, onPrev, onNext, onToday, onSelectMonth }) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerYear, setPickerYear] = useState(year);

  const openPicker = () => {
    setPickerYear(year);
    setPickerOpen(true);
  };

  const pickMonth = (m) => {
    onSelectMonth(m, pickerYear);
    setPickerOpen(false);
  };

  return (
    <div style={{ position: "relative", flexShrink: 0 }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "16px 16px 0",
          gap: 8,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button onClick={onPrev} aria-label="Previous month" className="ipo-card-btn" style={circleBtnStyle(t)}>
            <ChevronLeft size={17} color={t.blue} strokeWidth={2.4} />
          </button>

          <button
            onClick={() => (pickerOpen ? setPickerOpen(false) : openPicker())}
            aria-label="Choose month and year"
            className="ipo-card-btn"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 3,
              border: "none",
              background: "transparent",
              padding: "4px 2px",
              cursor: "pointer",
            }}
          >
            <span style={{ fontSize: 15, fontWeight: 800, color: t.textPrimary }}>
              {MONTH_NAMES[month]} {year}
            </span>
            <ChevronDown
              size={14}
              color={t.textSecondary}
              strokeWidth={2.2}
              style={{
                transform: pickerOpen ? "rotate(180deg)" : "none",
                transition: "transform 160ms ease",
              }}
            />
          </button>

          <button onClick={onNext} aria-label="Next month" className="ipo-card-btn" style={circleBtnStyle(t)}>
            <ChevronRight size={17} color={t.blue} strokeWidth={2.4} />
          </button>
        </div>

        <button
          onClick={onToday}
          className="ipo-card-btn"
          style={{
            border: `1px solid ${t.border}`,
            background: t.surface,
            borderRadius: 999,
            padding: "7px 12px",
            fontSize: 11.5,
            fontWeight: 700,
            color: t.blue,
            cursor: "pointer",
          }}
        >
          Today
        </button>
      </div>

      {pickerOpen && (
        <>
          <div
            onClick={() => setPickerOpen(false)}
            style={{ position: "fixed", inset: 0, zIndex: 20 }}
          />
          <div
            style={{
              position: "absolute",
              top: "calc(100% + 6px)",
              left: 16,
              right: 16,
              zIndex: 21,
              background: t.surface,
              border: `1px solid ${t.border}`,
              borderRadius: 18,
              padding: 14,
              boxShadow: "0 18px 36px rgba(15, 23, 42, 0.18)",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 18,
                marginBottom: 12,
              }}
            >
              <button
                onClick={() => setPickerYear((y) => y - 1)}
                aria-label="Previous year"
                className="ipo-card-btn"
                style={circleBtnStyle(t)}
              >
                <ChevronLeft size={15} color={t.blue} strokeWidth={2.4} />
              </button>
              <span style={{ fontSize: 14.5, fontWeight: 800, color: t.textPrimary, minWidth: 52, textAlign: "center" }}>
                {pickerYear}
              </span>
              <button
                onClick={() => setPickerYear((y) => y + 1)}
                aria-label="Next year"
                className="ipo-card-btn"
                style={circleBtnStyle(t)}
              >
                <ChevronRight size={15} color={t.blue} strokeWidth={2.4} />
              </button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
              {MONTH_NAMES.map((name, m) => {
                const isActive = m === month && pickerYear === year;
                return (
                  <button
                    key={name}
                    onClick={() => pickMonth(m)}
                    className="ipo-card-btn"
                    style={{
                      border: "none",
                      borderRadius: 12,
                      padding: "9px 4px",
                      fontSize: 12.5,
                      fontWeight: 700,
                      cursor: "pointer",
                      background: isActive ? t.blue : cardColors.blueSoft,
                      color: isActive ? "#FFFFFF" : t.blue,
                    }}
                  >
                    {name.slice(0, 3)}
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function CalendarGrid({ t, year, month, eventsByDate, selectedDate, onSelectDate }) {
  const cells = buildMonthCells(year, month);
  return (
    <div style={{ padding: "14px 16px 0", flexShrink: 0 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", marginBottom: 4 }}>
        {WEEKDAY_LABELS.map((d) => (
          <div
            key={d}
            style={{
              textAlign: "center",
              fontSize: 10.5,
              fontWeight: 700,
              color: t.textSecondary,
              padding: "4px 0",
            }}
          >
            {d}
          </div>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", rowGap: 2 }}>
        {cells.map((cell, i) => {
          const iso = toISODate(cell.date);
          const isToday = iso === TODAY_ISO;
          const isSelected = iso === selectedDate;
          const dayEvents = cell.inMonth ? eventsByDate[iso] || [] : [];
          const uniqueTypes = [...new Set(dayEvents.map((e) => e.type))];
          return (
            <button
              key={i}
              onClick={() => cell.inMonth && onSelectDate(iso === selectedDate ? null : iso)}
              disabled={!cell.inMonth}
              style={{
                border: "none",
                background: "transparent",
                borderRadius: 12,
                padding: "4px 0 8px",
                cursor: cell.inMonth ? "pointer" : "default",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 4,
                opacity: cell.inMonth ? 1 : 0.35,
              }}
            >
              <span
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 12.5,
                  fontWeight: isToday ? 800 : 600,
                  background: isToday ? t.blue : isSelected ? cardColors.blueSoft : "transparent",
                  color: isToday ? "#FFFFFF" : t.textPrimary,
                }}
              >
                {cell.date.getDate()}
              </span>
              <div style={{ display: "flex", gap: 2, height: 5 }}>
                {uniqueTypes.slice(0, 4).map((type) => (
                  <span
                    key={type}
                    style={{
                      width: 5,
                      height: 5,
                      borderRadius: "50%",
                      background: EVENT_TYPE_META[type]?.color,
                    }}
                  />
                ))}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function CalendarEventRow({ t, ev, onOpenIPO }) {
  const meta = EVENT_TYPE_META[ev.type];
  return (
    <button
      onClick={() => ev.ipoId && onOpenIPO(ev.ipoId)}
      className="ipo-card-btn"
      style={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: 12,
        textAlign: "left",
        background: t.surface,
        border: `1px solid ${t.border}`,
        borderRadius: 16,
        padding: "12px 14px",
        cursor: "pointer",
      }}
    >
      <span style={{ width: 8, height: 8, borderRadius: "50%", background: meta.color, flexShrink: 0 }} />
      <div style={{ minWidth: 0, flex: 1 }}>
        <div
          style={{
            fontSize: 13.5,
            fontWeight: 700,
            color: t.textPrimary,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {ev.title}
        </div>
        <div style={{ fontSize: 11, fontWeight: 600, color: t.textSecondary, marginTop: 2 }}>
          {meta.label}
          {ev.time ? ` · ${ev.time}` : ""}
        </div>
      </div>
      {ev.ipoId && <ChevronRight size={15} color={t.textSecondary} strokeWidth={2.2} style={{ flexShrink: 0 }} />}
    </button>
  );
}

function SelectedDateEvents({ t, selectedDate, events, onOpenIPO }) {
  const dateLabel = selectedDate
    ? new Date(`${selectedDate}T00:00:00`).toLocaleDateString("en-US", {
        weekday: "long",
        day: "numeric",
        month: "long",
      })
    : "EVENTS";

  return (
    <div style={{ display: "flex", flexDirection: "column", padding: "18px 0 4px" }}>
      <div
        style={{
          padding: "0 16px",
          marginBottom: 10,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
        }}
      >
        <span style={{ fontSize: 12, fontWeight: 800, letterSpacing: "0.04em", color: t.textSecondary }}>
          {dateLabel}
        </span>
        {events.length > 0 && (
          <span
            style={{
              fontSize: 10.5,
              fontWeight: 800,
              color: t.blue,
              background: cardColors.blueSoft,
              borderRadius: 999,
              padding: "3px 8px",
              whiteSpace: "nowrap",
            }}
          >
            {events.length} event{events.length > 1 ? "s" : ""}
          </span>
        )}
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 10,
          padding: "0 16px 16px",
        }}
      >
        {!selectedDate ? (
          <p style={{ fontSize: 12.5, color: t.textSecondary, padding: "8px 0" }}>Tap a date to see its IPO events.</p>
        ) : events.length === 0 ? (
          <p style={{ fontSize: 12.5, color: t.textSecondary, padding: "8px 0" }}>No IPO events on this date.</p>
        ) : (
          events.map((ev) => <CalendarEventRow key={ev.id} t={t} ev={ev} onOpenIPO={onOpenIPO} />)
        )}
      </div>
    </div>
  );
}

function CalendarScreen({ t, onOpenIPO }) {
  const [calYear, setCalYear] = useState(2026);
  const [calMonth, setCalMonth] = useState(8);
  const [selectedDate, setSelectedDate] = useState(TODAY_ISO);

  // Derived fresh from IPO_DATA + IPO_DETAILS on every render — no
  // separate calendar-events store, so an Admin edit to an IPO's dates
  // shows up here on the next refresh with nothing to keep in sync.
  const allEvents = useMemo(() => buildCalendarEvents(), []);

  const monthEvents = allEvents.filter((e) => {
    const d = new Date(`${e.date}T00:00:00`);
    return d.getFullYear() === calYear && d.getMonth() === calMonth;
  });

  const eventsByDate = {};
  monthEvents.forEach((e) => {
    if (!eventsByDate[e.date]) eventsByDate[e.date] = [];
    eventsByDate[e.date].push(e);
  });

  const opensCount = monthEvents.filter((e) => e.type === "open").length;
  const upcomingCount = monthEvents.filter((e) => e.date >= TODAY_ISO).length;
  const selectedEvents = selectedDate ? eventsByDate[selectedDate] || [] : [];

  const goPrev = () => {
    setSelectedDate(null);
    if (calMonth === 0) {
      setCalMonth(11);
      setCalYear((y) => y - 1);
    } else {
      setCalMonth((m) => m - 1);
    }
  };
  const goNext = () => {
    setSelectedDate(null);
    if (calMonth === 11) {
      setCalMonth(0);
      setCalYear((y) => y + 1);
    } else {
      setCalMonth((m) => m + 1);
    }
  };
  const goToday = () => {
    setCalYear(2026);
    setCalMonth(8);
    setSelectedDate(TODAY_ISO);
  };
  const goToMonth = (m, y) => {
    setCalMonth(m);
    setCalYear(y);
    setSelectedDate(null);
  };

  return (
    <div style={{ flex: 1, minHeight: 0, overflowY: "auto", display: "flex", flexDirection: "column", background: t.bg }}>
      <CalendarSummaryCards t={t} total={monthEvents.length} opens={opensCount} upcoming={upcomingCount} />
      <MonthNav
        t={t}
        year={calYear}
        month={calMonth}
        onPrev={goPrev}
        onNext={goNext}
        onToday={goToday}
        onSelectMonth={goToMonth}
      />
      <CalendarGrid
        t={t}
        year={calYear}
        month={calMonth}
        eventsByDate={eventsByDate}
        selectedDate={selectedDate}
        onSelectDate={setSelectedDate}
      />
      <SelectedDateEvents t={t} selectedDate={selectedDate} events={selectedEvents} onOpenIPO={onOpenIPO} />
    </div>
  );
}

/* ---------------------------------------------------------------
   SETTINGS SCREEN
----------------------------------------------------------------*/
const OTHERS_ITEMS = [
  { icon: Share2, title: "Share With Friends", subtitle: "Spread the word about IPO Bazaar" },
  { icon: Star, title: "Rate Our App", subtitle: "Help us improve with your feedback" },
];

const SUPPORT_ITEMS = [
  { icon: HelpCircle, title: "Help & FAQ", subtitle: "Find answers to common questions" },
  {
    icon: AlertTriangle,
    title: "Report a Problem",
    subtitle: "Let us know if something's not working",
    accent: "red",
  },
  { icon: MessageSquare, title: "Feedback", subtitle: "Share your suggestions" },
];

const LEGAL_ITEMS = [
  { icon: Lock, title: "Privacy Policy", subtitle: "How we protect your data" },
  { icon: FileText, title: "Terms & Conditions", subtitle: "Rules for using IPO Bazaar" },
  { icon: Info, title: "Disclaimer", subtitle: "Important information to note" },
];

const ABOUT_ITEMS = [
  { icon: Info, title: "About IPO Bazaar", subtitle: "Know more about our app" },
  { icon: Package, title: "App Version", value: "v1.0.0" },
];

/* Permanent Help & FAQ content. Keeping this as a flat data array —
   not hardcoded into the UI — makes it easy to swap for Admin
   Panel–managed content later without touching the screen below. */
const FAQ_ITEMS = [
  {
    id: "faq-1",
    question: "What is an IPO?",
    answer:
      "IPO stands for Initial Public Offering. It is the process through which a private company offers its shares to the public for the first time.",
  },
  {
    id: "faq-2",
    question: "What is GMP?",
    answer:
      "GMP (Grey Market Premium) is the unofficial premium at which an IPO may trade in the grey market before listing. It can change frequently and is not a guaranteed listing price.",
  },
  {
    id: "faq-3",
    question: "What is IPO subscription?",
    answer:
      "IPO subscription shows how many times the shares offered in an IPO have been applied for by investors across different categories.",
  },
  {
    id: "faq-4",
    question: "What is IPO allotment?",
    answer:
      "IPO allotment is the process of assigning IPO shares to investors after the application period ends. Shares may not be allotted to everyone if the IPO is oversubscribed.",
  },
  {
    id: "faq-5",
    question: "What is the IPO price band?",
    answer:
      "The price band is the minimum and maximum price per share at which investors can apply for an IPO.",
  },
  {
    id: "faq-6",
    question: "What is a lot size?",
    answer:
      "Lot size is the minimum number of shares an investor must apply for in an IPO. Applications are generally made in multiples of the lot size.",
  },
  {
    id: "faq-7",
    question: "How do I apply for an IPO?",
    answer:
      "IPO Bazaar provides IPO information but does not process applications. You can apply through your broker or an eligible UPI/ASBA platform.",
  },
  {
    id: "faq-8",
    question: "How do I check IPO allotment?",
    answer:
      "You can check your allotment through the IPO registrar or relevant exchange using your application details. IPO Bazaar can provide allotment information and updates.",
  },
  {
    id: "faq-9",
    question: "What are RII, NII & QIB?",
    answer:
      "RII means Retail Individual Investor, NII means Non-Institutional Investor, and QIB means Qualified Institutional Buyer. These are different investor categories in an IPO.",
  },
  {
    id: "faq-10",
    question: "Do IPOs always give listing gains?",
    answer:
      "No. An IPO may list above, at, or below its issue price. GMP and other indicators do not guarantee listing gains.",
  },
];

function SettingsRow({ t, icon: Icon, title, subtitle, accent, isLast, value, onClick }) {
  const iconColor = accent === "red" ? cardColors.red : t.blue;
  const iconBg = accent === "red" ? cardColors.redSoft : cardColors.blueSoft;
  const Wrapper = value !== undefined ? "div" : "button";
  return (
    <Wrapper
      onClick={value !== undefined ? undefined : onClick}
      className={value !== undefined ? undefined : "ipo-card-btn"}
      style={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "14px 0",
        border: "none",
        background: "none",
        cursor: value !== undefined ? "default" : "pointer",
        borderBottom: isLast ? "none" : `1px solid ${t.border}`,
        textAlign: "left",
      }}
    >
      <div
        style={{
          width: 34,
          height: 34,
          borderRadius: 10,
          background: iconBg,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        <Icon size={16} color={iconColor} strokeWidth={2} />
      </div>
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ fontSize: 13.5, fontWeight: 700, color: t.textPrimary }}>{title}</div>
        {subtitle && (
          <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 1 }}>{subtitle}</div>
        )}
      </div>
      {value !== undefined ? (
        <span style={{ fontSize: 13, fontWeight: 700, color: t.textSecondary }}>{value}</span>
      ) : (
        <ChevronRight size={16} color={t.textSecondary} strokeWidth={2.2} />
      )}
    </Wrapper>
  );
}

function SettingsSectionCard({ t, title, items, onItemClick }) {
  return (
    <div style={{ marginTop: 20 }}>
      <div
        style={{
          fontSize: 15,
          fontWeight: 800,
          letterSpacing: "0.04em",
          textTransform: "uppercase",
          color: t.textPrimary,
          marginBottom: 8,
          paddingLeft: 2,
        }}
      >
        {title}
      </div>
      <div
        style={{
          background: t.surface,
          border: `1px solid ${t.border}`,
          borderRadius: 20,
          padding: "6px 16px",
        }}
      >
        {items.map((item, i) => (
          <SettingsRow
            key={item.title}
            t={t}
            icon={item.icon}
            title={item.title}
            subtitle={item.subtitle}
            accent={item.accent}
            value={item.value}
            isLast={i === items.length - 1}
            onClick={onItemClick ? () => onItemClick(item.title) : undefined}
          />
        ))}
      </div>
    </div>
  );
}

function ToggleSwitch({ t, checked, onChange }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={onChange}
      style={{
        width: 44,
        height: 26,
        borderRadius: 999,
        border: "none",
        padding: 3,
        background: checked ? t.blue : t.border,
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: checked ? "flex-end" : "flex-start",
        transition: "background 0.2s ease",
        flexShrink: 0,
      }}
    >
      <div
        style={{
          width: 20,
          height: 20,
          borderRadius: "50%",
          background: "#FFFFFF",
          boxShadow: "0 1px 3px rgba(0,0,0,0.25)",
        }}
      />
    </button>
  );
}

function AskQuestionScreen({ t, onBack, onSubmit }) {
  const [questionText, setQuestionText] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!questionText.trim()) return;
    onSubmit(questionText.trim());
    setSubmitted(true);
  };

  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "18px 16px 4px", display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 20, fontWeight: 800, color: t.textPrimary }}>
          Ask Your Question
        </span>
      </div>

      <div style={{ padding: "16px 16px 28px", display: "flex", flexDirection: "column", gap: 14 }}>
        {submitted ? (
          <div
            style={{
              background: cardColors.greenSoft,
              border: `1px solid ${t.border}`,
              borderRadius: 16,
              padding: "16px",
              textAlign: "center",
            }}
          >
            <span style={{ fontSize: 13.5, fontWeight: 700, color: cardColors.green, lineHeight: 1.5 }}>
              Your question has been submitted. We'll review it soon.
            </span>
          </div>
        ) : (
          <>
            <textarea
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
              placeholder="Type your question here..."
              rows={5}
              style={{
                width: "100%",
                background: t.surface,
                border: `1px solid ${t.border}`,
                borderRadius: 16,
                padding: "14px",
                fontSize: 13.5,
                color: t.textPrimary,
                fontFamily: "inherit",
                resize: "vertical",
                outline: "none",
                boxSizing: "border-box",
              }}
            />
            <button
              onClick={handleSubmit}
              disabled={!questionText.trim()}
              className="ipo-card-btn"
              style={{
                width: "100%",
                height: 48,
                border: "none",
                borderRadius: 24,
                background: questionText.trim() ? t.blue : cardColors.blueSoft,
                color: questionText.trim() ? "#FFFFFF" : t.blue,
                fontSize: 14,
                fontWeight: 800,
                cursor: questionText.trim() ? "pointer" : "default",
              }}
            >
              Submit Question
            </button>
          </>
        )}
      </div>
    </div>
  );
}

const PROBLEM_TYPES = [
  "Incorrect IPO Information",
  "Incorrect GMP",
  "Wrong IPO Dates/Status",
  "Allotment Problem",
  "App/Feature Not Working",
  "Notification Problem",
  "Account/Login Problem",
  "Other",
];

function FormField({ t, label, required, children }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
        {label}
        {required && <span style={{ color: cardColors.red }}> *</span>}
      </span>
      {children}
    </div>
  );
}

const SETTINGS_DISCLAIMER_PARAGRAPHS = [
  "IPO Bazaar is an information and educational platform. The information provided in the app, including IPO details, GMP, subscription data, allotment information, dates, and other market-related information, is for general informational purposes only.",
  "IPO Bazaar does not provide investment, financial, legal, or tax advice and does not recommend buying or selling any security.",
  "GMP and subscription figures may change frequently and may vary between sources. While we make reasonable efforts to provide accurate and timely information, we do not guarantee that all information is complete, accurate, or error-free.",
  "Investing in IPOs and securities involves risk. An IPO may list above, at, or below its issue price, and GMP or other indicators do not guarantee listing gains or future returns.",
  "Users should verify important information through official sources such as the company's offer document, SEBI, stock exchanges, registrar, or their broker before making any investment decision.",
  "By using IPO Bazaar, you acknowledge that you are responsible for your own investment decisions.",
];

function WishlistScreen({ t, watchlist, onToggleWatchlist, onBack }) {
  const savedIPOs = IPO_DATA.filter((ipo) => watchlist[ipo.id]);

  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "18px 16px 4px", display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 20, fontWeight: 800, color: t.textPrimary }}>Wishlist</span>
      </div>

      <div style={{ padding: "16px 16px 28px", display: "flex", flexDirection: "column", gap: 12 }}>
        {savedIPOs.length === 0 ? (
          <div
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 12,
              padding: "48px 30px",
            }}
          >
            <div
              style={{
                width: 56,
                height: 56,
                borderRadius: 16,
                background: t.surface,
                border: `1px solid ${t.border}`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Heart size={24} color={t.textSecondary} strokeWidth={1.6} />
            </div>
            <span style={{ fontSize: 14, fontWeight: 600, color: t.textSecondary }}>
              No IPOs saved yet
            </span>
          </div>
        ) : (
          savedIPOs.map((ipo) => (
            <div
              key={ipo.id}
              style={{
                background: t.surface,
                border: `1px solid ${t.border}`,
                borderRadius: 18,
                padding: "14px 16px",
                display: "flex",
                alignItems: "center",
                gap: 12,
              }}
            >
              <div style={{ minWidth: 0, flex: 1 }}>
                <div
                  style={{
                    fontSize: 14.5,
                    fontWeight: 800,
                    color: t.textPrimary,
                    wordBreak: "break-word",
                  }}
                >
                  {ipo.companyName}
                </div>
                <div style={{ marginTop: 6 }}>
                  <StatusBadge status={ipo.status} />
                </div>
              </div>
              <SquareIconButton
                t={t}
                className="ipo-card-btn"
                ariaLabel="Remove from wishlist"
                onClick={() => onToggleWatchlist(ipo.id)}
              >
                <Heart size={17} color={cardColors.red} fill={cardColors.red} strokeWidth={2} />
              </SquareIconButton>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

const ABOUT_APP_INTRO =
  "IPO Bazaar is a simple and informative platform designed to help users stay updated with IPO-related information in one place.";

const ABOUT_APP_FEATURES = [
  "📊 Latest IPO updates and status",
  "📅 Important IPO dates and events",
  "📈 GMP and subscription information",
  "🏢 Company and IPO details",
  "🔔 Relevant updates and notifications",
  "❤️ Save IPOs to your wishlist",
  "📚 Learn about IPOs with easy-to-understand information",
];

const ABOUT_APP_PURPOSE =
  "We aim to make IPO information easier to understand and access, helping users research IPOs conveniently from one place.";

const ABOUT_APP_DISCLAIMER =
  "IPO Bazaar provides information for educational and informational purposes only. It is not investment advice or a recommendation to buy or sell any security. IPO information, GMP, subscription data, and other figures may change and should be independently verified from official sources before making any investment decision.";

function AboutIPOBazaarScreen({ t, onBack }) {
  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "18px 16px 4px", display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 20, fontWeight: 800, color: t.textPrimary }}>About IPO Bazaar</span>
      </div>

      <div style={{ padding: "16px 16px 28px", display: "flex", flexDirection: "column", gap: 16 }}>
        <p style={{ margin: 0, fontSize: 13.5, lineHeight: 1.6, color: t.textPrimary }}>
          {ABOUT_APP_INTRO}
        </p>

        <SectionCard t={t} title="Key Features">
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {ABOUT_APP_FEATURES.map((f) => (
              <span key={f} style={{ fontSize: 13.5, color: t.textPrimary, lineHeight: 1.4 }}>
                {f}
              </span>
            ))}
          </div>
        </SectionCard>

        <SectionCard t={t} title="Our Purpose">
          <p style={{ margin: 0, fontSize: 13.5, lineHeight: 1.6, color: t.textPrimary }}>
            {ABOUT_APP_PURPOSE}
          </p>
        </SectionCard>

        <SectionCard t={t} title="Disclaimer">
          <p style={{ margin: 0, fontSize: 13, lineHeight: 1.6, color: t.textSecondary }}>
            {ABOUT_APP_DISCLAIMER}
          </p>
        </SectionCard>
      </div>
    </div>
  );
}

function DisclaimerScreen({ t, onBack }) {
  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "18px 16px 4px", display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 20, fontWeight: 800, color: t.textPrimary }}>Disclaimer</span>
      </div>

      <div style={{ padding: "16px 16px 28px", display: "flex", flexDirection: "column", gap: 14 }}>
        {SETTINGS_DISCLAIMER_PARAGRAPHS.map((para, i) => (
          <p
            key={i}
            style={{ margin: 0, fontSize: 13, lineHeight: 1.6, color: t.textPrimary }}
          >
            {para}
          </p>
        ))}
      </div>
    </div>
  );
}

function ReportProblemScreen({ t, currentUserId, onBack, onSubmit }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [problemType, setProblemType] = useState("");
  const [ipoName, setIpoName] = useState("");
  const [description, setDescription] = useState("");
  const [screenshotName, setScreenshotName] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const inputStyle = {
    width: "100%",
    background: t.surface,
    border: `1px solid ${t.border}`,
    borderRadius: 14,
    padding: "12px 14px",
    fontSize: 13.5,
    color: t.textPrimary,
    fontFamily: "inherit",
    outline: "none",
    boxSizing: "border-box",
  };

  const canSubmit = name.trim() && email.trim() && problemType && description.trim();

  const handleSubmit = () => {
    if (!canSubmit) return;
    onSubmit({
      userId: currentUserId || null,
      name: name.trim(),
      email: email.trim(),
      problemType,
      ipoName: ipoName.trim() || null,
      description: description.trim(),
      screenshot: screenshotName || null,
      status: "New",
    });
    setSubmitted(true);
  };

  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "18px 16px 4px", display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 20, fontWeight: 800, color: t.textPrimary }}>Report a Problem</span>
      </div>

      <div style={{ padding: "16px 16px 28px", display: "flex", flexDirection: "column", gap: 18 }}>
        {submitted ? (
          <div
            style={{
              background: cardColors.greenSoft,
              border: `1px solid ${t.border}`,
              borderRadius: 16,
              padding: "18px",
              textAlign: "center",
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span style={{ fontSize: 14.5, fontWeight: 800, color: cardColors.green }}>
              Problem Reported Successfully
            </span>
            <span style={{ fontSize: 12.5, color: t.textPrimary, lineHeight: 1.5, marginTop: 4 }}>
              Thank you for helping us improve IPO Bazaar. Our team will review your report.
            </span>
          </div>
        ) : (
          <>
            <SectionCard t={t} title="Your Details">
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {currentUserId && (
                  <FormField t={t} label="User ID">
                    <div
                      style={{
                        ...inputStyle,
                        color: t.textSecondary,
                        background: t.bg,
                      }}
                    >
                      {currentUserId}
                    </div>
                  </FormField>
                )}
                <FormField t={t} label="Name" required>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name"
                    style={inputStyle}
                  />
                </FormField>
                <FormField t={t} label="Email" required>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    style={inputStyle}
                  />
                </FormField>
              </div>
            </SectionCard>

            <SectionCard t={t} title="Problem Details">
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <FormField t={t} label="Problem Type" required>
                  <select
                    value={problemType}
                    onChange={(e) => setProblemType(e.target.value)}
                    style={{ ...inputStyle, cursor: "pointer" }}
                  >
                    <option value="">Select a problem type</option>
                    {PROBLEM_TYPES.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </FormField>
                <FormField t={t} label="IPO Name">
                  <input
                    value={ipoName}
                    onChange={(e) => setIpoName(e.target.value)}
                    placeholder="If related to a specific IPO"
                    style={inputStyle}
                  />
                </FormField>
                <FormField t={t} label="Describe the Problem" required>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Tell us what went wrong..."
                    rows={5}
                    style={{ ...inputStyle, resize: "vertical" }}
                  />
                </FormField>
                <FormField t={t} label="Screenshot">
                  <label
                    className="ipo-card-btn"
                    style={{
                      ...inputStyle,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      cursor: "pointer",
                      color: screenshotName ? t.textPrimary : t.textSecondary,
                    }}
                  >
                    {screenshotName || "Attach a screenshot"}
                    <span style={{ fontSize: 12, fontWeight: 700, color: t.blue }}>Choose file</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setScreenshotName(e.target.files?.[0]?.name || "")}
                      style={{ display: "none" }}
                    />
                  </label>
                </FormField>
              </div>
            </SectionCard>

            <button
              onClick={handleSubmit}
              disabled={!canSubmit}
              className="ipo-card-btn"
              style={{
                width: "100%",
                height: 48,
                border: "none",
                borderRadius: 24,
                background: canSubmit ? t.blue : cardColors.blueSoft,
                color: canSubmit ? "#FFFFFF" : t.blue,
                fontSize: 14,
                fontWeight: 800,
                cursor: canSubmit ? "pointer" : "default",
              }}
            >
              Submit Report
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function FeedbackScreen({ t, onBack, onSubmit }) {
  const [feedbackText, setFeedbackText] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!feedbackText.trim()) return;
    onSubmit(feedbackText.trim());
    setSubmitted(true);
  };

  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "18px 16px 4px", display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 20, fontWeight: 800, color: t.textPrimary }}>Feedback</span>
      </div>
      <span style={{ padding: "6px 16px 0 66px", fontSize: 13, fontWeight: 500, color: t.textSecondary }}>
        We'd love to hear from you.
      </span>

      <div style={{ padding: "16px 16px 28px", display: "flex", flexDirection: "column", gap: 14 }}>
        {submitted ? (
          <div
            style={{
              background: cardColors.greenSoft,
              border: `1px solid ${t.border}`,
              borderRadius: 16,
              padding: "16px",
              textAlign: "center",
            }}
          >
            <span style={{ fontSize: 13.5, fontWeight: 700, color: cardColors.green, lineHeight: 1.5 }}>
              Thank you for your feedback!
            </span>
          </div>
        ) : (
          <>
            <textarea
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              placeholder="Write your feedback here..."
              rows={6}
              style={{
                width: "100%",
                background: t.surface,
                border: `1px solid ${t.border}`,
                borderRadius: 16,
                padding: "14px",
                fontSize: 13.5,
                color: t.textPrimary,
                fontFamily: "inherit",
                resize: "vertical",
                outline: "none",
                boxSizing: "border-box",
              }}
            />
            <button
              onClick={handleSubmit}
              disabled={!feedbackText.trim()}
              className="ipo-card-btn"
              style={{
                width: "100%",
                height: 48,
                border: "none",
                borderRadius: 24,
                background: feedbackText.trim() ? t.blue : cardColors.blueSoft,
                color: feedbackText.trim() ? "#FFFFFF" : t.blue,
                fontSize: 14,
                fontWeight: 800,
                cursor: feedbackText.trim() ? "pointer" : "default",
              }}
            >
              Submit Feedback
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function HelpFAQScreen({ t, onBack }) {
  const [openId, setOpenId] = useState(null);
  const [showAsk, setShowAsk] = useState(false);
  // Submitted questions are kept here for now — this is where they'd be
  // sent to a backend for the Admin Panel to review later.
  const [submittedQuestions, setSubmittedQuestions] = useState([]);

  if (showAsk) {
    return (
      <AskQuestionScreen
        t={t}
        onBack={() => setShowAsk(false)}
        onSubmit={(q) => setSubmittedQuestions((prev) => [...prev, q])}
      />
    );
  }

  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div
        style={{
          padding: "18px 16px 4px",
          display: "flex",
          alignItems: "center",
          gap: 12,
        }}
      >
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 20, fontWeight: 800, color: t.textPrimary }}>FAQs</span>
      </div>
      <span
        style={{
          padding: "6px 16px 0 66px",
          fontSize: 13,
          fontWeight: 500,
          color: t.textSecondary,
        }}
      >
        Things you need to know about IPOs
      </span>

      <div style={{ padding: "14px 16px 8px", display: "flex", flexDirection: "column", gap: 8 }}>
        {FAQ_ITEMS.map((item) => {
          const isOpen = openId === item.id;
          return (
            <div
              key={item.id}
              style={{ border: `1px solid ${t.border}`, borderRadius: 14, overflow: "hidden" }}
            >
              <button
                onClick={() => setOpenId(isOpen ? null : item.id)}
                style={{
                  width: "100%",
                  padding: "13px 14px",
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  background: isOpen ? t.surface : "none",
                  border: "none",
                  cursor: "pointer",
                  transition: "background 0.2s ease",
                }}
              >
                <span
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: t.textPrimary,
                    textAlign: "left",
                    flex: 1,
                  }}
                >
                  {item.question}
                </span>
                <ChevronDown
                  size={16}
                  color={t.textSecondary}
                  strokeWidth={2.2}
                  style={{
                    transform: isOpen ? "rotate(180deg)" : "none",
                    transition: "transform 0.2s ease",
                    flexShrink: 0,
                  }}
                />
              </button>
              {isOpen && (
                <div style={{ padding: "0 14px 14px" }}>
                  <span style={{ fontSize: 12.5, color: t.textSecondary, lineHeight: 1.55 }}>
                    {item.answer}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div style={{ padding: "10px 16px 28px" }}>
        <div
          style={{
            background: t.surface,
            border: `1px solid ${t.border}`,
            borderRadius: 18,
            padding: "18px 16px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            textAlign: "center",
            gap: 4,
          }}
        >
          <span style={{ fontSize: 14.5, fontWeight: 800, color: t.textPrimary }}>
            Still have a question?
          </span>
          <span style={{ fontSize: 12, color: t.textSecondary, marginBottom: 10 }}>
            Can't find what you're looking for? Ask us.
          </span>
          <button
            onClick={() => setShowAsk(true)}
            className="ipo-card-btn"
            style={{
              border: "none",
              borderRadius: 999,
              background: t.blue,
              color: "#FFFFFF",
              fontSize: 13,
              fontWeight: 800,
              padding: "10px 20px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            Ask Your Question
            <ArrowRight size={14} strokeWidth={2.6} />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   SIGN IN SCREEN
   Follows the app's current light/dark theme via the `t` prop,
   same as every other screen. The uploaded IPO Bazaar app-icon
   artwork is embedded below as a data URI so the file stays
   self-contained. No backend exists yet, so credentials are
   checked against a single local demo account — swap DEMO_ACCOUNT
   + the setTimeout below for a real API call when auth ships.
----------------------------------------------------------------*/

const IPO_BAZAAR_LOGO_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAADwCAYAAAA+VemSAAEAAElEQVR42uz9d9ylVXU+Dl9r3/c5T5vGDDAMvUhVUSkiil3UaKLy1aixRI0ajb0naoxGTaJRE2NLbLFFETSKokgQCyAoRaRIL8MwlOnz9NPuvdf7x25r73ufwbzv9/399YPP85mnP+fc5157rXWta10XGa2ZARAR8v+Yuf15dv+S+JjEvw/0n/x5ZqD0+6nwcf53x/0Mi88Tsh+WXyP795NvJ3Dpe/+3/7Uea+ExjLmODIaCso9jzLWVjzP8ZgaYAGL3WrovMHP4WftzKF+Pwn/kfjBckzGvcXg8/9t74Q96BGMe8R7+RnIr/EGPJb4+4dtL92YaHADZ5+2vk3yQXHr5H+je/UPupexjMkbHe/aBgqkYgOK3+YAgagcVZT8sXmwm2FvAfY5Kv29PT5DKL0bxWtjTCuz/3pjn6W/K1m9zATLuhqX8xskPIPnb/HVKL2rykMYfKvZ74+MkMAEwvIfrkf5MfBhkA30P1zZ/qcc+rux5MgAVrhf5CwiI5OCvZXgu2eNJX57sFcmenr93CBRvG/r/4RD2t2uezPJ7UxyU4SQFFQ8CBrsvU+E+CUHQPjDkTeYfmtGa/R8oPsjSx+5fcj/D4n0i8dIyku8v3xtZ9GR/A8zuxrFnMbvvoT0ENbtfw/buAZihCFCtrEyFlM1jTuf/Kynl//3v/+H/mBlam/AaKledjL9/WOT90ldFxt1DZhYlVTy0kswNUHKvl0+aYjoS8UTGGJZfIACcBK3MpDIQ93BTi6AuHQThwCwdEOJUCxdLfF/rR0SwEgEVQVzA9KIsNYxlA8w3QE8DcyPGwggYavu9FYmXzj29yl1YrQ2MNuLv2OenDcMYE/5cRQQDQGuGYZ9Z3GMEgYaLAGtAKShVgUjBGEbTNAAYigjaMLRhTHQqKAKMYfvmfgczQIqhfOtDBMPxYhhtQMT+7LKfY5sBSdnv08ZAEUEpm+3Y3wZswIZBKmYwozV0w+mNzyapHnSjYbS22dY09jBXKhzSJH6GKNT30Ma4i2Ns1jUGAKBUBWYD3TRQRCDlfpMx7nprVFXHvdQG05MTWDHdxczUBFbOTGLNqhmsWTWD1aumi7eo0Rr+KVdK/QHnc3q/F+/+Byq7ZZL0QVtKcvn7eaZ3GZp8APtSMU/54ZRolQpUbD2p/M4DX45W31voL8T3MiFc/JrSn13WwH19xqYecPsCcOeCxl09wua+wtYBsGwMFhqgbwA9ImDkyk5/Ehj5ZsKNhkbbN/81d9OhMfb7WAQ+Q3yfv3YK6C0Ac5vciawAVdt/DQNap3/PwJ4eNoLtx1y4gORuPvbRZgDduN9jAJ09PqL492SZJwIJrOMhaNh+rE08Kdn/Pve+Mfb36cZ9r7b/sokXhE0Mev/z/ufY/Zxx3+P/0xow7vf4vt4FbwwA93uIbYmlFKgirJzqYM2qldhv7RocumEvHHXE/jj68INwzBH747BD1mPd2pXJbdVoDTCSw6J4x44L0lLclAJyTFK0n5L3yx92UNgAFmVq+TT535aQ/9+XnONKFH9PA0CtYnGx2ADXLQKXzTJ+s9Pg2jnCfYsGywMCRmSDTrlSWqWNKrEBMYPYAJrBxsTANT4AxA3LDDI2KML3+s+z66mN/1gEFVX2D87eATQjuGI+dLkx+DkGMJM4oTkGL4v3M7SPXIYiwzGbiccOeZP4jMcm9qbGADCuEvMYgb0+yfOFe77ya6ztdTQGbJoQsARO/r7/PLvH5n8G0OHxkAxyloePuEaGw2OFMeDwfGwFAj2yr/1wCAxH7m8QaKqDDfuuxYOPOgSnnnA0HnfKQ3DSI47E6tUz4tywvytmZk5fpz0FMGdNbdILy8JwTLal/13TbkGswsnigzoANvKGabWtoiflHMnZ04ONYFDr532p4+43mWm3jhiXzDJ+vI1x8XbCnYsMjJQNNmP7DmUMlD/1YW9oX06yCwJ2NwIZd+PpLMMa7QKdw81B7mvsfgaGk6/D3Vc+m9vXYwLc3wbq7bBZlzkBwIljqRRapgxC8zFsA8f9TPZahQrCBwW7oPNBG/41Se/BIihhtMianGZM//3+NQtZ1YCNdtdBg1zWZHdAsj8QXMDDiMcH/3URsDI4/efCjWGy52DEARp/B4nnRO7vG2NgmgY8GgGDATDSQKfCwYfuj8ec9BA87Qkn4ImPfRgOPmh9zMyNhlKU9MxJGSwmGky058y7x575D/x+kaUJlPXAY0AkAfEhu8vc7/P9kphleKTSn/xEDwgXyc+7YwWVS1azDfCL3Qbf3c64cDdh2yKAIQGGQAaoDMCGwY0BaxGM7sUnd2MEEMxnGGNAxiTZl4w7zbUOvTqLbCvf7Pci3EQxgG02BFXAYAG0fJ/LxBRBeB6DfLJ8rTgZ0/jjlBKkzl73cIgYEzIj+bI6CWIRoEng+8Ax6e8OrYEsnW0Q+cBh9zdDKSwDUARrDDgtKoA0O8dKw4RKIWITHL7H3o7itXO/3z4WTkt1f5C4qkCJ/t4MB0BvALDBXuvX4WmPPQkvfv5T8eQnnoSpqY4L5AaKVLm8DrFSmFDuqZ0cBxKP/f54knuMiYz2aSIDkjzyG7Kr/EFOoPL8ezycz+KBUMBYyggyidaRAChlP3PdIuMr9xl8bzvj7gUCWAFQqBoGNMCaYRoGtHHlrQZrcZIbV8bJvhVwASle4KR8NiI4Tcy6IUhlSWtCicSuzvfBxagA3YAWNtrfI8tmiu8HDILbwSyrx6Sq4bw0jdUFJVk4C1gWwcxZULAocf2oQ576IaDLWdBmYR/E7SxKLivL4Ewel5zrye9JDhxOHg+B04MgC9q0ejCxMjA+YxsoF9AMQA+HwOIioCocd9xReMWLn4mXvOCp2G/D2gDWUZaRx8/dKA1KLo1q5dcpvtCMPwjUaqHQ4/+ABJHyPtXf0FQ4cbiFtJV67ogI2n/P327wH5sNzt9BGAxt/1qxzbZGA9wwuGGQ9uCSDEYWvZELRINWNg6lMPtS2Njf5VFRI75XIq9J9iNx2Akg0ABkAJ7fCNJ9MCoQmeT7HawbLzOjfeRxYZDN5IIM8UBxF9GXrcmBlQdTnn2TABdls+zLZQbPszlnZTtngJzMvsZkoBangBgkcm8EiCUqkPxvw+MORrQyZkxQ+8okZmR7zXT4fRUBBgyzvAws97HvgRvwZ889Ha999fNwzDGHxoyslI0DGlcSF6aQf2jJXOq3OZ+t+wAuEjb+UBCrNO1HOrTHGGYViR7XBe4F2xkfud3gF9sZMBVQEWqOwKbvOeHKZGp0KJdJ3rAhI7r+yOQZWWc9YwFtDae4AIlYZCMWsBupmF1t8Q/edSeovxNQHRvgZC88QkEosjHL0VneX1AWbDmgJVF0kz6vVhbKg7UNoMXn6W5w0Xtn9X0aHAFU0qIcL2RBuMMRpQzMLlZl6W3EKCr27LIKIPhRmClk3Xh4sOyZ4aq2kJl1aD8sd8Dez7rXBxYXMbN2Ff7yFS/EW9/0Uhx00D4hkKuq2jMe9L8ij/Aex0o5gyGi0DITIJ/xCHZJKbW72pxBAXT7Q04bzRFRvnSnwYdu0vifrQBQQVUu24bXMI40yPenWoO1GJWEzJv1qUmZnJ3GHlnmeOO3sljGuiIZR6LZYVIWXFBdYNdd4OWtINURYxD7RiKICZQxOvMjm0SVNSaAGWAYAZ5lPSBzBvYUAlkEZch+En3PKzhwmu1MXhJzO9O2AtrOq9kIZDsvmdm4+1n+XlOoIORhK5B0k5bssXVygeoOc5/tfW9u/zWhwqkqQjMaAnNLWHfgBrzhL1+It73ppVi1ahpaa0tgkoGLQj/LXKbxFn9OgJMYX3q3QKyx5fYfwuWU0e/R0pxWmfS5wD194MM3aHzxNsA0CqprDwHtn4wRSGM4QQ3IBS43OoJOboQCHUsxXyb5AyAGpyj1ZKZlTl44cAEbQDpU9w0Fg4BqArRrI3huM6gzEctkP7MVZbMM0ngpqcjsDZe2BSzF5wnY/pdka+BLf5P1v8a0y2k/jvIHQp6lk0lORJaLQBWygJNlPMbMkwtfY5jkeVNAwWOJzwJQa5X1yd8R10G++TLdiPm1aAXYI+4EVJVygbyAY44/Fh/90NvwrD95QjEbPyAp4w+hC3M7IwcQkwBil4Hbp8UfkP6TlA97miaNevuXaAPU7jl+6VbG+67X2LJIoMqyjrTxQ3CZBTyqGkcErN0F1zYbk+x7jQBX5OluxPzQj48c4MLGxMwifqaIDotqxf6n7GlENWj3XcDcZjsu8t+rlAheiRWoBKH3PDDfD8fDsAQyctqLh9kuQgkYqhHImTVAMG0EWJ4SrQydg2fZ7NkHmzz4UMjIecCC9xDA8fcEFLpVNZRbgAgumvQahPLeiH7cuIpFg00avGFWDcEUY4ZSBKUUmqUFQBv85Sv+DP/woTdj771XYzRqUPsb/IHIH3tareCUM84FbiFJEItdmcScjYRalR2nywjicZLgKudsLY8w14pwy6zBWy7SOP8eAqYr1MpSD9ndueFkNwxAxxtSjgMC+8cEFhPnM1kfpNQuq30WYjbihke7rBT3dHoxKM72qQbVXWD7zeD5e0D1hGBK+e9VMaDdDI8RS2qWSx45TVuyO0lUN0mvLqiwsmw1kfKYzGRLKDYytFdUHyHzCXYeywNFAlThcNFpKSyCPZ0129c5RZWRBHlrVpwEbQGdRwkD0Fk2NoLZpeMMPJljm3SmLZ6P5VUzzK5ZHHHUg/Dvn/4ATj/9VEv1hOQ2PDB76w8kdrcAZQdi7YEB0uL2F0gd+YaE3zDxkzr2HGXgqzcx3naRwe5lhXoKMAowcqSgPN9Kln0SKEHCiIJuAjMqltLiZjUsykHJRIooJFrlskCcKS1x/dYMSLkA7ABkQDtuAha2ApXIvO57wgvpgpkEAs0J8JVfczdiYr+lY7GIGLwmfazy5jWlEriQWTOWVnqtxOZMAI+yYzkhe4jXLgtA+bVw3V1AE2fldbgGYr7r+lkK94Pg7oVecRxQl2VcSRmVJXT4mLNS2rRQbRZMs6qu0SwtQhHhA+95M9733teGkVNVqT9oedMn0OKoaRyfGkkAU7ssBxfQaRIt4AOsWImSua8J77hI47NXMdBRqCpAW1gZRHbuaLNvyp/ljAoY+2GOvF8dT1MWIA7npIt84ULMdSObiZKsxH5FTSx3MruA60wDpgHdfyW4twtUT0a01gVwOi6i4hwYooTO++uc0JEcMDI7ZYypJMuKIEh65yyL2Z8xcVST0C85q0JKFYv7W5Rl3WLJXOBIS4pmDpLlfTPnpRG3ySYJMBYDUGZWuNk1ywBOgt2keInPxuCkelOKwDAwu3fhuc97Dr70xY9izZoZNCONulJJMVta+ilvAqLFo2hzof06Yb4cAS4v1wtUK/KtynV844L3rlngJedqXHo3UE0SjGEwaUBp24+J05fIhBfG0vLEGENS81iQ9bUWHGAx0+VCOVgAY1rZN18yDOWvJZEwCOjMAP1doK3XAsNFQNXuwFNgl1nJvziUcZ9bQJYIYMoqG2a0ts4E0hoPnqzfz8ZGYTTDhWvhb3IIoIwjWYPlqErcST7Q/c2cIsI5GyUbFUEE1liW2B5IHj47J4oGOUEECUKdtkt5htVpljVurMQ5w8wRVsTj95UfEVuQa9dOPPzEk3D2tz+DIx90IBrXF3NpAShjcUlAmPPd+BIBKu2BC4yQkhQAi6XrMWm/MUCnIlx+j8ELzmqwaR6op4HGI8RKu8xrYukW5n1t0IMRgzaAWdqjyzqj0CEtLyXRJASlWBpnESiyXHalsl/ZY1JA3QXqCdDOO8Bbb7CPVdX2scusS2TX98J6pgjY/OPk83nvKx9XPvc1Sd/nxyZp9ir19dmCP7fVKPyclsXPRcwdaTmd86UpB79MVjmYInkjzqE5FRjgFMiK9wLH2fm4TB2qBzE68sGMQgD7Pt4UPi8DHjoQfdg9Jw+kVt0Kzdw89t+wP878r0/hcY87Ec2oQVVXe+xp2yxFbo8RsxmzGCMJxQS5RdHOR+XFZ/HLtQOrzrnJ4M+/PcSCZtQTjMZfHGKQMmASLyYJlpRAMf0hQZLmZ8Ss00TOs5/5ybK4VTpnc9i4KGAXIcJiJZENPKUiCDW5AmQGwL3XAbN3O4JGBKaQlM4tvFCcgWIFkKKCBCfZRAYUtUClEouKEpJDPsduq37I30ORKpExmQrsq8I+cBkhDqTt8ZTOJKu6x0KyhOfswJKAFsbQRAsMsJxOiYguI592JCOmbNRUeGMHfsX7zqCuFZrlZayYnMR3zvo8nv6000ImllunNI69tSehizBLzgO4WC8jybwttYEsq/vM+5WrRnjVdzWMMqhqDW1EkCoDJvtxKEXID99NoDgS0lPaMupMRrQwCfsq9jkcVX/845b9KKENxnmAyI+FlCuX60mgOwmavwu491pg2APqCbeHGoPWJl2HMOd9rVwz8/vBSVktkHxB0BgLKjK3OcqFZYsAZhHSpZJsEUL+saRNQdw+SplaJiEaeK63X2kMGZOyCoDGEUhKdM00yzPkmIoTIQAaW3aXmWBpSZ/2yIGS6efCxowHtVyvHEdoMcNXtYIeDDEBxpnf/Hec8ZynFGbF4wK1QKYqcARcAHOZaVUkYKeltNxSajTQqQn/eeUQr/zWANRlkGKLMrtsS8QxeMmXH5yVWiZh5SSEdZOyilpE/DB+KnXlglBB5K4Tic0gAkMBqnJvNTAxBRotAvddD+zcaFHmqpNmxDDnRZqJ87+dj6Io27hkKkpnBR2uAmtKAnsRSEJhtJP/3SxzIjs8YMoz4LDkUBj35AwtFEZTSf7JxlCybUA8QOJjM8V5sT3szfg5cPJ8IghVZIfBZPeZTkdNzGN65zaZhdmgIgU9GmACwHfO/hL+5I+fEIK4vNjDrelHMtKl0kJ/ENnCONRqjOpA/JLPvN/8ncZLv74M6tgnZ4xTfiATMi6U/ZgRd08pGQlEMoUci6RAlhZ7tCx6WG6zpigDj8Sb70/JbVqBKlsaT64AFIO23wK653rwqAd0JiIBg5D9PlUIWqmLlGbaIjkjIJIoj5U4zmGT1kX2wLLXNNzmLvv2J8cAstcg7WdT1NmLF7D4u7EVQra5JHpUmDaQSP6xFtBt/7dIEFBMm7EVx0ucKoDkRJScKWbMGMAsA7ryDJyj00mPnGZ0NgaVskE8XVX4yY+/hcc97qQ0ExfYVv+LhX7DElMeRxcsKvO5r2sm1BXh7GtG+LOv9IBKg6Fjb0DajYlc1iWbiX05xSj0OlLpIt82QVysDxee0JprtkClJIhVCGDyM10oiy53J0FL9wGbrwLmtgDVhM3IJEtxNab3jYg+pPIlKPS8RH4cZRJwLaXICsJGkqlKY5ysJ22NU9KVr1RGOCNyyIyV96doc6lDi4JCOZz3x3vqCbj8byib4YghhfkyS16z23+Ogc/tsZLYjGLKKzlOg7QFYOn2HLkEcolSGmxQVQq638c+a9fi4p9/F8cccyi01lBKFYIY5Ra11YaN6YFzRlWebWWdrtmOii66XeOPPjWHPhuQMjbzBmTZBMQ59L3KDa6pxP4xKT0wlG1mzBZN9iQ9ii6zo8zEqgKrKg3AegroToH6u4H7rgPvuNOWZVVXnGlK8JrF7wW11gNTimKb95wXOvHSSjhJyqtSYQ0QrTK41QO3QKJxxBy0ySCFjJiSMlAY+4zpYeXXWuUhxGhJUDTl3J9hK7YWzRLpYoIksVAJOENhhDWGuQUJYmVBnQSzLpA/0kxve+IaenERxx57LC7+2ZlYt/dqsGEoJQDEPxil5qwH3qMANIp6tYbt/u7tOxinfWwWW+eHqGoDrR1BA3JMZGe+ILboc7jnS8va6QihrQbB6ZZUphjCfnYrymSCCjPa0N8SLBjVnQL6c8DWm0DbbgWavv28vGgyi6t0LpxmtZIQPhVO0TTltjUVqFANGQEyFQKXCnPtrESMOGQy0G1xoj0zKKFQQiiTUD7fRTb+4bga6UtpFth/rnreOjjSPj6l10IEE9KAK+49SzKLaQdr0h4I8hBMoef1+8RiBz0sPYiDJGMQepCv6tRodu3EM571TJz7/S/AGO20tyjTho6qG0VRPJ9DxkrqlII6280HAYtDwuM+MYdrN/ZQdRsbvI5h5Z+ED2C4spnIbZkkKFtWRpNgeBqdvqB5KmEF8qdYUjIrK2TnCRjk0eUK6E7bUnk4B9xzLbDjdmDYB1ddK5uS0yhdqd1Cs+W2UL5lFK4lpcv4rYtKGaaVarK01glFtmN5dnM+o5UjIm5XK8l8PAOssvI2BaeyzGpMCoKB4wqgGJiEcV3LXgApSkwoqI7Ix59nOM6CxrTYYfY67YkNNqYXRnsEtcf5MAtgVm6+idl33elgtGs73v23f4N//NBbbD+sqvFuJRifWwUKXUCbxy3lO4pkpQjP/485fPfXS6hnDJpmZJlUDrFjf4oJBDqMhMgkbMI0iDEeoaRUCSNZple+zBVvHiGmCqxUDNzBLLDlJmDLzUB/HuhMOkIGp2i1vw6qvZAQlSNzACLfxqJCSV1qCakFEqeEOA59cSwruS1DnihYmsLrV25BKF9QkH1vaekfpj3KShBOtCmcySEstdKy0Y+/hibd/01WGJO+XwsBglQjq7g8QXIEZcocakhJXsnS0skeMSWgmElBMpehWQjtAVY/vFnu4bxz/wt/9PTT0DSOcvmH7vR6E4W0hE7/TRaKQUGh0vKbCf947hze+41dqNcoNI0NWnLoMrkTil3/C591meML7wn6CUArlB8YyXgixXAoAaFsAJML1MoFrutzq65FlasKWNwC2nIjsGOjnedWXfu92dK9fGBEcjmBI7FjLCZD7bI2KaNJqr0XSDLZj4VyNwsEk6kLyLI0G++kk6TSeKiwrphk1TE9L8qjpnjPpMsGUg4ngHmlRYTs78X7Jge6zHj9LAkwlfphapNffKXBRhCLcmGCYj9sQsKiPFsb0xIqUIrAwxH233AArrz0v7HffusyNY89CN4xwn0ZS+g/RI0y9L2EX98+wBPefy90bWA8KAADQhNokfZk0y7bGtEXxX+9oReRZz8hK+XGKdMrgSQrV94qcFWBVA2uKosed6ftqtrcPaCtNwI7NwFNA9QdW0rHQSsYKhqDiTKZKCuXMw54u/KkcnBEQmQBTU57Xr/aORatBVJJ2BbLqp1R47SBx4ylODu0cyykVM5ycaYshSQYpbnzGKZfiQs9BiRL1hPHBbMshZHNzZHzrAtSti1Gl9ymStVIPD0zUHohkWgp7Gf/dlV3oGd34/kvfRHO+vrH/lfbSxkXmgtsqzby5RPGSAOPfM9mXL9xGWqKHOIsel+BPIedUOhwghLYtYISiZYkiEJWkjRhspYk7JFgVdlsW1WWZDE5A0xOA4NlWyJvuxm0sMU+rnrSfq+E68PfjZk8POeANCMQP1JjrkLW5Ry4KQ7oyuZqLGicBV50u70ozXnzbZZCmZsFX9InM5eKggLCTG1MwlcFpZeQXcC1LgBaPXRxPitZX5IH3SKzFFBjpL83LnAIiVwg1dVqbVqZjMnFGYil0+yLlBkIscUUrHiqCnphEd/73pdxxrOfAt1oKK/smF+jgrtDXCcU3zROjENrRl0rfPA7O/H+r9yHao2y3jZkrD1GmPv6z/nsy4HvzIjbKEn/SznJnyPLSezSsnLZ1gFUrFzG7UwBUystU2ppC2jrzcD2O4HlOQuVV504y/bgVr7E7HplkuOlwPqmgjg/iaTAWVyY6JQnA182BLKXZ25/f4uVxeVeOitfW60PxHZZcqJkoFdRYmfMiVOYR8fnnB0UmTtj6sGYCUJwHrA8ZhnDtAG1Ipgldb2kMD0nSDZlSw/JLLyk65WV6VFS15FNhMSPDN5E2pgBpRR40Mehhx2May7/EVasmHYFoHIOmns28iOjDbOsksdYhGrDqCuF393Rw6lvvxWNAozys10dwQNPm5TUSU9Qd0ggtwIYMaByUrcIbHYUR1KVzVBVDUzMgCZmADMAdm8Ctt8K3r0Z1IzAVcet+VHcFkpkbSg73Xy5XAlztuhbw6VcyuNm0fludOZ1Ky+6KfSv4uNkFbCFDZDIWoi7wdT2D05JL1zAtcTrUuzBMEbBI11ykEphPLac5gIaPo4IYoQrhBhFtRYqZGYU1EdJ4ECJL10YR+0BqQ5UTAeWsfR14jTrS1XPNuLtbv1OB3r3Lrzvg+/GB9/3xjbBI7+A4tYhrTWTtIYYs1BsXLZ40ntvwcW/nUO1ooI2OrKrxNjIjoq0qyyF7YffPiIBeocgjWuJ5PZpg5qFD1ZVgVUNqjvAxApwtwsM5kDbbwW23gIs7bDldGfC9sPemSAXk6OWqWxcLpCAmDhhZJ9IOcGCMT4zhTPDPR8W1txJaQmMEyFLe9ksgFkacGfBVPJWQs50QirgXobHC9hIjjxnm0tlgF3Evmn//oxOW+xZgZYCR/z+fASky1tSyaFQmB0jtWfh4maTyfSzcgCLoZTVbjPJsgWEvhYC9gNmzExP43eX/RCHH34gjDExiPfwX7AcikNjEVRZ6fzdS3fj4qt22+AdjVym9eiyduuBrlQhrwskgBYyIXDjCMnbystOjIIYHHsXv04H6E6DJlaBKwLN3g268/fA7ruAUc/u6XankotMeYlc2vyQd3oo11HYhOF0xMFZteJvblPij3NC+IA0d04eAxVQYxKVtvQxinSJdC82J99w6jguWU8heLm1wzKW7tg6EPLAHVOCM4kDUKDRBSaZdKGgIG6IFm8+KZ4Y5YX+lkl7SbVSEDzEYc056JbLB2Wglt/QshuoDD0/BCYrQMXtrlQXMeIkqu5gYdt2vO/Dn8G3vvLR8qJSfsRz3gOPQZ+ZHXD1jhtx3U1zUBMclxQCWBXLZlsduqUFceGDrpNDm+NKrA9YPxpygJRymz8TMxaYapaB3RtB224C5u63oEHteMqhDqVW6dqiOYqACVI1mW4z5+WpkXPRmEWiOJ0QBpDi7AS0FU9I0LepGDRt+9WCHE5+qJSAj2Aex2kpXcx++Vw2r8bymDYpmaTIgc4rnoyvPRZll4QeDkqlKFYL2eokSpYsJpXCzfXWxEEUhQyQZF6/RNMibbieV7nkpReHgGE86lH74MY7dmN+rnGUAm5d2zi0tePQihlXXvoDPOz4o1wpTW1HQ5mBW18Y0/ue9+tduO7anVAzFcyoASjVswpB7DMw4s2cgBeU9rapcLVAlOsuMLHSUhoHu4E7rgB23AoM5u331F2QcuqPnqlFDKIK3CJRIChTJuixtIgRLuEsxz0t1BeJ/Awjz0oUyfFyhhu+TFkOyUS9BZmjXJpjD4ATlcGugK7GYG8tSfhRGtOe+dOMFgss9HeEghD+Hg6CXNY2H2URnMOj3I/OH0wWpC1Z2nFU3bayR448R9KIDNZ0K8mPk6qK0fQaYGEZD3n4Xnjf+07E/k/ehRc971bM/2ItaIUvpYW+GSGpFKlWGO3ejY9/8sv4xn9+tNB7tLeWEiplCfFiR7A/7S2/w+XX2ADWzs+VQk9rUp4p5TNcIfKeBLCb3SrLT6aqBk9MA5OrbfZeuBe042YLTo16NhurKr4YruQlqGjNRAoMJfSEOCpwSGqjBK4CXVLGIbU4/yyULlgWveEGdsv8QYygnTBChpOPg5HetCig8floh0vUyAeYT8mVw8IMNqkISj19DoYVq4CixWK2yMAFsK8w/28Bb6KaSzC2cVTIHJAaE+C858zNwRFEKHA40lKlgGaogdkeNhwyg7e/5Vg88S+6uGfVRlxy++046y1DbL5gH9B0k5m0UxkkYKADxtW//jGOe8iRMB7Qkr5iwmalJozf9/fZ99zLd+I3V2+Hmq6gm1GY83IWwIEqSVlfldssKQo7tey5yfUkeHIFqFLA3B3A1t+D5zfb31dPWKqjFGnzXFtCUj6HzCrYSywzJMeSmcXBVcKj5FXhUEYbcR9ya4TEeWbOyluWsjqSFpf0qIVylQi5M1/LFaP918LzFVSNJFTbzOfx5XVr6Z6znrS9ttYG15J+Xmhbi0O+ZSeaBXsKclHqQDGO+GGybaUWSaTkLFEArJx5uVI2+zY7ljGxssbr3no0/uyt+2HbQVtx9u6boXctY3KSsHp1hc1iNCVmB0LMn0KVUVUVhnM78cWvnIVPfuJvxb0ZpZ6SEppz2kzyof3438+529pkElkZTrhlfJZjIiO2ZayDYSuruxuROdIeLc1xjf2h3bcB264BlrcDqmP723DjaLRkWDPF+tiX5fKtHH2DKOoqB7G6LFgTjIbK/kHJKU4k1tTEvkKr5CuLIcRgzJzcpU0NU/DDTcdVaFEfU+61QWvfiVjsVVAb6CqSKyT4xcXto4AByOoH3DoY2IhHJINSlswtZlg8ICi3Ry2RQLLetyV8VwpUlNcJo5CAz7qMZq4P8AjPf/5heMO7j4A+fhu+v/QrbN+yhCk1gW5nEjwxwPQatkFvtB/A2Ksi/bHESWq0BrrT+PZ//xjve88bsXbdarA2mS9xbINqlOa/bmxUKYXb7unhomt2AVMKphm5OZ9YF6RIDA9nOMWeNwFWpc4tdcATq0F1Dey+Bdh+HdDbYTNT1bUaU2zA45QxE/IgtU74MLdlOcGNpzt72wr3vwVKMvE4yUlI1vUgiPBIWGtFFLcFyrocnc/fixtL8VBJSlcJODK3boRWKUoZ0s1ol7zcGkq3xlZSTyt4HtOYZQbOCRucZJ+wXtiSKOOWJnUZVecMtM9nyCl3ORWuL8vzAOnSPhsdfraqGM3SAGapj1NPW4+/fu8xOPhpjEtG1+DmrVsAUqiogx5rNI1Ct9PF1D59gAYugcTRKLMSVakwQTCManICWzfdie9+7yd4zatfCG2M3VYq0OPq0thIxvN3LtqG5V0DVKsUdOMok65stoGMRKyMHeIZ75XILba9qgKqaWBiJai/FdhyJXjhXlBVux1cSgAJS5lMoyFduyNx+pLYRY0nFRFlsjFiqpKVv22MhAubUA6BlksF+YSdedw0NwQgmfFBHmbHXOAht0rtdPSSUo0zKmVr7zRzWKA0+HkMqh11pcqLJ5ExycUnR4kVLcZzopFNMUz+O8cQS7JSOrdFaQdwym1mv90EDaUYejhCs3sZhx+1Eu965wl47Esn8bvurfjaznvBrNCpJ7GsGzTQDuA2aFSFibUMVENAV+41rQAohx+p9h3tJxaqxn99+4d49V+8IKVWtubAJIyUxLWrFEEbxn9fvAVQBty4+p90YKGwhOYle4eyE94hzKw6wMRqkO4B91wIzN5u58+dSV8/CFmatPQiOR/296FBqnxYXA4wUb6V8y2hPYhmFwXkxgAszGXisATN5KJ2689Rtugv5r88jo+M9nwzO33tglW2ZSbndxizH5xhBqGi4ThrJl+aM7eIINxS42gPx+QMum0G354NI1dlKT3ubC7tWX+Bn9+yVjFCqjYuGpAz/FaKYbSG3rGMVWs7eNPfHo8XvHk/3L33vTh79moszo/QVV30YTA02v5FJmj3Wo6I0F1X2T35HoNquYaaocmRimK9laZmcPnlv8UNN92Bhz7kQSk7K+mBk94r8nKVUrjxzgVcd/NOUJdh9Cjym92JRhBysIGAz2EzLwrGEbheYTeDZm8BdlwFNIvgasL1PTouJ4hgkFpdwYIi27BhaeoV1tQo0/jKylJ+gDKXeQx9sDQiifuxZk9cqpZKxh58qEjyDqnwSyNzLoPZ0iF/0ZtW+h7RA2QwsQIoBO1SSmMkhBClAFOkZrYJKsku1zgV1UR7S86COTsgIexgTFySyVcKc0E6ZH5HzvCbHLtQ7+6BuoSXv/wIvOYdB6E6Zg4/6/0G23f1UVONTqXQh4Zm2MkHDGzOtuuIfSZ0V3dQTwygFwHUyh4UYZRZgURV6PkBDEZd1xjN7cb/XHAxHvqQB1kRedUqvFDnNwf5lUEA5126Fc18D/XqWuz7sitmTBh4UzbdkOt4hBqY2AuERfDmX4LmNwH1BFhNuAuaIsLpPDCn2lC2+1rqOVOWj71fCYk7QNJKtKmS+dy3XZYViPxJv5arT6aGzS331T32zFI0L0PHSxLCWW62OALl+FUbW8i4yMnrSu1FCeJ0vp/OmkWwj2V2UfsjOWrKKpyQn0w2R/ZHd2bNkgrcp8ErXRm8TQrc56qK0Sz2gOU+nvSkA/CevzsGBzy2j9+Y67F5dhGKKnSrCQyYbaCKzO81PzQzDAN9zahX1qhngMFOD64aR/OFIzpRa3084Cmqxjk/+ine9paXQ1WqVSmDCj0ww5bPzMCPL90CVACbxgYvdIL0MUVAyNp4+n63si+r6oIn9wYt3g6+/+fW1aCeiiTv1gbSGNKY+90cFhKkRAuStTKW63GcfYwMNMgXfpI5KcpOCDmIUmygJWonxQJzHa+8/6NEGaXNxmrbutrKxINy1BKMY+yp5Kby7JhF8GXPm1BuK9oo8PjxWmsC2qqyecx1F4okCZeOy24VRS1oYWwm1DRqxWgGIzSzizjqmDV473tOwWNe3MX1dBt+tLgdzDU61QSGbDBihiFH5nJa4oYZwTCTCTAGA21AM4SJlQpL0HbTzd+TxKKCiaQmDmCWAU1N4arf/g633XYXjj76cFtGZ6SrVgY2xho03X7PEq68eRcwwTC6AbhxjCvOxMmipjLJYWo9A6o6wPZLgN2/t2WDcm4GKnrkpk59WTBQHkQU4HTmnIaYZUHKMKdcvJ45YYJxVluT4Yw/2wZXEjneVm+aLw1Qy+JlLBEDUas6Sdkst5diT8v5oSCuq1yE4BZgWehVi7pXBUwgL7uJkKiJUllzeo/SiTzmMGxl43hCt/SxJYLNJkOdc81mDeX65GbnEtbs3cVb//6ReO7r12Pn2rtw3tJdGGpAqQmMwGg8YZLYBiyMq0MJGkADgmaCDm5BjM5Mhe5aQkv3jbItuNBYiETa6WAwuwsXX3IFjj76cFvhqLTVq/PD2F+Q3/x+F/qzS6hWKpimCYqSycpB0qMJn5/OSsAMgft/Ch5sBdVT8QKqTOAc+cZM5haezVTZUJFam4iI+2wggRqTAq4kelnODwzOBdwIJYmZJOi5QIgQIm7jPRyzTJjwTVHQKiPBAhNHhdQSTmxJSQDRkuBC7UyHXByf2wsARaWRcV5GaPOVx1yFMlm/fJCwWOZoo+BSGke4IUolDZ99iWGGI6DRePlLj8ab/vog4Kgd+PXwMswt9FCrLlhBBK+VpWhcmazB9l9mNAw0xmBk2GZosNWymDCoV6WjxuD+mXRDIqlxnEIAhMuuuAavftULi74ANcZssV10xRagGYG4zlQIZMxGapcFoZww+nA7sP1iQC+DqokgcEctVz4e0weWlBoRyg8mFPtUkhJvBMG4kcBR3FOl1uyW2/pMmcYTJwvsYquEUaQ6kjgY4vfTeCA4MwMXxO1Y8YTHQkmf3aZJ+sfprU4FEi3R3IQQwWPke0t7uqJnzme24AK/ubSCiSirxFRYVMjWBwHhIZy8KuJxmlRdRGpVQei0jTT2WTOBc7//VBz4sPvx8+ZS7JgdoOpMgFSNARiaCJqBBkDDBg0zGsNowO7j+DZixgiuxGYDowmqy1CrU01vad3rDQXISTrJ89oYA9RdXH3djRhlxmgUAzi9iypl/XuvvnUn0DFgrZ0MCge5l8C2EcwmkAK6q4Gl28A7LnOTo64diktdKaJkpBHXDYXmFJEDGQS5Xs5smQonemZJmdxgJh1foKVoFd830pdH9tDtko4KGaXEPEJLO59SpqYE6wwL0Xi0Rkvtt6wIINFHyx/lMeZ143aBc1ZT4unb3iCi0gwWY8T3RaXkMw4V8QQGclmALHi5OIvOlhOQGpuReL830PjKty/HYct3Yf9TgdVr1mDXskGjbbWoncqbDVibXRvEgI0BrN2bwYg1NGvURmFiUqFeK5VJx7dNCbPQV4GTE7j11ttxx52bcczRh8FoIyY8QJ3AGgwoRdi8ZRm33TMHdJQ1JktUBFNjYnLrf9RZCcxfD975GydfU6cbQZS78Dn4oVU3kSDjmJDp25pQhXW0AhMjVbMoFbLcmv1S60YZL5SOpKko8IjFOaHye9n3wZ4tJlcgvZJDXrVwPktMifAR7JLXW/QKhLLogC/tcknYlsfuGAeGsdka7VaEqHj4pSTBAv5ASF6fpNaQ7uctLyQI5FlY9RCwuDzA5z+yCdWnCKc8dRmn/1UXBzxlDZbUCAvLDD0iaDIxaI2JmdhnXdY2uMEY+YCGgWbGhFJQa0SbQZKYghYnnQSfHwxUdY3+7AKuufYmG8CcsrLqBMBihgJh4/1LWJgf2ARqOCFrkPRKAmz676wA5q4Gz/4OpDqOYeJeCuHHm84jc+RVPBETQYgSRSr0QAWiRaqhHG8IZhZ7lwWDakElZE5WI1olI3Mb8UZrJxZ7OCqoTcySzCkScrZhJVLKDWXEFPl+QZOaSjTP1qqfSNIm7WVTo+9MBUNSKvNgz8rc9oJU5ruFfGTMKY30AQ9ftEdQoSdO+2GZlNS6Gno4wGXnNLjsB/fjYY+fxaNfuwqH/skq8Ooac0sD6BFE8BoMjXEZ2Qb10GiMXA88NLZPVoYxYIN6tYqVJnHCg/e86EDkEBgIOyYiuMHvb7wFwDOy5EBpAPvfet3t80CfoSaUZZU4oyhKmlECUWXHQvNXg+euB1WTkZQOSvq13I+XTc6gorh7Oa7nClmViiQLzm8UAWwFGIlZEEayTCoM1VqsAm4rPFCWiSQ6nxYWieRk1tfGgyXe0KJEbmmFufcN4vpi3p5wYXmkvHoUrx1HHft8m4el5aasxlgGB5J1PZLBHM6mbJNqTyhWwjMfr0qWHgQ5eGbG+yiL9sU0jpi0sgI3Fa795SKu/eUcDjle4ZGv3geHnrEavRVDGBZBbAxGbDBkdgHMAcAaup6ZmNE1jGoNQF0CjygbqeXmeJK1R0KTosatd2yO9alolOukDXMX4qaNu+P6U2IAReGEYGKQmgQWrgcv3QCqJssmDkXn8cJ+QlKSmXTJuuiZg5ahECVWI6WsjLIYG2c2mFn5zIK4wGP0ovz3xColh1ckep4KRMk9YPt7RNCarGQG3GaSW9QIP6zcx6LDDyW2SUX0eMxs1mA8+pw5HLApmWqnO7elEVtegnNpDiwrKKLkmBvPeJFGBJSYnxGhPQEXj9VXEFbijaAmFZgVNl3Xx6Y33oaHf+8g/MV5J+Lq4U0AKzsLNj6IfRZm9z4wYmDoDqmuZmA1oCYJZsCh5uXc+0pkYYjXjhlAp4uNmzZDaxMIHR6SrOVT80Pizdt6liUStjhS9g4BYDUD9G4FL99kA9kvNEhB9Nz0g8fQj4SEZ/B6TVwFOCW0B9uNAhTAKRGfmNuKmxnyE/m9nFlgpCWytA1NyBIi88pDxH9eQjHRjUCcsBkXmikGaMuLKYwXlJgvk6toMhF6plQiJzx1yioJUVmUlCukmTpke5P5DpVUMMI1M0IIgTPGXL6Vzi3mWEK/dOgtZQofkVhqEk2ttEpKJXfTkaCl87K2v6OenETTX8IfPeskrJicxGC2gaKOK5Nd6cwGIyabeQ1jYBgDZgwc7rs8YtBKRrWC0MyRjNdiIFM2EGUAqGts27YNS0s9rFo1E6pXzntgUjZm79vet5rLcvoi+LmsJoDhZvDyjXYtECVnvsiNbkuqtB0Boo1k7kfD7fUyFDZr0HZ3o1wGlTnzEkrZRXnwcl7GMdrieLlMCnMrIFKOjXLSP14XS14zJfgZgugSMrKK+tWJf44bQ4QXSqEtkZPB3i10Pa6B5qQIGqv+KL9uksDxWY2D6IFJt4IEX5uRShnnwzDKW7DMjrUtFcUJ/1zKBxG4YGmDzI1DQRFDDwY44pjD8NhXHYJzdl+AijoYGI2hMeFtxLC9sAGGDAyY0DeEARPIMJQGJlYqqBUSpKJE0cWLO3Br6uDumrrCjt2L2LFzzgawSGK1HDArpbDYa7BjdghUJFT0BYtJTQCjHUDvuuBJlOr8ZLI1LUsOlBk+ubeqEZzVon2HeKJGnED52lxEZtLeTCK9LkNQYQVNjjzynek0wzLaOE32cxIPyKhztsQWht+B+6wiGAhjPw41p4q9s1Ii4B1hhjMBBG63FkmFkWAPDrE1MWNSUfGiJFdjEtnX+Lp50XNJRGurkVDh0YUWLsm0KLQlER+Jq5iFgTsJsDSoZgrLHgUwD/AXf30a7l6xCXP3LoFU12ZdbTBwGbgB0BjCyDAGIAyZMYANZDYMaEBNKajV7YU1low5Shl0flbPAKiqsLy0jF27d+Pww/ZPt5HyAmQwMhiMmqg4ydr56sIuJphlcP/6wHkON3s+6sgWC4jbWkks+12j2xsi3v1NqiqgTE2MJ7G72RmptDiXDblyNcXoeyOzRqnx5uJIihNhrTHMY8lZ5ujEICuZUNGQcR97a1MhH8QcPKH8rJtFFpfMMio6bkR1i8huKvS8LCVpkPa6EC5/kkSRkDqteicp62MVvj+RHJZkk1jeMgsEXMrTEkX2JiKxKFmbFPVqQjQpvDby0apKgfsDHH7cgXjI89fh3O1XQ6kueg5tHjqyxhDAiBncVRgYwrCnMSCLPA8MAEPghjAxTeisVSgMS2MLBBJjROXkqhTCTnzTYHZ2ocXhSzIwQFhaGqG/vGx3gP3OLwBwbW/MwY0AjUBUZyqDJE52obSHkjKgBDO03IR0ItlxW4S8NWPY9aDk6SNfA/U3gegbpchcVApRAjk16Q3dkl8ByruIlJEbhSJnhpC3938lmAIhvOfJMuJFVW4NLemJVTRHJ3aZmSJ9Eio1WGBOS9EiuwlBBcV7B/msy4EAAeTib5wAfwxFZC1DmKGbEXjQBwYDoBnZe1IJ61elHChmgGYI6MbZuVZOC7wD1ek68MbAsG4pyoZXlWSfHDGYCApKNDuvCCUluAYbjVe963HYNHkX5nf2gKoOs96G4Wa+gJlUGF41wGi1gn5Qjf4ug4EiNIbDgdqrAVpdAdDtQ4NSi1wZOXFsrgCjMTs7GyY4rApzYABYXG7QHwwdRuKi3/duw1vBZsHNek2CtBLLXdOCHSazsGCMp64ihh4O4glvGkA3jjSggw4vezGyTKrV39Cq23XrISmIFkplYiiqQIqge8uA1jFzsU7vCFNyrhuz7MsFtCXf7inJwvqbuK5AdQeViopXvswMJZU2IQN7WqRfsg+PNxk9KDHqK5ljlV0OKCufyZj08Mwys8cM/OGoFMEYA7Pcg+kPgEphZt06HP6gg3DYQQfgQYcfhMMOOQD77rMWK1euxMz0JOpODWZGb7mP2bk57No1i3vv34Y7Nt6D226/A3fcdTd2btsBMxzagJ6eQl13AAa00akSixQMZMoO8wyM97NqEq83AFUr8FIPxzz8YJzwgn1x5o7LQVUHA2hHp4zBq2tALRGW/meErT9cwOQH1mBwxiSazU0gxDQjRq+rMLm2dkzqdJtILvK3KwhBPzaM/nDUmuDUnCC3sI05VDC7ZtOAuAM0dwN6azTBFh63lM8OWytgJgSoJZXDZvjhCHowwOo1K9CpXEY3Q8BoKBIkdJ+RySLlJPvIqkLTMLbetwXoVqCqGzJZXrAY3Qf6DTYcsB9Wz9Qwxp7KbHTwg5XgExsvJkbCD4fs97ty15e/JMo4UpEeSJSWy8o97uFwhIWlJcwt9NHv9dD0lu3zn5oCJmdQ15UNBiP645B5HZilVFYhqLQP9LUQtfdnkzMpGRUakBEVEVJjL0/s8V9X7uDRvWXopUVgchLHHXMknvDYU/DEx56ERzzsOBx00AZ0uzX+t/+xYWzZsgO/v+EmXHLpVfjpL36Fa66/Af2d24DOBNTMNJRSVgiO49qIdQxx+IwkwCQE2mzxwR9iRDBmiJe87UT8vnsz5odDqKrG0DCGbGzZDKAhALVC71cj7Lx8gP69I/RfsxPVpr3AL5sGL4yAEYEVYQTC1P5VlEgqikdSiq0kEI79fNOY1oS2Vm5s4eF0w1bq1bbABFJdYLQT3NwNUipZI5QL5YEg726IRAXQqx34sowAjEZYPdXFJ//5bXjyaQ9HraowFCWQ3ThU6clqk5ByvVI8iYxhnPPjn+MN7/hH9E0T5qYBYFIVYIAVivAv//Y+PPc5T8HUpCWdKCFxOoYt3B5ycNt5jyT3WCpljFH6bBrtgIk53L9lG2697S5c9dtrcMXvbsJ1N96CZvcsMLUC1fQMwMa5QDrT8sTK02VbqtzoD2GCQAn5o0BNRIrQhr1Z2f8a7aofYRQGdtmWoedmAa1xyIMOxbP/6AX4P895Gk45+eGYnOwkV1Jr7XraiCq32egCMyHbi27Yfx9s2H8fnH764/DBD7wNN954G3583s9w9vfOxVVXXQOMGtDKFVCkLPk/tCEqivSzEI3wSzKCVccuURAR9HIPx550CI5/7t44c/vlqJQVqRvCjYd86dwhVLuA+V8OsHT9sjXcY0B/eBfoxgb0kdVg3QALBFNVMPsxqOOwGpU5XiKqcfiKMiGtuNdx4DNwqQcmsQ8c55rKlrDNXUKgLkUMOYP4/aihNY4JLCeDihjNwgI+9P534mXPfzL+b/z3Fy99Nq6+5mZ89lNfRL12jS2vXGVbKaCZncO7/+FdePUrzihrYP3/9b82fNTt1piensDe++yFo446FI9/3CPx6lc+H7oxuObam/D9H5yPs885H7fdcDPQ6aBasQLGNH5TVOiPKQEyQhxePuOoljIIEn6aJzz48Z2GNLP2nj8+eJUTENCzswAxTnv0iXjtK/8Mz/yjJ2LNXivDb2+axmmr2UBSpFJJmJZLg8AlEplVA+Nar7qucNxxR+K4447E29/6l/jFL3+Nf//8V/H9H54LPehBrVgLIqtn7oktSRALIzvO+NLB9qcZ4WVvPxk3Td6MxZ09QHUxAKPPjD4YfTbQbM0Ehtc0mLusbxlWymIOqCrw9xZB9wH0r2vB+2pwn2CmatAEAX3bF0eHDpKLCEnNGOPZft9o1LTO4Lqo5qK1veupBjU3gtG3oJVHQBkFYbQUkkdh1keun9XaAFMTeOQjjobWJoywymt5Y+h2IiaaRqOqKzzk2EMtEGIaV7LbbzRNA6gGjz314dDawGjtei+BgEGhmJpKaXlPhlN7DOL2pxjRE5cJ6NQVTjzxwTjxxAfj3X/9Opz9nR/jn//ls7j5+huBVWuh6soqpEDZSimhYopKWcmCURUepECNfbB6wX5OlSt8RlaVgl5aAHrLeOzjT8V73vU6PP2ppyWvg7/hqqra4xWIGUfq1nNrDkoKUFyF81ZrA2MM6k6FJz/5MXjykx+Dyy//LT7xL5/Fd75zju0LV62x7YfH91zARFCLsw02W4mZpR6OOXF/HPXsFThz2y0g1cUyNAaG0WftCBoM3QXU5hEWLljG0i0jSyk2LplpAuouzG8GoDO2gz6+FuaPCM2MhpqsoXupvzWSKRgnUGpbNaa93aXKy9UMoAuY7WCzDaRqe6DJHdTSK8Op7wyysQRLhpVygVepoJxIrn8Mb/Dvx5PIjxrC++6tUkL21ozAZgQyIycHZNyLb/+eqlRAhol8WY7C787+bvic63mJLOJK1P6esDhBScmf/Lyyj7uqFKqqQl1VYMPQjUYzajAzM4VXvPx5uOLSH+MDH3w3phXBLC2gIgbrIUg3zlhaB/QeQu8pzNaROdRnyoyU+9r63+dVKxTA3EBv24JjHnQI/uvrn8JFF34TT3/aaTBs0IwaZ4fpMi09gIAgpKuGCKjEfUIwueRGFwF1pcCG0TQaTaNxyikn4uyz/hM/+cl3cPIpJ6CZ3wGjG1QE593bgE0Ddib07D8Wptz2BhniL952Cm7q3I75QYMBPLPKYOAy8IAYugGGV44w+/Oe8xtwWdUdFNAEdGrwFgAvnwW+rDE6qgPatwaMcq6bJOb76avTisjclUEl9VUGjhKBqAvoBaC5I/Cf2S3tU7KrmvGaxUghGCALBg75m8M0LlOK8U2ppKV0c1SsCWUUOpH9YX8/uSC2VhiNmK1mY69cEpU4JSjnj4ty90MkBm6QGAGhhThKumTys6J/VpVC5UCsZtRg5cppvP99b8EvLjgTxx51MJpdW1HXFAPN3ZD2Y3uTkncD8EFshDKjcSZdxv+8LnyvPRjqWkHPz6MzGuGv3/0GXHHxd/HiF/0JmBlNY906qroKh1WqUe1fK87sWdGWF2p1HJRogyUUA28ZXdnDTzcautF4+tOejEsvOR//+E8fxKQaQS/Ooa4UAHsPEMfDDtyEKYdSDLO8jAc/8iAc+dwVuGLbjUBVo2cMBmzQMwY9ZiwbxrBD0JsYi79sMLzPuBGfinLIVNlS2BDQrcGowe9aRPPOAfSyZVXZWb0K90AyGiUVl4BI8tS4yDhTLY4wA6Q1oG8F0A83HWV2o8WbW859M2J7lPPU8WYaV2xmu6I0zq8ns11kbgD4Etq+ETeAGQGIurq+/+HkICBBeywsoY/Vr8q4zJkKZbJsMW6PNT8KOIp8V3UFZsZo1OCRJz8MF//8ezj9aU9Gs2sXqgqAHoFMY9/0CKxdxvE3ahasyfsueMlnKZfRYRoQMRQxmm1bcPKJD8ElP/0WPvIP78DKldO2VAa54Gi/biwPwpArKEmlTGPsUKXXMpA6WALJ/RgaBKWglILWGnVd4d1/8xZc/Muf4IQTH4JmYQsqL/znnps/5Owh5d7XPbz47Sfht9VNmBuM0GdGzxgsG4NlZiwzY1gxmj4wvFRj4aKBwyJUmAwQVS4nOrCRlW1FJ2vo8xroewnoquw5pAyFIDNLJHIVF+Miuk4nsq4GrG8DeA5Ane6NcyYO0drI4TQRMRKPmbDZ5EkaNFabIFvho/aLXEBU7YExsgJ84Yb17zfpTFSsF7bHvOXMuyc9hfJ+TEq/zF0PWyi1pIFm/9V1hdGowd57r8W5P/g6nvmsp6PZtQ11RS4Dj8As2gYnRGhv1iYEK4usy0lwu1LaNLZkHg6gZ3fjjW95NS766TdxyiMfGkrlqlKFwTiLRQqkAocPjAa0g5kK9EdBbeXCfF6RcofdCCefdAIuuuh/8MpXvgp6eTuIDRRxPNjcmyKG6S3ioacchiOetReu3Ho7UHWxrDWWjcESM5bYoG8YulJQdzJ6F/bQ7NR2upEAiRaXsFnY2eTCva2oQZ1K+EnHf/N7IEOVsvs7vSwqv6xK9UHVTjDVSTBRvq8ouahyKT0z9E73bKUafpTI5LEZj1J7Q6Jkfc+XqWGxntgGsElvXHuTDsOYa6wTfVGfOs2aVPqaFBgP4wpuZxNJ7i/1PPn3c7r716krNI1Gt1vj7DM/h8c87tFoZneiUtFAi33F4YPYyGwjSmaO2Yddyc2mQVXZPntGGXz9K/+CT33ivZia6EA7oND3+Hls8rgQzdcmS9xkEodpcjhT+RojvW8S7IsIdV2jGTVYMTONL33ps/i3f/s3YLgAMxrYubXzO4rtwwgvfecjcYW6GrODHnpssMwGS8ZgiQ2WDNBXBJ4DzGUNlq8YRunkMJd3Aatq+0aV+LyyvS9FvnUSxEkhSJkIAieMrRzbUnnWqxSsZAdRJtOAwmobFXynpXeQKJkdKBLLaJ0YZUMu2QtpBuZ2uicnySJ3mO0J7LO9BrmsG05cmPaNRdnNMw5RzozEkuBNLGnGBLrMurIkZC7OnWOfnaKyDKCuKmitMT09hbO+9XkccNB+MMsL9rmbGLDEsRyGA3DYNCAfyDoGsu8F61pB796FQw/YD7/86Vl46YuehdGosUZ3olzmFmiZ2l7ymOzLycon7Tkry0mGONiigmh0E0laSWHTaYxB0zR405v+Ct/97pmYnmCYfg9KVbbSIA0zmMeDTz4Q+zyjxm/uvxmsulgwDRaMwTzbDDwEMCKAb9LondeHWWSgqmLQUmWRZeWyrQxm8T0cAjoWxyQUa3KZ4tQ1k1qCUFRCodODXyoGiJWrUtmXcJ5NMktkF0gkEM5Uz6qgxFhi/5UCJ7lxnPCnp2CaFI1VlPW30lOXqBigXPp7uUMgUTr1YoZ5oBJRuq0LgkRiNCZ7aVE+VpUtpw84YD988fP/CjIDkBmBeAToUUBdQ/XBjfu8A/Z0k4FdDepKodmxHQ958JG48Pxv4KQTjgtKiCQP6nwnpYiDUJsPLt8fN3ijzHmjoF9NWf/mGXNsTKRVhkKRUKkKo9EIZ5zxLJz343Oxdu0UTH/eUleNBniIl/3N43E134mlkUIPjCUGFpnRA2MIQtMlqN2E4SVD9H43sIHpARTH52ZV27GrL50pDd5QUlMVs7bscn0lOYZ5K3coxbe1A5jZO9nnfwTZIhfaywqta275y1HlwoQFBrAONLzisn2mb4wxDCn5GaOdFWRQ3M9U+InG7xHlQSmF38cEdzm7isX6UtBmjKyYXZAORZPWAIlvleyJ/+jpT8IrX/UX0Iu77E3JDcAjF5gjW1LrJlQlZBowuxLb9ct1rdDs2IZTH30CLjz/mzjisANt8PpZLmecb58piFqZuO1cQwUEv3VPtoOYMymjwkGhtcFg0Edv0EN/MMBwOITWulVldeoao1GDxz/+NJz/kx9h331XQQ+WwI3GCacdj/2ftRpXbLsNXHWxyAbLYPQJaKDgmeB8Y4PhBYNA2oBcPRRByr6EVlX4l0JmrkPAhyUVlEtjSYJq33MYPwcO0/PW2hkV3SC59QkuKOELdlYgyEPYRGTADWcneEsrIFfDyPpxbi+dB7ZRMv4q9Lw5iFQCz+SII795BXjHJS9f4b9cXEAX30ug1nGcrP8rOw99/9++DXvtux/0oG+VhUMv7IPY97jaldFNzLw+eE87Gef98GtYv+9aNI3TIJabVZmmGeWBKcGrsmWV2y+2RAzdNNBGo9EaRmuYkEELVV7ijYUw05+bn8XsrgXMbuth185dmJ+bQ6/Xc5TKVG21riuMmgYnn3wSLrjgAuy7375gHuBP33MiLhz8BrPDPpZYY8kwlhkYknVZMB0F2kLgC0cwNzcx+/pxD1WWyBGyrntT8V8mF9CkANjvZ6rCISCVWXJDyigCXx7BqeLsNaBr0ZR7nA5Z4gKQgVhBzRCCyCEX5sdymDiz7eEycOQVJksZWfrjtGaQ1O5BCyV5MYhLo6EsCwcwIncxK2UjSedKMnEi9pwavbn3rQWsxgEHbMAbX/8q8GCXu9fFrNPNxCHALRaAVTO7Cw99+HE457tfwpo1KyxYFVhUhZZj3LUYQ03zfahhA1IKqqosaaXTQV3XqOsaVV2jqqq4gqg1TPAnoXTdzxFhdu/ehbs33oM77r8K1y1+F/feey/uvedebN++Df1+v6ihUCnrYbRixTQOPehQPO5pj8Dap0zh2q0bQVUHS8agB2BIrlasCdAK6gqD5md9O+8NIoOxr2VZIiv7RqXyWVUu6/rgV8JaRaHAuWrrIGZtTJ2c9L4MVMpupLBQ88+a0XzbBw8kt5K9n4yd8leeqIVQxpVFGstj5nGFtsvi4cak8f1bcJAgsRCQZ2GpNZ2jzOHOFQdM4g9E7d6+Jfwn7IV8ZitQTJkQbvrXv/YV+Oxn/x07dy2CuhPw4h2JFanQyFJVBb04j/037IMf/PeXse8+a9A02rKcWpRW2vP8OzNdY7a+uj4w/XVfWlrCvffeiy1bt2BhYQHDwRB1XWP16pXYd5/12H///bFq9erEB7dpmsCj9qDPcDjEpo134eabbsPaJ/4cV03+CHzbc/DQ5Wdin0Pm0ak7WL9+PTrdrjBK51ABfP7zX8BosIQXvf9U/Kb/exiuMKoYfQMMAGj/RCYV6lsJ/LMeeLO2eufsSmBl9dADcSNkYjdOCtRNlRkaIFMVTgxGs9Y0lxLKR5BATakxhdtx16m6I1CWYUVBgZ8zb1iWa2np1zmZa5GwX2l3urSH7Ehjklo7wLnck+YgVBFqEcLwivZQPYwhlLnnrN3qm6oqscGUv1hOOpfSiiQs+yefJmitse++++C5Z/wJvvD5/0A1sQ+0aRx1nZ0KRiSxkFKgpsHMRI3vnPUFHHboAbZsriormcDU8uHhvGwW5uWS/q6NRl3XIQgvv/w3+MUvfolLL70MN954E+7fsg295YXWlZ6cXIF99lmHY445Cqeeeiqe/OQn4dRTT0WnY7eamtEIpBQqVWHz5rtwzdU3gPa+A7v3ux2Lu7rYeuCPgUvX4Ij+w1CpGpNTk1i7dl3g2BttUNUVLv/Nr3HFpVfgmMfsh7mHb8dv77sdA1VjyWgM2LIgQQqsCNRXoMv7aC7uibGQcpm3cmyqKpTFoAqs3OeTZKQSIDC/xYkegCvE7S/6QrfOZVKNMW68gFbQxfLYtMsqv0LoLRzlorQxiVRNEFpvWdNlfXDyedoDCs1tTrYI2sB8cb09yzI3m8tShiy3CnQi9Ho99Hq9iLeIjEVjstXExCRmZqZR13WSXWx2ola5mBh4UTa6KfDRmRkveP5z8YUvfNkubzg2lFxC8eIMFYBmYTc++Z+fw6Mf9YiANscDNJHHT5w4ZODm941yM9jFxUWcddZZ+OIXv4zLr7gKYL8GVwHogNRM4ITbhMHo9xts3rwZmzffhZ/+9AJ88IMfxvHHH4+XvvRFePGLX4wNGzYAAGZnd+O6a67DPVtux8OedReu698Hqiax4UjCbbvPBV82AzXJmJycQqfTxcqVKwOnXmuN/7ngAqha4YSXHYKLl67A7IjR69jed0h+tRZAR4FuYDQX9sC7DFDX8RpShjR70EpkYZJEDd8wurVdFsQJKp/0ol7j8ZUmFRQ5woJ3Mh4itJUahVJhIsPi/jVyHzj9l8MigfT2ydQF87u30D8mpoaAs4FBIsRHIj2rBGiJzhHjQawU9dNNg7rTwac//Rl8/OMfw8TEJBq35+rX4WJfg4SQMDU1gf322w/HHnsMnvbUp+CZz3gmZlbM2AULJXixXp+KYlXS5kRwUk5VymbzRz3qZBx62KG4685NUBPTdpyGKLfDTKjqLpr5rXjpy1+BV73iBRiNRqirOkN6KbkWVDooxVNsGrvdBQBf+cpX8ZGPfAS33nqLu+zTqDrTTtsqSqaaTMieqhqEjl1eIYLRGtdddy3e+c7f4Z//+eN45StfgXe9611YWJjFLTdswiEn97G04R7s3j4AqQ6qZgrTD1nCLXf+HNUNNUgBkxMTOPzwI9DpdlGpCldceQWuufJ6HPfEA7H4iGVce9dW9OsKi0ZjIDeAOgTMAfzLHsyv+84myBMwfBauwcojy5UFqki5MZJK3AY5A+PC60ictlecNr158ObYctCFbpWkuXIDZbNKzuVYoh6yXGhoC3ynHGnKSRVRwKnNRCqASoqU49xScYODxtfDYlyBlut5TibIlYt3796N7du3A/DSQlLOVaEsC2Cw8c478OvLLsF/fvmLOOrIo/Hu97wbL3/5y2C0BsldUMrtTAWphcpTNm4aTE9P4wmPewy+eudNUDQdZ6PulFOqgukt4OAjjsQnP/5Bt0GkMpubGLT54eZLa5YzWGbUnRrXXHMt/vpd78IFP70AgEJVrwBAdlvJ6IQPzUl9ToEbzZKxR0DVmQGRwvbtu/GRj3wE3/3u9/F/zngOplcCe582hysXdoFUFwMYDJpl1N0aSyfcjBtvX4vurTX22msN9tprHdbvtx5N0+BHP/oRFpcXsM8Zq3HhwtVYZNvzDsNqo3v96gq4sQGf3wMW2cleuIPZSyGRpEzWFllWscymAh2XKWIiXlzWO55wgvlwyMJUaMaoxYXOT3cjVqzG+fxkomhoTYwzUqcx6UYKcxtVyzJy2tzmMyvKtoBSjWXiAucAeyIhcDAai9lHoMly9uZWIDudCSjVgVJdUD0BqieguhOgjnybhOpOQnWmobqrUXXXourshVtvuwOveMXL8a53/Y0FlLRGyaAvn64yA17ch9mOo5jZLbEDj33so+GlkKwckmelOYHAZh6f/PiHsHbdGhht4h42Uq520U9QroIbDnu/n/vc5/CY007DBT+9AFW9EqqahjbW3Mvuy8T+kAtjFqhOgtYy7JtmhUYbUDWBursXbr/9Dvzzxz4KdfCN2Lb6LuzuDTAEMGBgCI25YR/TB9fYctrVuHduM+66/W7ceOMNWFxcxBVXXoGbrrkJRzx+b9xz1BbcuG0bRpVCH3ZvmL3QYJeAnQRcNARf37cBK7XHEemREmlmN+8NQayc3a7/PlXFio/IAV32YJDqHMURnFAhzSM4WKsYefq3CnMuzIVdECd2Jun2UIzBgmutEIxLKJGU+dwAwm+JhWpjtBqlwoIyJ6wdt5Dos5xgBbGkNlKGLLRALkoyT9C/E7I6xlCh/xE+To5UojozqKjGxz72UWzYbz3e+ra3QjcNlCBPcLAXQUJAYY7qisxpz/qwhz0MpCZgmmECnFRVB7q/E3/yrOfhjOc8M/TfEd3fkzABJ7N5bQyqqkLTNHjd616PL37xCwAmUdcr0Win3RXKToqZjeL8NJknJ6h+zuQjMDSMGUKpGg86bgOOO2MKv9p9IxpFVqfKsPUoYgKZDlaeMsJNOy/B5O9mMOIhpqam8T//8xMwN1j/vLU4Z/F6LBOg2QTnV1eigIwCLmuAny5b8asqEr9JuTKaKKDNJILXP08fpCRYVunSh2iDyICgYhsGLk/qpOKmmGSoov1Jbi9SZEJxqiWfe3aJm5cK2DCJxe+U7USpUScRqESlRJTz4YLfEmXWHczsBvxItIeICzC9NE8r7P0GRpdHGCHKKuWG9IGRUwPUEQN++zXDBM0aqprC373/A9i4cWNYHUyNI8ix43zGdRN2ZrspyAzDsSw9+OADsW7dXpYyCbgd2AbcDDA1sxr/9I8fSNwiQpC1TMCyQYMHnYylci4uLuE5Z5yBL37xC6jrlVCqRuN1u1QlmEgdcS064l/7xtQBq471kpZfpzoBh0AdGMN4yXtPwtZVuzDXG2II49QyGEMoDImwaDSMmsDSqffjhunf4r47tuDXV/wK9228D+sfPY07DrsbN+/aDtNRVuTVH8YGwASB7jLg8xeBW3tWyMJnId//hhtNlMvuayzvAyix2yu0vkPmpcRmJ+F0t3kzrSlFqAZbMz8vpp1YbLSzb0qqiOMcaS5F4maMbmxuHKOqVHYls10JAt5uhpmYdu1xpSg9ZGRi9QFMyYaLPOWkgRmNwQDlVY2lUmDXJBspHXGzirLRfZ9hQFVdLC7O4xvf+BbgRkLCbShyq931MK7D0QbQTNCGoN3XtQFWrVqFfffZx00zyckVAaaZwytf8TI8+MHHQGsNVUUN4lghCBINZ5YnDiQkRVhaWsJznvNs/PhHP0KnY7Ou8UL/PnBdAJJ//lXXvqmuCNaOna2qrvu+7GvuuqlOF2ak8bBTD8FDnrsav99+N1RnAgPnBGgtTRh9BvpgzA6G6Kybxr1PvAk3bL0eN1xzI4xqsOqZE7hs9yYMDUE77Tdmp5ellN1YuL4Bruq79UwT9JqTdi5Y3EgrWKeLJYIaIqBJzIYpVLoq8bNiapdBtEfCQ6B/cEJ39t67e3TkS7ZkhKKlPMiRy1qx2DLJ+YEx69kNDbnY3O63/VZLyQk0Xm+KFl4q6jRxRt1MFq8y0XgqDpY5mfHBjRaI6jTzVP4mjVmHqGNPdreVYluCCVxwwYUwxkr+xGvoKgd33miXcTUzNAONsSLj2hAaAwwbg4mJCey1dm2gIxAA0/SxYsUqvP3tb3ZKnCQ8ofJtsxS7TLXgGYYNXvTil+BnP/sZOp1VGDUmKlEklYfLsD54ZVCGg80FblWDqzpcJ/IHnv99XIOUwis+cCLuUBux1IysoZghDJ0b4MD58vaZsQyDub6GOYZw1yNvxp2/3wR9aB+3H7ULG+fnoaoabEjs3jh91jsN6JIR1L0NJqenMTlZO4mi6MfEaJkGJYEcy2tb37JXx0y+Hj+2JbcStMo0mB/AFdkROaRPjBwREWc3dD5fTQOARLojcTC0CBHs1OW5MDbKaMEt9cL20lp7DS9ht0Qmd3lGy9l0isttf4keTc642Z+4SqVbKJ70Lnq7yLCyE1kLSE3g5tvuwLat27Dfhg22jwxFAgWgitmalBj/PucaAAZTUNhrzSr3+AwqqtA0I7zkJX+JQw89RMye47wxMZmDF4OnBKOwahc13vzWt+GHPzgHne4qjBrdQmVJdRyQ4zi/8Gt2UlhO4AOUk8hN8tpVlYJeWMSjn3EYNjzV4Lytd4OrCn3WNvsaa+U5NMCAGH3DGGpgpDUMKfAzBxjccg82PGUKv5i/Ncxhgy0ruShYAOjCEegXS9Cmj7/5mw9hcWERH//YR1F11tmMLYDFUlohpM4Z+X1JiWl6nkhcO0cq+i0X+1P5IbsSOm8vc8e/rJwOYU0FZjSPKwA4m9FmWVgYVLX4GCwH4DR2utTGbAEq1hCUouBylZEfiD6Ys65J0Ock77V2JAq5SuZ75HwUQZifm8XOXbvs7zSclMqGAe3fjM+4jMYAI+2MpXVUKep2u+5RGmg9xNTUGrzlzW9Mel+GHCVHQIlIAlYUtn7qusY3v/UtfOqT/4q6s8KKjJOQj3FZl0XrwL4Kocpl19p+varTlsKDQEoFvnAgQzChmqjxwvcci6sHt6NvrLRr32XbAQMDTegT0NOMnjZYZo0lGMxpg/tpgOb1BncetRs7t89DUeXuKxXv4wkF3GqAny1Bb1vE3vvsi7e86U147Wv+Et2JKZhmIEZ7UrQxsaZL1w3k+i0EoCU2BSAFD4tZioqypyQKQDV2LxNUpnJJznNrKpVIcI2hhBUKAW5THVNMhcNoyWciLv2NfNuKqJxp5TZSOJs4ns5iy4jRxgEiV1dyXFUGaFEEdMjeoEl/5G9+WZ66CDSw+twarlw2BMO2TPZvIwM02gZxo+3X/PUY9IchezH38cfPfBqOPsZK+JJyM0+BXQR/RbmM4j7wEjq33XYbXv/6N0KpCTtl9DanKs5Cw6GVjIhcwFIMdKtyqmKVogR+ILAOVVcwiwOc/oIHYc1jDO7cuQOmUlhmjR5rLLPBgKzmcl8DfW1dAXtMWARhiYDG1Ng8M8RV8/eAqomYeZks4typQPME/LaBunkEBuNd73wXVq9ehcOPOBxPf/ozwHrRvubSFsgP82Q8EDJPbFE+B2Tavv5UWNNFJnLX3gto0yHasrJCLQAty5Sc+4yMGy1bY84VYVp/hwr7oSYj0bMYCzP58dCYX5qXNGGhguJ+cvi9GdFDot6cZXrKHSJozImB0AOhxcCJQt7SVtI/6ZmZlVizZq+AJWgmK1zCZPtdDdf3AiPDaDQwdG+Ny9jaZc75hQVHb7Qfv+QlLxLcc0pP90xdI5EyE9fnLW99B+Zmd4GqCfcapUQGjxyzklVHvi8rb+gq3NCJG6NoT0xjMLGqwv955yH43dKtYKps1jV22X6ZDJa0xpbLBxjUCgMC+gZYNoQBCE1le9DRgKP9FcnnRuBaAdcy1M8G0AsDPOjIo/Da1/4lmlEDAvCav3wVgE603hEmBZzIJ2dey0JaXxquJT1w0hfHG53zvLmHdk5RCfZSqrCWl+81jFGyZamxl+7yprGpUpmWEgHDESvSc0Jkzbw0luIhciqUzX7TkzRVqqXSi8Ep0Ge0KWw9cgGl5/bmVa4ASgTwCAcftD/22289jGEYQw5lti4D2jjASvs3wihkYRvU2i0p9AcD7Nq1C4DCaDTEIYccjic+6YmucqjSGsRdo3hAptnAz3u/973v47wf/xBVvdJWCaRSuRg5MvNL7J7sgGiaLf0iUsZZFFj3h6WqFHhxiGf++RHQD1nAptmdMKQwMMAAhL5WGHUJO25pcOc/zWL774ZYniYsGWCgCNqzqxwP2jOEYYSm24QCtgG4YBG4dhEMjfe//++wcuVK6wZhGE960hNw5FHHwAyX7CZhZnlK4vFzZk5eLIp9JvaHvARci7GSiUVm/ynOlTRACSE7zcZIbSl5DytmnMLdLcfCwp4v+3kmU5YJImBgIATm90Q9yEZjighVWCSQurtl3J5TDkzyt6zFCVASDQiud4mggVAGCWWXfV+RAtDDY097DDqdDgajJva6LuM22gaxD9qRBkZNDN5GExrNmOgCiwsL2L5jq1scGOJ5zzsDK1euDBrOLNuTLHrjwWi/r1IVer0e3v/+vwehSkTZIhNJiLi5rOsZSaqy/b1SSAg7XmyfxWopEuUUhhlprFg/jae8fX9cPXcHjFJY4hGWjV086Clgoa+w7TIN/K6PuQ/PYa6p0KsAU7NwCIlkkuC0GczqK9BVA6hL+9CjAU455VF44QtfCG00Op0aTdNgcnISz37WHwHouwPQiJGpP3hMq61kl1nl4gyTaP2EkQCXoNnE3ji91zlXpSSxME6UblBwgSQZv3nMpkQuvs5cLHPTyQyl5w2T6HVdX5jFS6sPzv8Ot7c8xvbDoSfm8leLmrK5Fhi3HQ6cdCsbIZouPI9Za4A6eNGLXmAXA4zvdW2ZHLMt2fe1COTwZqmUkzWwbetW7Nyx07oZgvDHf/zHIRMZkyhvIVPiSvpgYzRIEc455we44YbroOoZZ7Am5WOqLHijEiORglnS4GWGGTCIhLhgImyog5sEOU0zIoAXl3HGaw9D79Dd2LqwDI0KPadVtaAZuxVj240jDH/TBw00+IplmG8OgQMngYasvCsyMQAVXTMwWQH3aOCXfWDTECCFD37og9YdwxmnK1chPvs5zwKpLoxuohOnEKvgsRWd5JSL+W8BzIIEtZK2lwrTkphlVCtheydBoj2ux7WyLBc40CihZxxLaCG0HiAw1wcbRAnWGLhuLuq+30j9NyArNdq9Omf4NDOHbM4glyApHB6tkZTQH5akl5T6F1X/kQiJC7lbd9PWdQ093IEXvejP8JjHPBqDkUbDypEzEAPZAEPNFnHWwKjhBNDS7vnVAG66+SZobUUEDzzgQDziEScE+5jIn27/G0ZSzkXBqzp+9nP/Hum1EpwjEbCoEtKCIoAXG/z1B47A136yNx70UAbPNqjUSEj9WpE9CtrV9nAjMLg/xN6HTOGxf7UPrp69E1wpLLPBMgOzhrCNgF2zjN4vGtCve2B2B8g/7Ya6tQOs7ljtqlyU0ZeaFcBDBl+0bLNvM8Sf/Mmz8NTTT3fbYZWr2izF8cQTTsQRRx4NM+w5DkcMWkq28CAkj1NKUBrWKTU1+lmnm+f0QHNMCjbeOYme2zI2pdFP/vkWBW8ckstusYOS+Wukg7pAhktYbqRibzRHIxTo8Z5OK8jCmyjBy2Pi5PQQkds2YVVRrkXn5t3cdj4IN6rQpxZi4nVdYbR0Hx5xwiPx6U/9K7Qx6DcuKDkN0JEWyLOxJtONHzG5kaHH1X592eXhWZ9w4glYvXqVlbQBJYeeSd7YoeD2kNRuS+nXv/k1fn3ZZYCajo5/weJUZRxnW5lVFUHv6OFV7zwIf/rODiYeN4c3f6OLA4/S0LMjKBoFNwk4qdug4cXaztV7Azz3Hcfh/vXbsHVxGcvE2G0MtjYG24zBYs1obmbwRT3wXOOefAUzN4J53f0AJkBK4C9KBLN1kAPd3oB+uQy+r4+JySl8+EMfLLIDmqbB1NQkHv/YRwNYhlJVKhNlhJujaPDSaU7BBFAkNUroxDR+cJMfRuKpjZ13MrdnuDSuhBynRcVSmKu8JhiyIMdyOQYtQtCaQG5AskXSrhY4mw2zOLgoWXqKaDeLkpLj48kOM6/fpJxChFKEShGqoDLKqIihyKBSbN8qQl3b7zW9RTRL9+GpT/sj/OTHP8TatWuxNACGWrme1ganDNRGI5TPAeBy2AARMDVZQ2uNX/zy4jCeOvXUU+1NqFlwpx3KLebLFummVkVz1llnw5gGVRgDeVG2jO/rr0tHQe/o4Ql/ug/+/IOrccHC9bhh1xJGhwzxmm8T1qwfwSyMQDR05nNNaoMDDbPUw4EPWYWHvGwFfrvjbnA1gVnN2KkZuxvGgADsAsyvhuBr7K4usbI3TV2DL10EfWIR2HfKWmKpjMNXK2BI4MtHqK4xMNzgJS95KY4//qFWvsdtHzGnG25PfOITAFTRqUtu1TnvZEtOkmZyBT2rnHBE7Z2hRCFakiQLv6xoL8pZppTsE/tHuf3NvIdNFhn0ooktatUhCnlwcoBQuvbmXhsuaTcFjaZUZIpz9cgEUY88UmYKah0AtWxVRqMRjDEYDhbh7OlcGVnHcjLsBbP7niacxkc86CC8+U1vwBve8DoQEWaXGgyMgjaMxiPQHn3mSNzwgWvEmqF9UQ3Wrahx/XXX47rrrnGz2j5OPvnkiIuHAI1Ir1u7FZfW3jQTnRq9Xg8XXPBzALUjiKiwJidsG6NYQkXQc0Mc8bDVePvnD8flg99jyTC4C9wz18Oq4xT+7MwaX3t2H8uLBJpwLbE0ylMAhj08513H486ZuzE3O8CwUlgEsEQUl+5/b8A/7wM9C0QF8X/NQNUFf3IH6PQVwEM74Lmhnbt66vtUBVw5gPppD2b7MlatWo33vvvdmZxT6iAJACc84hGYmFqFwagB1XVcu1WxffIMquCHXdpV93vPYUnHkZdMfoe3S+zSjmCdK9aoxKlALBYTxI6wKA0SdQxuo7Mo2fxy0dGBXTaI3jcUM2dC7/NKXvYwoWxEw0EwgFJnidLRIhanWXL7uERVse8dcsjBOPHEEzExYYEdw2xfAGmp4X6yqitMTU5g/T5rcOwxR+Hkk07CY097NFasXIFBw1jsawyMcqWrC1yO5XPDkbChjV1a8K9CRXYmPqEY0wr43ve+j6YZgqiL1avX4Oijj3LlP6UHI0O6CocnquBWBbsK1113HW677VaQmravhfKbV3a2ShCqEwrg/ggr11Z477eOxqbVd2L7Yg9UKQxZQ1fA/bs19n70JJ77NcK3X7iAZuj8v4xyQoqAWRrgyEfviwNfMI2fbbsNXHfQY40+gB4YzQSBthFwSQP8vu9K+exGB4EHBvy2baAL9gPVDbhx3zNRAfMALhuArh9Bw+BNb34zDjv8UDSjJvDQ5SapV3E55NCDcOBBB+GOW+8E1StcxElGFkcdOKRqMSRJP5zSjMO7iuyIi6PJWdhLGEPQAoAaBU4C5St7npvpM5uUrmEBTkmGzx7yeiiYKc3RcnTEct818Rayz4pcoBEDVeYGmHuBozWD5bCm5+9ok3YmyfPzZZNSFRrDeM1fvhavfc1rEwG+xNmQaKxJGWDJF7uXGjSsMDLKzn79ggJbf3VfKo9EL2xM5D9brjyhUoy9V9Xo93r49lnfsWcyD3Hwwcdi/fr1aLTbbDJxo4m5faCST7Lu85f86lcweoi6O41Gu1uKIMgo8cYlw+DhCO/60oMxOvZe3D67DVVdY8SMBkDDBF0Bm3YNsO8zJ/FH/6Fx7st22wOBrLa17ZuGeMZ7DscNtAkLTQNdVVhmxqK2lEnSCriaYX66BDRkfYCY2rrR3Qq4bgh8bAH8oRlgc99+b1cBV2vQZSOYhT42HHAg3vymN7nZNrUovAH/0BrTU9M46qjDccetN4IwI0aFBoS2yGNSGec751yIzNzTjcZNPdL/6vw7tTZWFE30NiSDuJXGJeDFrb43DKL4AapsKd7Bac8q+9ywFyDkQsOF3pNlaTYQ52BClrkOchr2JEZcoAiikXNUp0QKCNmKYuw9tTGhJDasnOJEBJR86eznviNRNjccASsZwJ0a6CiDfaZrfONrZ+O2W2+yG0KjeRz5oAeh0+lgedDAoBJYQizh7MKKVyW217tyT+PKK64sIAlxh5rBgGIoxdCzy3j5x4/Dwc/s48rd90LVFQZsbJ8OQsNsg1kxNm7vY/2fdXHKtin85u1LoInKOgT2h3jY0w7C1NM1rt9yH0hNYNk0WDDAMhN0twJtMuCL+qDbR+Cqk9n/CHabAdCpgE/OAo+ZBE6tQcsA7tHg8xahfteHgcHfvOtd2HvvdRiNRlCqbk8hXZI0jtDyoMMPAdAEMQuJr5CYBRPno8p8vZVbQG8yG5XLQelyeCv+6j2aPQrtKxCsVnSBiJGTnMKpzsl6ryix23Pb0J/JLMGyouUwr2bXnxoiKEi5zpJRdPtv+e2rlEmYognMfobHoayBbBP8Oh7Jn5WCBCTaAoBRwYAjkg7JsiLX/9r3ffAGwMr3voaEtQpQE2PtDKEZDfHxT/yrI+HYQ+yIIw53h5rP7nZvmEuqwIC9lszo1hWGoyFuuvk228+3vJ/YqVxWqGoFPdvHE15+KJ789hW4Yu5GmKq2wQuGhhuHgTFya38jMti4Q+OA103jwVs0bvjYAmiyhqqBx73vEFzZ24yeqcAVsEyERQUMvUf3bzX4F8sAV9H2J/ThqkXF44ZB79wFXHgAMDECblhGdXkD0xvi2Acfj1e96pWOH15B7mMFeprgywPA4YcfkSWqCNSyoFhCqotEAClUjQm7L5sK236Y23tCguXVInK0uMzSgdBDV3krKW7kHEeSW8SMfFjbtipJyZfcshf2yLMO82GvSpEixImIP+VRnGHnJA8+yg5CQSphiuU9x7GN79e1oWQso8Ooy/JztPg3Ir4CaXa9bVxS4DD71WJUZAzc4r59KpUiTFQGB66q8M1vnonrr78WVTUdqpB916+3FRWLQ0AjpWgyxcfqdLU6NWHXzp3YsmWL5QBziRoKqJqg5wc4/FH74M8+czB+u3gnelDowS4UDKDQd9tBPWZn2cnOrlNj8+4RDnzvShz+F9Mw/Vk87LnrsfgojTu3L2GgOphlYDczlrWGqRi4TVuRuXu1FZ1jShYkkuUJqu2tPTkBvoOBf1kGprvgq0eoNwIMjfe+592Ynp52qqL+OlCccIjJhb8Chx56iAP/TGbQzm3aY8KXLWdlGtPcBu5+gsUwqCBqVyc9W4FcRb7Jzb18QlXdfoFJbEwmRSxj7OqUn+kapsJsNq0iQk/q+lhTIFql1oyZNBB7WptHnJHsw6KVlWP2IU/4GDOwiuBbe+Sl3UHhl/FN1u82nHKbfdY0EEseDgzuKMbB6xR2bN+Ov/3b94GoA6ljuG7dOhvAScAibUsQqwgFArFBpYDZ2VnMzc2GlTsO+KErESvA9EdYuU+FV3z9YNzYuRXbFnqg2lYORBW0BrhjBQd6A8YQduF+ZOCW8AnzfYN1H16Npq9xwluOxkXL92GbYoyaEUbauiigJtAcAb9qgF85idegq6WiDRBUWyHdGKBbg/99Htg6QHX1MgZLczj10Y/FC57/PLcSWSUzfiQut6l1z/p99wHQsdrpUl9N/E3iyDuwbLsqVKvRbYGDFhmhcJ+GUpzK4x1KeuAxDTJlPIj8tJFsSsdIoozM3frNxBmfuoQKxzcjKJ6cvDZk3dYzPNuwKT9ZTref5MnKQkTbBracM1G7H2o3Nsliug96k5AmuIUyx8ASs17xvg86Y+wQyv99pQhdxdhrWmPdZAcvffXbce+9m1FVMzCmsfRGAGvXrg2HkBw/aSNQTrFspdxYrgIwNzuH4aBnEWhjhPwrWYKE0SBj8JKvHY+dR+7AXdsXUHUURqYBswLDQE0BS3eN0CiF7v4Ky8saQ3j5G6AHg/7I4G7SOPJfN+C3aitu37kdhAqsOVAJSAG4nYBf9IFZ19sKQgkF313ZBxuBZRCgDOjsAQwMuhMz+IcPfxB1XaM3bKB8AMvKGNEWh4R+7+rVq9GdnMRwxBZ5L4lKCIJQsmYYxPuMC9y2Ko2sdsLWXQhyVR4j5dYqyZpfZqhFSFUkOcGPkfaGWWGczFyZx4BMlKLSHMkUSALNLa97E6qqfQaRKJNLu5WhVaG4Yzyu5E5AbOJEZCB6+GYM04xJpgMpg2JgikX9xiPQ4s2If32bN9UFVnYaHLdvF5/73L/jv/7rG6jrGaelFS/BipmZeJAgBq82uYqHZ/PEm3Fufi5wADgh5ljfLLPcw7M//ghMPw24eut2dLsK2mgwFIwhVB2CWdK48lO70fSAIz+9DiCg18BSIgH0HddbM+Ha0RzQ7AblMuUTCphXwKUN+MqhLY+Rls4c+NdC7YONC2IV6K1qRQW9tITn/J8/xROf+AT0hw3IBa8RPWl+a8qwmZqaxES3i+FgFItXCE2xcUIQnGJsoRJ19x6B2izGvB4cA+8IaxVKAzixaGRHcMjIGZlrgLXyyFJpzlMuZHyJACdMKLnQT2KtUCrZS+K3olYJQSSJGyy2nlxmTJwX80BuT7FT+RkpiYu0V3YtgGc4ecBKZyobHrjyOlfa5DRH+zcqBUzUhJl6hEcc0MWFF16It7z1LajUhPVFDiAJOZCrjiW0IIc0JuIGiTWx6OB007RaBzBD1YBZXsLxf344Dnr7avx8282gigE9ciLjtuRewTVu/ckyFq4YAFcv4obDOtjwzlXQ2xssVlZ4zhgOskr2nq+jEKgSGtXXMvj8JWAJQMfxrlWVqnxCWJnAeVv7IDaucmDrnfzgY48Cs13LVCpy7k2JEuUEFf0suOPM2rxVDOXrOVw4/zN5oiDcXtoPQMInGls6M0siBzLZneCckD0osSTPRceDnH6dMkxamz8JO8sHldir5JRowcwS0AskDplhqSRgK2iWXheaS4sS4jdzC/onoTBEyS/nxFuJ48KFl35lTkZAIasGzjMFcMqIwPbPX3nZpgpY2W3w8AO7uOxXv8Lzn/8CNCO7+ml8dix5FnkaqgfUxBKDB/s8h8CPkKJmFllTdsOgWsH0+9j3lL3x8M8+CD/ZdRv6rKHciaXc4VZ3GZt/voDtZ81CXTeAqWroD2/DlqMn0HlOF802Y+VcjXdMzIBQchhDB8BWAl/SB34/cqoeuSdRFXpiFv0qOTsZZh0USPx2kjEm6GVrsRjD8mD2og5+ZMaSjsspkiyWGJBIoMVVIU86ykx/XY+wBxYj5zVqvJd9XNQlanJrkYFyLkSs7aWjfNIeu1PE72VSi9RdYFRzkV2dGKGxoJvxHgbcJbcVJcqbwPhCKqNDRdqJtAb1nkscR0YZhyVZuABiuZyNhbRxABzHklte+kpZ6m5HMWYmGA/fv4MLzz8fz3/hCzE3t4yqmoQ2TaIAotwjHY1GIoD9OElwzCEEQXzwEkG7Xs9mRC/KQOBmhKkNEzjl7BNwUX0P7l8coKNcQCgCaWByqoK+YYTZ7ywAF8zDNBVQVUDDaN60DfphB4M2EHgH2yeXji2EEL+7Z67T4EuGwEjZcrqlAhIzsOQV207HJNQFUpbqOj01nYCUJizORJgSQuHY4wMM6wFljEk6MnnIe38wokIdnBA4uBAFQoVCVrFtVDb59rotmsWRB+pPJfmL5KJ00sRzIXYIuWaWkMdozZTl7JSLu7/tspkztDjtu1P6Wm6P6UllBm0iSaxVygsSco4Xe153Q6BdBpusfJa9l0HMulD2Na4UoVsZdCuDg/fpYL9J4DOf+TTe+tZ3oGkAVU1AG+2UH2XTpgAdZXXIVQU+2yRc6mQH3MZGA6st3e12MRwakLKUQQWNh37tNPz+oN3YtG0OnapGTzfuzgZ4EhhuHqE5dwl0/hJ4ZJf5oQFUXdB2Br1wG/CD/YBuz1HDozJlAuZOKeBeBv+iD9w8BDrelzcVDbSeREIoHekIM3H7IwCYwlqHzhtQq01hISMVwb1YNw6HQzQJySmj8UrPMCpFaLZpni8KmVIPzC07XNtSKrHQT1lmDKOQccvy2TZhgUKW0yjTlniMIVm28C/XCtOympKFfn94KFJjH25L/inL+J49bcRWVL5zLGmebdFeoXZhxN8x6SriWOTdn6gEdCuDyarBfmsqnHRQB6Ntm/CSF70Ib3zjm9CYOupSqSpqcGXEht27Z8MpbQTa7bOvNukcWrvKoWmANWvWYOXKGQBD207qIfb+xDG49/QhNm7dhqrTRWNrbQtcdQjYDTQ/7IO/uWDRYtVxhIsKMApc1zDXLYFfvRNYtcKWtIYiUuSc64mUpUxe1QAX9e33KLl/XAmHCymGVzkpHyEaKCRv2RigqnHwwYckU4J02y1qbkfQLzpyLswvoN/vBcmp9jpr22YoncLkAZrzIxgtmWPpDlK4iRTE7DK/qdq1dSng0jtcGpgVxFxbdiXFxUS5jRQCjES2jVzmZHJE6fw66iwhaFHLvxX7QQ84iZ4o65Xj36ZkPBDRoMQdJnkBpCVQ7j5qxzeWp9WtDNZMMQ7dt8aJh3YwM9yBf/6nf8QJJ52Kb555JqrOXlZ3OTCPxD4upB8PnC6WmK+bdHQVsrHXwnDjpaUBY691e2OffdYB0OBGY/I1B6B5yzrce/8uqM4EmG1AGVLgTgVCB/hVA/7uImhzA65UsFsNgWQImJgEX9gD3rcArOuCYcCuyWflrmy3AjYa4MIRcA8D3Y6b96Yql9RSAVHBMIyFWyQ5iR9jDDrTFQ46cP+kfNYtMNE7XqQAoD0Ud4PNEEqptB8N5C0KJAwUiB65N0DJJJ5K2325rlrChSYALd49lRtgylkVkjpmMrJEZJIl4uycbh8FwkSBvJFmPW4RQqx2iJzbmzY7jJEBEIgi6Wx/RxTIo/QUbZWaLIzVTGwERBmu2M9txeZJZvjotMRRK0KnVpjoVpieAtZNWFTxxhtuxJfP+ja++tX/wt2bNwJYgaq7DtpoSM+d8hFos8O2rdsjvz0LXJO0JGwTobLXY7FvsH7dBI4+9mjcfPPNUMdNwvztfpjbugjqdMDKbUd6RbwawEXL4G8uAr8bOI4yixNLnGKGgAkAn5kFHdMF/moK2DgEV+66dx1wdoUGLh3EPhdeO9qqXgYbG+k35DfmiOMqOuxoTSkFHgLr998PGzasTxhxElQ0YkKeLh/YG2DzPfe6LoWiv9a4itJzI6hKZsthn1iJESePydZMxX5ZtqhhmBUzWYmvLGr7vDnNh6CJEiOSZYb4oHKwjBPapMnQUsOU7fFyFCfhVEEDOaxeLFspUOVMQp1EmxOL9sba6pkKHVT4Q//zG8HF3WsN7Ni+DbffcBvOuuIK/Pi8n+BXl16Ofm8ewDSqib1hjLGKGEI3uQVfEoexB6Bw+x2bHBBGiRy5kVRB95ooF+QjDfRG9neefMLJ+MH3fwB6xDT0lYswJ0yBV7i9r0oBmkETFXD1MvisBeDnC8mcloLJtcq4ygzu1sA7eqBj14JPJGD7yHLOpxRwuwYuGgLbAUzWgm3lvZaqMPslZ9kZKo+MEhyBKAKGDY499jisWbMaCwNtN6SEXY0JbVlq2Eein7311lvHIqSU2wnJ5BZQbQ57BaUim5MVwujQSYkscToxqtsoNgm2FLeCJpt4tsnQnMulpagxiQdFmRVKyIZyN5hFGcupXgGRXPpvJyWi1M2GjUnwBsmUKg26JG5XuZN4pqNw3W9/h9/+9nIossocVVWBiNBoHccwrqcisTXVaI1+f4CFhXns3LkD99x7HzZtuhebNt2F++/bBms3DUCtQj25jxV391I2SrWsOdO+yIi2ZQq33HYrhoOBdWnoc0THBWAWEHBXwrK2sdkH8NjHPhZ0YAd6SwNc0wMdPmWz56TLppMK2DwA/2QZ9JNFW1Yrl5WVEgSL6PsT4XUAQwN+8U7QT9eBN2hgnkFzBP5FA1zOQN1xP1+HzMseuFKVcwOs4mvc6hPTnW7oPk5+xIMtGDXiQKiJVQmn4J6TfFIMdB1iftNNt4g7WSE3HpKJiQrglTf29tMLtPjRmUHZOIN6jmBzXdSVDBnVpPTJ4pqTRNC4VbbKUpSScjulNibgUmuTJwWefO8olxCKwJVTF2ydTYiiJ6EHlltNrUUmdrxrg6lOhe985yx89KMfxf+d/7oAuqDOCqhqVdggarwKhhIgldNWbs2p2dqosDFW5bGawKZN9+Dee+/DAYcdhmrBhJ9rldCw/R/Z0Sm0UZhbBk486QQcetRR2Ljtdqi7J4CNA9CaaXBNwGQN2t2AfzIPOnMWvMh2XBQOmtifeolipswzZ4qBLQ3wyiXQBXuB910GLtDAeQ2wi4DprkOeXeA61wcWGTig2EztAaUg/DADqDs47TGnhOfrhfLzii/ZqDOAUUCnU2G538NNt9wOYDILB44TIv93FRX1rajlcxQ3mZJFf6R8h9a2jvg9dWm7yNfTLP1N8l3GnG7oy3CObCxb1VkyH3EkcLd41eLJsstcUkI2SshEIMvP3EwuBJ+TzRLzPSpkYI6ZyLssCsUPIilEbn/P5OQk6rpGVXUtIR4x08T7VLKDnOk3SwumWBb5x61ZBC1E5hLkfZYrbtJnirUjIDFUp4PlxV247rrrcdjhh6EiE8ZNJjvYw34xRwGB+eUG6/degWc+6nR85is3QN3XQN8xAB05BawEqMfgC+bAX54FbR7YbJmgxbWgOgr9LCVuXMNWPfIKA3pdD/SJGvy7Briha4PbgV8k/Ja9kTYHJQ4p7ySCVVaBBJjBEAcdcRgefcoJGGrGMKxzpgeazMA+RrRmzEwAG2/eiLs3bQKqiTAqJLbst2Q4lNCpqM3IEotDPiMHWmXYcorAMJXGs1yieubzzpatChW4ixm/C+3SgTK6WJTp4YxCGQvAsMgg53UQwnZSfpZpjPkpZQsUGQotgtcYyVKiVvkutepthtRomgZaM4zRMFrD6MZ+XnPCb9ZOMK5x4FbDhMZ46Vhll/upAlM0BSPvk5t76lZdoJqIHroUDdTY/UtUQakOgBF+/ZsrLAVQtVct86EFwz7ukQF6jSV0PP+Z/wc0rGHmRsC2IbBgt2v48iXwN+dA1y850IpExq0zj2D3nCr7WClYr3YB7oDWTIDPHoJfvAz8RAGjSaA7IexZrccwebcHJ+tDwRiM2u2b4CEqpYDleTzz9Mdh9ZpVmOu5/tdwwjuPCx+UjJi0MZgi4OqrrsagP4+6U8WERalovPcHJkqN/7jAwJBSO9IoTW7RcXEImqPQyErioK0Sl+sJZYMWuQjBtAdZV8oVaXNfBblTyzEzMgnk2B3c7nAxBCg3CiiZmpX0EGIG5kz5UsJtnICAxG06qzGiZ2Yp8iZHO1W69pYAayrRcIrXPPWLJd9LgtKF9eQgFELpYKfrbABM4ZJLLwczY7JbAUMv1Jbu0BDJa2uvydAQ7lsweNTJj8KJJ5yM3268Eur+KZjNI9DdI/DZO4Gfz9rSlpH0uaxUMDBjQbRg7zbYAm4UsIqBS9lC89MUwHT7GlTud1TCGE74CnEuk85Cr9v2uGpyAi970RkAgIEWro9iS8sg3bslv+7n+PU///kv5YAyst+IUgcTolZ1Sr7MpxRfSjnQXFTtkLnPZMwsIk+lFLSVlBdMAXRqSYSQmB8zp+RrKXDteKECFRfJW5bN+VJ8uSeWXqwm2x7h4r5GBEFJSIyaTOGRORWyDO+reKhQa20xesEmgSvdCvIXljKXC+lumAyMq8T42XFBC/iEC17FYGPLVcMGqFfgmmtvwqa77sZ+hxyC7UsaFRE0RckiubNtwlo4YdAAOxYbHLiygze+7C/xsjf9Grhfg8/dDd4yAC5etM2h9AaWLCkSBAtVBXd6Lo0ofTmwConFbBBTVKL3T9QwKfMmimZ2flqiFEHPz+OJpz8OpzzqRMz1NEZGCVleTgQY4myXbQPDjJmpCrPzC/j5Ly4BMOlGlcrdU6m8bpgDC9SYiNoLD2PMDwLf3ityEIMM2kwvoZTacicM9b2qogQm5LyKhQmWQACzyQbLvd/iyRvrhcC0MinnOWpBc1jcl8wZmDGoPrfdZhIRQG4vNEhao8m4yVKVIe21KRIV/A0cyAadWCpWovytuiD3Fj5XT4Bq+y9q/30ToMp97N8q4XZfdSKdUJSX1oNHoZqcxPLCLvz0pz/DpLLaWZ2agwB8Dpj4zxp27g+mwn0LBs97zp/imIcdD7N1AdUNPeDSeWCgwuEUjc19wHYS0kXClBJBHXjMqnaIs28fXNlcdcICA7vDLBiCJZY30mvKE4mkNrPGX7/1VSAizA84uF0ke9mGE0BLG7+LbrDPDHDFb36NTZvugOpM2eormJMJ8oh3HRS+SKRU69BuOV5mc0reA/1SFQhQqsVgopRaSTmfOeEhmjEuDrIEEIyo8ekySNfI0paFFI1mdppQ7f6txAwnHs9lixmdsnlzPBw0ymt9KdzvPIED2trJXPryALbBydUE2AetC1aufb87EQJdBn1887IxHZAgNbDzIA6uCWyz+pln/zfAwOrpKu2FW5eO4vKDYYwaYPuCwfTMDP7+re8Dz4+AO/vAMsUFgkTgPbKiiKL3L3lD82DinbkZBuNz1x9Xvk+WToeidIbcTTdITbdNyMJKKejZXXjq05+Ip57+OMz1jHU01JYuGTyoOIoG+nvNjyYrIkwS4b//+xwA2vbTss1xPTgRBdAyvqkiDY+Q6mnnrg0kGVoSqBQBLPNlKwMrUpZp4sEAyqU+IMy7uEXekHQIKrFHSo6kMtsK5UW/+B5pf5xmYYwflZX/WMrmMmJ3V3JhDVPmCpH6FgeDb1KuT1UWIa1ql0E8cOMyStUFqkmgngwBawN5MmbaaqKVodn/vIrZ1geuNxdjQSfk4BiorN1odyV+9atLcfNNN2PvGYUKJrhHBCBL+Lp6IgG7UUtPK9wzr/H8P3kunvLg06Fne6jqidiSZG6FktIYslRyM/vHJ4I555mKrCZ/V0TuowZzmJh4eVdjHPsJgNboTnXxTx98JwwDO5cNhg1jZGyF0XBJASVukgGMNSsrbN2+Az/84Y8BmorWqvmbYITFz+XZVY2jU7Xmu1mfidIcNOXdZRHGxgiFvazuLFkxcLqzyMjHYFxeLhC/yiCF8w1HBDpwd7O9WuYUrWMue/CmHrRyHNW2GjFCP0pn/bjJLVzIEvA9+urHHT6Q2RteV11RUtvMS9Wk/beeAPuSOpTSvlzugCtbTto3+7tZSeJ+lZiNcfAuAqpuB6PBIr511vfskoRi1MpiRZQtc6Tqh/H12LUM9DTwmY//C1auWg02I+sPFPNCmzaZ7IaLLKQiUoskW1EQjGeBMOc3L0mOvRudtdwgWaOuK+i53XjPe96OEx7xUNw/36BvVPSccppkDUvhwFhGExFqYuw/Q/j+d7+DLVvuRtWZdDhBzLSccLBJHDYS80A6AiisOnABJuYCluOxF1l5qjwe2bgLk4tVF/629xWSF5uSsluYFrcOEk5m2nKtzuTQPtpKFZxR39qcxxQkYkgZXLF4LwC0uKvLjgVlXDBzVITMT9VSjycUEu0IpE7HQmIcxKobxkY+W7PMuKq8yE5UOXaSCr68iWMgVVZUpVqDr37jbMzNzmHdygoTFaOuspeEI3mB5HyYCUOjsGm3xtHHHoN//Zd/gTEDqKojjLuFmAOPo+IWXh+h6RyWP5mtuRkL8NO1aiy9ldmA8uB15nJ1p8Jo53ac/sen431//TrM9jTmhwojbVJVFPZC+RRkh6SIwqoZBTNq8Pkv/KdlHHMGNMK6UyQkG5LTAjkTlkRdLi7rt0OE21k3UVKhIEbYzuSmYFr8gDvznKZdluuF1DpeqNUxU0Kw8OMdzpQqgiufdFMgKnbg1HZ6au39mrDyx65E93uznHgUGbQV+xPj6CyY2fXA7MYpEJkUypbHPjOze/PfTwGccrNhcSCwqgIjieTN43jCMZgVDBSqyRXYvPFGfOO/zsSaSYWpjkFHWhzJuKI0xjQDw4ax3CjcNTvCK1/5F3j9G96GZrADdV25wxtJdUNhrm8E77ctGMYQfPmw+GISm5LUNM8kbggx45rgM6yqCs3cHA498gh8/QsfwwiE7cuwfa8QyA9bRqHyS4ExYoODViucd955uOaa34I6K6GDrJOKbyFwVQC1YsWRjo3KUjGcUJRzXkQrgSa4HWdEjlYQo30RiwhUhi9TO9opa8Zj/SZI3NJ9UGKInGZhnagsOpeE8ppAq+Kn0m4wUuG3vPfVkNsq7XkzESUD/dC/oRKkhYiyckBb3WaN8kHdifNTB+YE8n4Af3ygio0cSlfqJKBkFwoYpKbwyU/9O5aXlrH3igq1K6UrQRYqdG0wruQcNsDCQGH7ksan/+0j+JNnPQej/i506o5wfPRtSmTeEWLQxYypLSc9ZM5MFyUPzvDz0SidTWMdAU0M3qquoJcWsG6vKZxz9n9g/YZ9cc+ctpatLJweWVIo08OZYB0mV04ReNTgw//wUYc5CFvVZC80jtCYcq46xY0toMyXElsXlMlclLyBS1QOVeqlPQrdom5xLmyXvk8M5EVtIgqZqXJRInEjek2TLlSncjQsjK05WoxiD2bkGdPDo9AmHymF3psj+8uk1qbp9ZADfFlKVfZF972q8r1rnYxPKAtU+36VILAseMUcsnvkGVNWNqezWOu7pCZX4Y7bbsF/fOHrWDWhMFkbTNRWoVW58XJOs/VtjRehH2iFLYuEnYMK3z7zm3jqU5+OUW8bOp3JKMcvgo9FoDI7jrYLQOubHHtW76nMbPnccMFpg9V58JrorxyD2QZyXSno+XnsvddKnPfDb+Jhxx+LjTsbLI3IGqM7PWqPPEeRP4q2q44GW5PG4esqfPtb38JVV16GqrPSbYLJcrkSM/DKCRG09am5AFa1l2U4W8DnVmvTSohyn7z1dSH3yPmyUZbtiMv+wMGSJKsAGOW1IRlEUp0xAEnenU/KsJq4hC1VFtNDKC0PleRCQ6pHcnw/mQvHraiE7N5ygssDOQYRCVqhDWSHHnvyA1XJzNQHLIefj72WLJlZLg0EdQoZxPF9A0B11+Af/uljuOeee7H/6goTyqAmS7OsFDKXDE5EDxoDDBqg3xDumzcYVNP4wQ++h+f96YswWtqCSil7CLB2FpseYPLevxqkY/CSe2MR8CSClEPG1iETs/gedubgBINOrdDs3IlDDj4AF55/Jh75yEfgzl0jLDbkUGchlm+oBU4a4WpExNhnpUJ/bg4f+PsPgdRk2Dzys24K47o6jMgoYdyleFCr2eQxeI3EEto5B5lCUIEL3aI/cgETGsfxTCVuQBHIEqSZNsCUBXFkYnEiet5kQuhaOtdrOx/Olxly9QKb2U0iJuAzvhbKDPlj8OW1LqHQfpc4YVmJEYjK0WEV+Mv5rNMDU+lN4gIzL+GcgJXfzAlUQ8GGIhHEDAXVncCu7ffg3e/9IGY6CqsmGFMda+RXKbfmSZGNlcMf2lhnhaEmbFnQGKkpnH3WN/Dmt7wFzfIWmGEfVVXZTMuxvA0G3j6gfcZlAzI6mnyz+D5XFtv3owE4mwYwI8BoVBWBjcZo5z148lMfi1/98r/xsOOPw8ZdIyyNCKPGhK2jRkdrmsApCBUYOasaYLJmHLGmwnv/9gO4a+PtUJ0VFpVODkuHachr70aJUAolDfJYeFJRhaMgJ1MmL6sWbUNqYslTI1XmG/+f+LlQx3OmVjCeI5rvTkgNKkmp9LTH6B/kHOvd+8a0TybKR9eCS8pSpRFebkaCV5wGsuFEQaR46EkjZooeupCzUBVZW1zqp5QrvcPYheLiusq+149bwu5tFT2BEtTaHhjaMKqpvfFfX/8GzvnBj3DQXh2s6BpMdVwW9uqLHFmb9iFQeCl9Nu43hHvnNXb0DD75r/+Mr3/t69h7rxk0i7ugVGUPhJA9bXDaDCqDWYs+V5TSOg1kn53JZWulgEox9O5dmOAR/u4D78X/nPdN7HfAety5s8HiiDBq2C3sxwlCrskt9ccrInTI4Lj9a5x//gX43Gc/g6q71o5tSrpbSmAMYcEiI26Ie8HX0vZd3nNIyWZTyugkcs/xZlcojGKIONtEkoPzbGWrdVSIB00pQpws8LtTEIhmcAkCbTgIwsnMm/gImVjuZno9rTxMkm2EuN2kxQxaegiFgDYZfRO5lhGnozNvCOfpdf6vK5WylwT9Lpbe2fqgykkDJOlyQX3DBzj5Q4Ak8BVLclYVqJ7AX/3Vm7D1/q3Yf3WFyZrRFbNhIoZysLDtjeOKGwtQa2lE2LII3D2n8dI/fzGuuuJivPDPXgiztAC9MAsig0rZ29pm4lEEs1w25ZBpPdgVy+sQyKYBQbtzj2AWF6F378ATnnAKLvn59/D37387FkYKd+7QWGocuwpRhdOz7Xz2zXlHRISKDA7cS2Gwczte85rXAlQ7xw6CtHHx2ZcFq4yy2S9nrVsLdZbxUJqgUCk9ZoMcP1vm4hjJmUr5TRfky8Zpv5ssT9IY8YBEfaOtUQWxDRNJBJL7TImH0MjIcVJml5lvlsmG30F2uiXZw+m6YhCC42RGzWPKczlvJ0QNbCosMhDF/WDKA1YGtWQ5ubFFMBtDyloKDCd/Y1VCgkaOtpigJlZiy/1b8crXvhmTNbB2ijFRW+H4Sln6YAC2wFHyW7ht+Kpk2BDmB4Tbd46wz8GH4MxvfRHnn/dtPP4Jp8IsL0DP74IZDaEU22AOS++2fI4AlkCaXdZWZFBXhEopmNEAetd2mNmdeOQjH4Gzv/MV/OJn38PJJz0Mm2cbbFkw6DcI5mmaud2OMQmBQgrUxI4C9po0OHSVwqtf/Ve4++6NUPUKGG0cEOl6Xwc0koqkHUbKOAvLCyXuc+IyiNamUSo1J7kXNL6PJrHQT/Lm9IoZzG0hSrlknMsg7GFWnEoB5bYrTiIuE7ZL0GiWHGmnkqK8dUmp42/5oSariXJ0xGIbJVWg9A5xEfBoCwekKwGcccklkYSckqakBhKlKuFEQsFEbEVFAUwVBRdIBYmW0O+SsQZkruRkVcc5Khlo1qhX7osf//AH+Nu/+yd8+IPvwXx/hJGpXK8bd6ylZpkkD8DtDgPAoGE0WuH27Q2ma+ApTz8dT3v66fjFzy/Gf37tTFzws19i273bnJROB+hOA90OlDsokhVDtgbzaBrwqA8zGgIg7H3gBjz52afjz1/0PDz96U+CqhR29gx29wwGDWEkqiXr+kjJgoJ8fUxoEQh1BayoNR6+oYO//7sP4Jxz/htVd60VDwylc7qUQRJnEEwsagkNcjYA4qgFTVSUo2KU3Arb/MtoQuDWCYlTA0I29vThMfPVEuOmIEwblP258D2ecy1TphEWK96UutFZAAsJKC1617y0zcsTNixALPcxx77X+yWlWtNWE8lauNCYHrgtc8IFBDLxcvKII1FxzsBylJd7qwb2knKrH7GUBrmezTBIeXtLV56GQLZL6vX0PviHD/0DDj3kALzqlS/DbdtHAFUOX7A0Q0kqSJbigjWLcRRCA2LCogZu3DLC6qkKj3/S4/DEJz0O27Zuw6WXXYELLrwYv73mGtxx1z2YnVuCGTLQNKKvc2l/ssaa1Wtw6EFH4OEPPRZPfdLj8YQnPBob9rd+x9uWGfO9BiNWieeTdkGbU2ENUuF962xJ6FSEmWqEkw7u4stf+hI++KG/R91dA+2vVdL3esS5doJekXUl2yRKZHa4HSZSjYRSS0RKdggoXUIvVLaeflqjsKcbXOmYy2hTXqe23Mnl97sl8lxEUaXrUZzMg1NWlpREZSHBVVo0kP2CTMIWQ4qE8kjPZOFMF9UqpR6WNMHOe/lczJtLu4tiYM8tjrr0T+XExtnvuEYpIo4tCVR0bPQapeQ0a6iyYzxVu+AVQIWxcquaADW5En/12tdjw37r8cxnPh237xhiWVulYaMBHW4uKtUajjfM/hhxkruE3T2D+b7GTJew17p9ccYZf4wzzvhjMID7770f992/FTt27sbu2XksLS3BsMHU5BTWrF6F/dbvjQ0b9sN+G9ajdmJys0Pgrt0NhhrQrNzo0EQyhqjSGlG1lej7igjdCpiubfCe/c1v4bWv+SuozmpbZocVUUFddcw6ckL6svWh3Dw+40Lk7gpJAkaqi0V7rGbLjp61vA1bfLpxSwuZPGzZli2eJMwolBaUaXvEB2U5qhEtzLNvCGIeB5JTQVlWiuhF4YLSLjCQWtSAU65sibrZNgwuz89JnsRUSuSuJHY+sonwWavKycEzJeRe2GXkun15DMDagKpJaGY8/wV/gR+c8y085SlPwO07htCmRq2s7Elq/OXtR+Lc3V83xYB2GdkPO5ZGwPKuBvexQbcmzExUmFm/AQ89YAO6YxZyGgDLDbC9z+gPRxg1XpbI7SuDXcXkOeux1w2m6SwzLsLaX6UIFRgrOgYnH9TF2Wd+Cy972cvAasoCf4wEwSdV22USpVrbXuxR5/Bss4zJ4jgWAnvEKLIbEy0slOSaU7ffRFInYV565ouqXW2dz1ZJaEPLP0JZChd1O5MoBalF35bewEg2kmwgo5TckdqtJM+jIOzeIo5IhQ+BMgcXOc7skZkjkCW+wJxe4HZMin6SjfDaocJqliidTCafkmMHnI+wol8PewSbK1tKJxsLPrANDDdQnSksD/t41nNegm9/8wt41rOfgdt3jrAwVFBEjvnGrWtPYjTn1JecZl3qcaWcGL7tVQ3meiZwnRVFYDEKVcjrY50Xw8TAt0KQ8kvUUpdM7GL9bq8idIix1zRw/H4dfP6zn8Eb3vgWQE0D1AlWNR6w4jB/l5lYTgTkbS4WOaRZW6jGhIOhMCZIqlgIMlJRc11gT8JXUBVhJ1KF0jnVCirTRNIN4PBiJFZCEdTJN1WS+Vz2YiR7EihSqhP2FbXYMDnRQxA63G0n18MleYMzKVbmNpe1rW7B2QoFR8ohJBfYxI8TFpNJyP3ha87mwXOOw4tBeTWgQJWgbAo/IUkiMQyozgR6wxHOeO4L8bnPfh4PWtfBfisJU5WxIyZFbh5MyWHFYhUuNXFjNGwpjE342GCkjf0cEwwpaCiMDDmZGxXF1kNGNfF3uNl9I8TYNaeIs5HxIFYV60qhSxqH7V3hwesrvPev34XXv+GNoGrGtRmc9Lt+FOd55yGwE9RfDA8pZhfmKC7QxozSCQ4HWaQ8mNEyS2szpClqYiUlmbKMD+YMwBASpkGUutAjS7FrEqdqacBkuEW1Tm77kh4miyTvD7sSQyoNdmpLqXK+qpWxtoQQXrjsJq9h3DKDPwc5gmd+XBJs08ILYpJsmdDUOFs5odhTRbdIcQNQepLLLSn795XzHYqyM8zGf9qWyAQYMwJ1uoAmvP4Nb8Stt92JT3ziH7HXTI07tw/BjYpAoxCSo+Q197u0kUSjvD4di1Epc8jKVAQ/03tBi0pJiylE7gDJqWAaiOLYarI2ePCBHSzdfy+e95LX4dxzf4iqXh2eS2DDedNwihYuUTFEhbFR1L4q9SZUwEY4W6NPt5C85zaREH9vLTLlTC3O9oFL8px5iZcErEFuDxp2bUU/zYktRMwOHm1OkFol/YSjVBwV5t0VRfNrw1mGFUJxVDD/DuSPsDDi1QX95zgrbWKvHAMz3YnmoOeMli5YugoXqYRSlijuNboWxmVlCjIxJoz4PLqfiy6E6TPlS/Z+5dFpTam6JW3DUOCqg2p6Pf7t3z6NJz/lj7Hplltx3L5drJkiTChGx/kVV770JSqQYikLsDg39kvzTeaM2Pg3v2gvabOOURWcFQu64SzARVJ2dlwrYEIxDlxX45EH1bjk3B/g1Ec9Guee+0OHNnvRvMhXJyUpklWc9XqJIhqHMGXjSreY2lrTz1kkbFLxWKGuKJ0LKWMfpFzogkeWZcn4lTDJuOJ2cMs+seVmL8Y5/i3QCetkX7IiDuVa5bgIndq9VfbGqSv7fscRD2p3QwXUnNL9YslsYi+07h6/UvbF9mWWci9+EH1zZaPKBvO2ZBOjD1ZtECm4JcTel5JtHZNyfj2pQTeBjRTc0IxJlgJiqW2SGyEnztizOfLRmZS4Of2esQhiskGsGahX7I2LfnkxHvXoJ+Azn/4sDlld4ej9O1jZZdRkBQEqStltTGOyKEe9My1IM02im+2XVuLH/uuRUsthYpDbvnoyRaUItVKoFWPvmRonHNLB5NxmvOHVr8aznn0GNm/egqqzBo02MavKXe7M7ZAoivNzsvpH7V14n1XlHrxXyTSRmME5FUhUVST5y5xrdYhHIbJZTSBRYzsnBedCzsJTLVGd5uw0SbBfI059Izp9FTIbqQqmGcIYA2MMKmh0K4WJyp66CkBXSeUEBK0qDvMhS/+b6hAmKw2iDpaX+0IpA0EVQakKZriEufkF++RNgw4pNK5Q9gBMlOrkQLPzj7lWwKQy6BCh3x/FDRXjxcpUViq4wPIjHnZFObvr4gc0ycoYlfgnrUOTshdfjrzC6ySM2Nlfe7f2Zkto9+oadz29a4Jp0OgG1fRemJ3v441vegvO+cGP8Y//8AE88pRHYvsQuG/XCAPtbinilnxTuKeC1TSLvWESYrZJCWjJ/pzuaSPDQ5JRjT9g3YNXYKyeqXHIugp6YQlf/Nf/wEc++gls3Xo/qFoFIoJOdK1k2eyZVWK/V1ZwoqRliuhyafZDnOMu+cyX/DxvDGWDEuPwpD0QKZgA1AwujIXQfjCeOeSbdJKOg5zIq8TRpiMXUITsGIRKVdBLy/jCl76NT3/y/Vgz08UaWGsvAwRFSM6rd7H4rN3nZypgCjXmZmfxzf86C0STrqSmiBY68bR/+9SX8PjHPQ5H7TuFPoAhHLea5fw79mV+bDzSNtPvrYD77rsX3z/nPFC9FsZwcOFjKp/LqcOxpH3SWIvzZNhNpXk8JYZzso2WoycKK2oqThTcrJhVJZbwRQC7C2BMA+p0obr74Gc/+yUeffHT8NIXPQ/vePubcfxDH4JdGrhvp0Z/ZKIAQwH6JypQguXcv6iiQu3Rlbjb/U2u3OdrYuy1qsb+q4HR/CLO/sI38W//9mnccOMNACZRd/ZCY7TL1tYQjZUYFalYMlOic0ZCLjaV/OGQqKgsG5Rju65KIjFSihv8+e69cAOVJA9OJZnZg1jtP8mpW5M7qYlyilg+VBDE/IBWU3SRVwwy1o6EVq3GZz7/LQxGjBc872mYnp6A1nbH04pb65ChvX1Jo20v2YxGWF7uYTgcgcDYtXs3/vM/v4rrrvs9VGcVDOsoqk5WYZK6q3HO93+AJz75j/HCFzwHq1evtL9PXhhjoI1G07hFcjZoGo1R06BSFRbmZvHVb3wLd915L9TUSpe/leAli747xzi8fjGZ0Exzxt5hcSAWgZ3kJzwZn8Nh4PumMMNmeaN45hDSUs3jFg4N8mMndj25NhrV1Bpo3eCrX/sqzvruf+MlL3ohXvvaV+GhJ5yABhXunwdmFwcYuezGosxjaSDCyGAvEZE8Tggp+gEGeyU3nlox2cH6NYSVHeC+u+7GF75wJr785a/i5ltuBlCj6q5xRnEmLpeEAK3jyqYXJBQOEOmkXXj7sgmEldgnUqtTJRkXhtsCZLmCa/IxJyOjlnq3qPTIOJ8QNgxVKfzuxo046dnvgFEqXnTmhGjRnkk68zJXfodlbaMTwTGw661hl7uJGTy/CFQMVBrQI4BHDq0YurG+GSPr4/+zPkBABdVZ7cApVVxhVIpgeovi3B8Vfv+4Za+O+3cSNDnjQKsoXAflxNcTXSuxXJ+7MmS+UrKNIY7MtRZrhyj1wBRVD0vlE4oBzE4ILlruCTAt27clbsBaF1b+DOpKoRkNgdEC6u4UTn/Sqfjzl70UT3zyU7Fun3XoAdi1CMwujjAYafdaiLFhxjSj1nZOWiIH0NHJ7nQrhZnJLtauAlZ3gOXFHq667GJ8+1tn4oc/+gl27dwGoIOqM+O49Jwu2ieiCFVUSAlzXoqa1j7gVdRy5hL9lajg2ZytFBVGRT67Qjh2smA1ssA56qpCs3M7Pv25j+ANr3kxmlGDqq4ikaNd4nD79Mu8wgBpGSrbtHScETiuxgE+isHGgywa1ZqVFjTTjVXo134XtOtWydI+Lxl4hwV4cvu9HHsbIK7whXKNUc3sFQ6dFiA0LoCFOoYxJhn6+2V9rw+dqDIQtRDEtjIep0LlvoQ3SLVfE5kGShdEiESmo6STAtKxhG9jLCdY6i9XFmw1EOW03/W016gxGlTVUJ11aJoRfnL+T/GT88/HgQcdhtOf8gQ84xnPwMmPfCSOOegggDroMbDYA5b6jP5QY6g1GrfpRh71Z7/EwZFaS5b22q0UJicqTE8Bq7rWiHVudh7X/+q3+On/nI9zf3QebrjhBvdAp1F393Jm6BGkSlc4KRNAqMPryq0VUEdQMdotjfjRXBbMzOFzshqNlMnUGIwlQ6Klo54GF0nVphalmtM5MLWoiIKbS9yulr21GZcpcWlfTbGUZnIDcQZBQRsNMuIQoOh27tMPm9IKH2VrTpLDWkUvnTCrdb0dc+rb5G9qNmLOKmexFPt4//gyjaroY6QCT5nFFUTplPSzP9kNZp8LJXC+bcVoBatcX+TQ95aXTUhI5oTMpGyp5wPZnyfkTctYh+tkXEmqJteBwbhn83Z85StfwVe+8lXstW49Tnz4Q3Hqox+FE054BI486ijsvd+BmNl7Feq6hs5rHvdaV241TolcNhwBc7u2466bbsd111yLS3/1K/z617/BHXdudL+lBtWrUCkFzcYarIvDNCdeeJCKE4G6+LrFwsbEe5fd/S8lPDnezyTnwhGKFKQXKu+7tsrlTMZ5Dyt+0q4o9MAmKQkcaZvFKQl5E4uHSiiDLFk5Ea20nF4uUzJmYtE7s1C3ZybLBGBOn06mTpEKy1VRZJshLnQ0U/YIcWA0wW7VxBQomedyyb4Co0qNrIP8jXTPEyClkFdlUa4kp7Axrc9Rtplkq+Bs1u0lcEg5yZbUS5Rz/nXWgdp71L7WdtTkB+s+kCndGHJbT8zaSq0ygyanoWgGYIPdu5Zw4c9+gQt/9lMAhMnpNdhv/TocfNAGHHjAQdiw/wbsu3491u61BpOTk+h0bGvSNCP0+wPs3r0b9913P+6//35s2nQX7rzzLmzdusO1O7ZopGoGqqos0OV6XJu2hbCcqiL3QFQaSFwivCB7aWlAzl3t9WnpjbNqmdYRUfv3JJhG+tuJJXMwlZO1QDEVlxjEGCkRYY2z2jDcNUiY60hJ/qXMXOopqcAPpnzpzqkgBJ3lwPbkyD6RdE/KjbAtfzaoBooekXNvFzJizJNRGUn0ka3DQppOizJMuNRFoXPRy0pM1fjPR1qldaSLjoPt5YWMZy1lkEJ2oUD5S7elpFRSBBdD+Z6NM0ipcFi0CHz+wPDri45Yol0pSd0pKDVl2xpt0B+OcNfG+3HXxrsAXAL8AYIyyWGBCqimUKkV8LK1htnuDYcy2bU5YfZfiXso9sAkE4M8+AO6TCnmwGmhF/SePb+fOBVuQLwfg5l7xo4nYTwfrq90LORsAsSZfWZ2V9TBJ1bcDClw0qbnc+SA5Q1xStTKwC6lFBQpZ4epHEBiPXbJuGyolD3ZjBJURIkHsFhEKHjziiG8JzNQIkfiH49KLTqhQVBQdf3/ae+9w22rqvPhd8y5djnn3E67FBFBxUILggFFEUUEpEqVKh0VTSxRY4ymGCJKMCZfYjAqolhQAQsgKsGoIRYSVGIBVCyUy+339L33WnOO749Z1phzrX0gz+/31/d85Dm513va2muvMccY73jH+8YMStKGk1RN24tIpTDyCrKiYukdlM7zAh9TaV0j+jYcDlbsG5DYF21uVaUQdw1OWBCstxqt31VK8APOdk9B9eGideErSAMo698X59JhTQVrKvddSvvXo/yDb2PzzHAOCPEh9BYxiiYEuObbBWuT6YVSDK1r47QgM8sOyYIx9SgINEaDCqoWvY9thAtaVXQ8PRKC75+h4QnVKV1PcQWHFdi9CF5W9fMlR4pE2ag473czfXRklqmNsjodrBXcYoXBLMsEINe4DA92g8caAQ/OttM9XXF2BnYwJ1ZPbK1UGLuj8Gf4u8zkylf9XWBiEkXRcYJzQmKGPFAh3eNYDOMDsYDYuq9h3+94yRUzu9Wj3x3/+0x993UPNLVCqETW4yNq7i+m2lw27vHBbN0aDblhc6cBYY8piejUgnAGMI6UQ8EnV4AmJxyirCwIwnKU0Zgpks9o7Pml1Zb1dVVTDd1EILyPvQmg100GzhSCMe4kewRMkBfYVxVGtgVJy0dxC8sOF1BhKBblqvS1qpVeLkgYpkUKawYihows2g0zPQPwKOu0x/Wb8iJ9Fag0MDEJ3eu7hTFrBYBl61ETpHucGKfJfiYZF5LA58XQiHIaNbdl4JDYa8nVaEAe19vSF8jJLqqc/9oGc8h5zRB4fg6vPPpFOPqlz8dgWDkqI+DAEdnIc721w8wwVQXLBqYy2LZtFr9/ZD1++rOf4/4HH0I1OwNMrYQqClhjki0HihKvEg2ulQHBylMca5pct9vF2a8+CduvWQGQclC9p/B1O1186z9+iLvvvhc0tcyXsSoZlztgzgKs431zGdUFpCKCXVzAGacehcNf9DwMhyNRsWRWmS12HJxQGij28wxgcmoKX7z9bnzrWz+A6heOl6g4amHFPpq5Vg+1fmO2qrB82RTe/Ka3YuXKCTCrOPIDA1prXPeZW/CTH/0UesKZXKcLKuE903F9zr1w64AkrrnzHKofqscnRBowI6zddTececZJ6Pf6PttVAAOdTgeLwwof+fgXMDc34/tbpP0sVGKozoHEE+5VWeKkU16JZz/zqSgNQysVJYIi6y4noAT6prWYnlnE/Q8+hJ/ffz82ProJKDTUihXO0zr04En/G4BMhnRfyNVNIKsgbif2UOsyg2di5dO5+lFRcUQkyM7NrVfZJzPS+RbXDCQMB3jDpWfjFS9/Af5P/xsNS/z0Zw/gU5++Gdde91kszs5AT025Eou0nJg05sE1NbTWESq0QrVlI86+9DX4+LXvG/t71z2+Gc8+8GjMzM+57R1ZlsbgrU/juqJxs+9Q0r3tjy/EgQc8C/+3/9thzRp869bbQf3tYyFEikW2guDoeplWrWBmZ3HJZWfhPe983dif/cxn7IVjjzsbjH56dHsQiOW2VFhBaqzH2eaiCBsoRTDDEa666n049+xTx17DxORKvPev/hLF8p1QVSZZ1ohC+ci1md2hUWiDv3vfu7DnXrv/H93jxx/fhO989we49mOfwV13fhuYmnRUXXbAX2xd/EiTZdiSSt1JGu0pQzLMuZYkaBXnaN0HpjAmkUN40URyQtwXluJcZ89I4pZKg0RYWFxEVRkMhyNUVYWyrFBVFarwp/8o838rK5RliXJUoiordHsdHHjgPvjg370bd//bTXjus58OMzsNpQs/ELdC2S8to+URFoAzC4Lqd3DReafAGIPhaOSuIVxP6RDSndduh1NPfgV4dg5akZBCtcl2EbNJ+muCqfc/AczPz7v7MBiJ122y11ym96Ss/73M7pe7nwbzczOAGdR6yi1kDM72jG05Qn/Vclx83skwxmA0KuO9Lv01lGWFIw4/BM/Zb2/Y+Tm/hJ+R671HslyOcKSWbvSFij7H4kMVPZjhELs99ak48fijUVUVRqOR+92le+9HpXt9F55/FlZs9xSYCm7XOddqhkplXhPMQGF2bs7/fH8Ps+evLKv03hoT3/+qrGDZYu3a7XH6aa/Ev93xaXz4n/4WnXIedrTo8m0UqE/vf3RZRLb/28I7aGe9t2191cV9I4BrhXlKT7SMiI4MHMm1pCM7yz+4SikUhUahNbTSKAoNrZsfhfJ/D38WBTpF4f+ufetoMRqN8Ad/8Bx8444vYO9nPws8GDpNY1uv4ZFf10+AHMEpVVrBzg9xxJEvw6GHPM+VbEWBQqv6eooCReEWvy+94Azo5StgTQWyFUh4+UQjLmGZRh5hDkqf4R4VhUbREa9Zu5Jdq/C6C3ef/P0qCg2tlL8ecb+KAlq7++polSYxB+PoRySlWx3TRyuHSxx31IvwrL33ABGh0yni6w2/hwjoT/Rw4TmnA6Uv+wPbLpsMECnXp4ogJe//BG9YHgUFSEMVfcBYnH32q7FixTIwMzqdDoqi4157odHRBcCMp+25O04++Xjw4py7rnyRMsxycxMBAlTRRbfbRSHuV3zGivAeaHTkexDvdwGlVeQRmMrAGIPLLzsXX/jcdejBi8/Deoahjc4UJIUXknXC8di7LLmbAOYTBHBKjsgALMpVKGqZVeKG0XAkRzQ25scZNPi5ntNktgkXuqqMWOJ3rJ2iKDAcjrDLLjvig1f/JbicdyeecMWDFTTPENT+wQ4jEHCFKy45B0orMbNLWRBKuZ7z+Qfti5e8+GDY6a1QxM7Ei71fjxUi5dE5z6Z+QbZyAulVBWNcb195nnc49Y3/qPznjTGtQvlImHBcI/G2rEXRY9CmCiAEvxapFS674HTfhtsU3A7SuuT62HPOOhnb77oL7GChdhTKPGtZiKDXlqiFMGjz/9tnS1MaTG2/Oy658DyAuRYehCD3iP7ysovOgu4WfozU7tsXwDrKNicSwQdOAX1mjjx4Yw2M8e+PsfG+BKa7LhzKPRgMceIJR+HKK98DMzvjfp+V1jA2UVaR7o0NU4RW66Hxou/hm1RbENU1OyXKe3IpP6HncgvqmgFTEp1u430QyI2ZtPvQRX0yaq1RdLy4mDw0yAFP1lq8/GWHYb8DnuNKPC+rKG8iRTURG3mmGgxemMdz93smjjnqRWBmzzGlBiGGlIp7wK+94DRfqtrENS94ApGQvCFxoMFWQDnAsmVTKIrCZYSOqy6KQqPT6bgMGD58JtRFAVKZA6PUuDaOYL9sqg9g4Djl0cLE1rx0IaauiGAXBjjwoH1x+IsOgrUWSikkk01/SCty46md1u6IU054GXiwxZXRkooaoyTnHQdFiyJ19VMKquiA56dx4vFHYq+9dofx1yAWiX3UEIpCw1qLQ/7wQLz4JYeBF2b9NXBDfihdmvCBYyun95yLqoRKTCl3v8N973SSKqSm6dY4T7fTgTEGb3z9a7D/QfvAzG+DJsRngYMzI2r5nGTJgZoTngZzMREtTK89ysq2NslKYNlhu0iQ7cMogaldJpPyE8fa1t/DcKfu4uICLrv8ddiwfgM6nQm/A+oewn5/Ai98wQvwute/Fv1+L2G2EBiVMeh0OnjBIc/Hfff+OGY88oASc6YaGEpcpcCLs7jo3FPQ6/dQVRUKXcQdV3fyUjSV0krDWsaxx7wMz9p/P9z/819CT0y4uacKEjb13m/kxYYsxRagDv7qqn/Biw/ZB8Phgiv5A1PbK3GQoFCUVQmtNd5wxRVYvmxZpjriHialFIyx+PwXv+Iyna0cAcJaMBnBxyah003AqMRrLzwDnU6BsqxQKBUZQOGAzAX4L734XFz3iRtQlmVNPwSBWAmktaYYev0Ud4gKggjc8QkUChedd2pDHSJUY0pTzJDWWBSdApdffC6+9Y07hZ6YEosGqk0NzR/muWKZG+8prbB58xbcdPPNsMbEVo+Z0en2cMD++2G//fZLqxQiKEXumSkKnH/Wq/Dm//oeiFb4w8QftgywpXgAI2d9RQUYqXWVUZQTHfH0v8Y6YZAlaS401gFHNI5Qk4NX1ltOyp5JEMXFz6kqg6997d+waeMj7g1PVroVbrnli/jJfT/F9Z/4qHu4lBLVvru+nXdeG2et7gQgsPIOE8wJS0wRYAcDbL/rTnj1aSd4lURfQvuX60gF9WiNwTDGYGKij8svOgt//Ma3gCZ7bqEYygWLhRdFq+miSeXR6+HLt9yOL9/4OT/nLP2flZh7p/9dc83fY3JyEpYtFOlEboWZUXQKnH/+hfj8Zz8JPbUbrDHudQeWVxQSCKt4gJmfwVP2egpOf9XRrvJQSjjUu4wkR1mKFNhYHHjg/njZS1+Er912B4plq1Gx8SMt3+9DpcSZ2M854k54dpQimPlFHHzoC/Diw57vKgBSsfhTytE6rbWR1BBanONe+XI88znPwi8f+BWoP+GerUC7FVRHCuQiDhtyOeWM4jP529/+FpddeknWXVr/HPTxxj96I95/1ZV1ZRLEH/yM/fDDD4PuTcH4g42U5xbI8R3VmnIkaMm1/gKJ5CipvE+AQjdFIFpW3lBvbCSuhIIaWXN4hdt6UOiz2QlITUmeVat2gNbL0OlOQXemoLurUPTWoNNfjaKYxFe++iVs2rTZ21iKUYTPGAsLMy4gmEG+hA7yNCTQWLLWCa4tzODsM07C2p13dD22CjYqDr3+5jfvxGOPPVYrTAAuQzPjnLNOxU677gKzOA9FqewN5dtNJObmbKGWTUKv2Ql61U4oVq5FsXwnFFM7oZjYCUV/R3T6O6Lb3wG66OP662/Am970R57up5LwNtY50//J296JT37yOhS9VTDVQHBprTDFNv7anFEY5rbgjBNfihXLp2CMrUt0uIfvIx/5V8zNzglgqBa2v+SicwFULrj86w24AuUldbLhSzXgSQyUI/zR616DotAwlRGxR9iyZQtu/NyN7iCxHDOQNRaTk5O45KJzwGYWKrQHHjAkrsHDenXSCpXIDOulutzWukBRLEfRXQ3dXRmfP9bL8MFr3o9PXv8p6ELXVj5c7wPsuuvOWLPdduByWN8Dfz359hE1enY0tpEoUf/0B5LWjSyuGhRuFoPpfEdJaltRlis4VeNIEDebUiJlRidRCjJXXoeo1iMKrJuqWsSa1dthatlkXd4lLCvCgw/+ylejle9zTWpdGR5kGJhyhN7ySVxy0dmQSjQsdlDf+MY/xu23fc0/vK4/IwKMMdhuu9U475wzwKMZF8B2FPtOjkbV0krL/50IbN3PsNYDWJUDSypjneOAGWE02Ixrr70W5513NkbDoQteW0uyGGNQFAWuvPIqXP2Bv0XR296V8sEMWwhHEXO8JsC6175yBc4/61WetEM1G0gRfv/7h/HWt/4J7r33R8IjyZWMbBlHH/1yPGuffWAXZ1wLwOGwtMKozANJic+r9dlXwS7M46l7744Tj3+5wB7cfWFm/Md/3I0//uM3YWF+wZmcU/0MhgN0zY47wwwHbgYvkPdaTyzDJzJgLJETY2coYCzBmBLGjDyQZaG1w2e+dsc3kuTDQjZ9YqKPyYmes4sBZ6KFpolAC41o5lx4hROyRiQKtbSh7SBW0407dk4RFWS5viaYY0j9iOKogRO0qx7HMseA2bz5MVTVDEbDbahG06iGW1ENNmO0uBGrVu+Aq69+PyYnJ71ihiuZjO9ZHn30UXz73+8CqR5MVdbIq3B9Dw+3UgSem8Yrj30pnvucvZ0SiD/dApByzz334P77f4YvfPGWOAJj6d/EjEsuOheTy1fADBZrW0zvhxvQcMr4rWH7Jyodhm0ZuBPWIbPb8KEPfQgXXXie6007nYirWguUVYmiU+Cf//lf8Gd/9g7ozmpPKa2XKTg6C0pqpoEmBs/O4NhjXo599tkbo6qK7UF4L26++WbMzk7jM5/9TLJdw0woK4OJiQlceP6ZAM95RpcEzKSIg60d6gQ3QGkFHizggrNPxbKpCT9hUNHQjohw8y1fwuPr1+Eb3/im07IyJpZqVWWwdu1anHH6yWAz7cAsazxzzL0P8cCSSHBLTRCYzbrQUKpIMjUhnSV3ut34XNtsGuTmySMxgakrUMgZcL4zP2ZZpdkDs2MbJmAzUDQEBCSRowHOS0oupSuB2a4ptcyF2TZlaAN7q9+fwFVXvQ8zMzOY6E9BKeUH6iOsWbMah7/kJdjjqbujrByH2XhieVEUUAS868/fgy2bH3cyKr4nqndZrZAJYnBlQQXjissu8CWzIw5ZAGVl0Sk0Pnfj50Gk8J3v/Ad+8pP7sP/++2E4qtwiglKojMUznvF0HP2Kl+LmL34RRWdHGFv5A8wvJ4SlDZBY6U0DmfyCPSkNBQOzuBnXXPMPeOMbr8BoVKIoivpw9OOnfq+LGz7zWVxxxRXQUYUEmY8wZQvkPsuYClCMKy49t2Zw+kasUBqj0Qif+MSnAGjcfPNX8Jd/8R6s3XlnlFVY2XMH2avPPANX/u3VmJ4egDo9N2/Wuh4fBtkZnzGjrSgYZjDAyl12xYWvebUff1GUnS06BTZs2ICvfe1OECn8y7XX4sSTTmiYyzEDl11yIT720etQjkpAa1+61q4fcf5vbRQSjC1SZnwQhOZUMFT3yynMFuVwEbCMM8904zbDVJMP/fdv2zaN6W1bgELFflfK68QeWKpxgFLDAqa4IpH6lVDD2SAcrEVz3usVNJiSTJxaIwqgILHKRKJCQfFUTxko9f3za36WoTtdXHrJxUvS2AYj4zOhU6kkAhbm5/G+q67CJ677BJRe7rIpFYKTaxMwRZOGmZ/G855/AF502KGojOMLG3+QdDsFpmdm8aVbbgUwgcFgGtd9/Dr8/Yc+CCO034xldABcftnFuPmmW2Arzz1mt03FRjl+f4uOVSJcFoKXCWZ+A65831V405vegOGohFIaRmgCVpVBv9fFF2+6Ga8573yQmvRajCRUFrVYYBeKKh6ks/PbcODBB+DFL/pDGO9CaQDYyqLbL/Dt7/wHfnLfT1F0V2HTpnX44k0344orXo+yMii029Qalha77bYbTj7pBFz38Y+i6O0E4/WsSXkL1UDiZ2HJGmR5tm3CaedegqfsthbDUeUXIYDKWHQ7Cl/96m3YsP4RaD2Fu+66Cz/96c+wzz77YFQZh5QrjbKy2H+/ffHyI1+K2269FUVnOz8maiEYBrkasd8bRBPD07E4LGHMEMDQ768UEVRcuWIV3vzWK3HC8cdiVFn3vPjzzBjn+3T/Aw9ibmYbdH+Nt+iRSq5CYZJydRlK0OdaELL2VEKLnGz49iLpb9uGtG0yp9mmBLEkY4tVKE51bcPPcWKLVLcD3guoLE2i/UuSAE7a9U6Bb62A9Y8/jje87rX46le/AniOrsw64YYhsTlVAA9x6YXnougUmFssoXThW3WL/kSB22//Gn772wdRdKZQVRo33vhFvPs978aq1asxqhyR30JhYWTx0iMOxyGHHoof/Of3oCbXwAaSiD9o3O5vzYGVTgsh+2hVoJp+DH/+F3+BP337WzAYlSDSwgUBqMoKU/0O7vj6N3H2WWfDctfJ87Lf3w37yRCrdqJ/dSNaAkyJS17zahSFxvyg9GUjUFrnzHj99dcDPITSK0BQuOGGz+Cyyy+H0joqTwYbz8svuxif+tSnYasQhMYfYMbJJlHK9yUwTGWhul1cdO6p0W0hYKVaK1TG4GMf+xgAC90pMBrM4gufvwn77rsPKuNXbvx71e0ovO61F+O2W291B2hwwaQ8INLddBN7Ttd2DCrGU/bYC1+86RZ0Om75w1qGMRW63S723XdfPG2P3bEwspAuk2CgNA7X+NznPu9WUqmejCQb3VLNg5bwAg5bSoyG2k3Ei0QOVW1STWwFc4RyxM4mpIx0/txmfF1foBK/q3ZORxLICYglFB+DoZVhdy5WFli5Zgf80z9/GP/6kX/FdtsthzXzbhSR+NJwRCEVGGZxDk/d8+k444xTURonIRNExL0mJj55/fUotIJSGt3eKqzf+DhuvfU2KAIGpUFpndTsoDTQWuOSi18DxsC/tlrArwZ3aiEZ6bTgUG2NanoD3vaOt+Ov3vMOLA5LMLT3u3XfNRi54P3Wt7+LU089HWWlQbrrrUx07ZqHYHmpE1UTZ6rGsIsL2HWvZ+LM009GaRgVa5Te1a/T03h43QZ84+tfR1FMga2F7q7Ej350L35874/Q7ygMS4PSABU0ZocWBx98MI444nDY0TbXKbQAhhFcshUULHhuBocf8WL84fMPxOLQwPrXWlYG/Y7CvT/6Cf7rv+9B0VkGtgZaT+DGL9yMxcVFdDraXbd17+awYhx55JHY74ADYMsZxxGR9z5Z1axL6OAO4byYCKMKWLVmDU551Uk44fjjceIJx+Gkk47HKaecjBOOfyV2eeru2LJgMDTk/ZPdtH5YGqyY6uDu79+Dz994I1Sx0vfqqSopyz36PEakZnKm5NHQXm8ZJau2cGvadeSlLxKyhlydA6dQFosRQjhBpJ9rNLJioNPT6PU0+n2Nib77s+//ty7cAzSqGJVHC5XuYM3aXXDxJRfj3+/6N+y6y1qwWXAzy9hr2IgKKiLATOP8c0/HypUrMDeo3KqBBUaVQbev8Z3//CHuuON2VMZgNJzGaLAZbCu8/wMfxOzCEBXcQ+S8ZDVmRowTTjoRu+3xHNjhghMqj2ObqgZX/IdbtDDO27UoUG1bjyv+6PW46m/fhflhhZI1KibvWgAsjiqsnOzgez+4B686+VWYnx9CFX3Xx0kHPQlgxRXbWjBPKQIPt+Ds047DqtUrMTcwqJgwMsBiaTCpgRs+cR02blyPqppHOdyMarQVo9EAf/+hD4EZGBpgZBilhdODJuDCiy4AYJyiSBvyK7jZ7nAb4g2vvQCkCMPKve+ldT/bAvinf/xHlKMRqnIO5WgGxiziwQfuwxe+8AV0NaE01h3gIMwMDLrdLi668DyAh35DMeWCo2WsFexbKh+MhoFRabF+tsTjMxUen6mwfqbExtkSG2crzC4YWCiUFhgZYGQZs4slJqcKTG+dxusufy2GwwrQSuhxJ5Sp1vWEuiMVzDOJeyXqINwaqkWuvEEtexGcKWJI4Wkpm98Ermx6LlCYX7pywIrSwFiL3/3iV76HJb8H7DjPSimsXLM9dtx1LUYjwPi6yxhGNWJsGJV47n774hPXX49jjjnOWV4CYLKO+ePpeGY0xPJVO+GC15yHkWWUrKA8SFr59/nXv/oVjjnmGPQnplwZVQ0BckT33z6yDrs9bQ8MBiaOsebnK+y+eiUuvvA8/MW7/wyaJrxyhZunci4Q6PuaTlGg3LIOF1xyIf7x79+LmYFBaVWEuRQBw9JgzYoO7vvpz3HyiSdh29YZ6O4yr7pYNPpeWTqTTZUfTFmhN7US551zGioGRn4HkJlgWGPbkDG/WOLU08/ERL/nXgM75Hn5qlVYt20BRW8SI2N9T66xZcB4xTHH4Bl7Pxe/fPDXUN0pp8kd3nrSce/X7YRPY+999saxrzgCiyXDkmNmGetwiMe3LQKdLo47/gR0igLKLxOMRgNs2LwVCwbu8I6OiApbR8CrTjsDV/7N+7Fh4xaQ7nrQUqXPsQjiylLtPMK1lBOTs9QloeKSG9u5r1dYvVLhkYcfw/mvPgv3/eTH0F2ffVUKK1GwoBXbgiwcGlg6NSQ05BSBTmnScqGfmlFNRK39bsLtDQN5ma0lQBPqeDk0D6wr7zhgPBWrKBRQLuJVJ5+Ch379S3Q6XVRVFbM2EWH58hU46pij8P73fwCrttsec0OLihWMBXTRwcPbShx55MvwiqOPwW23fgW6u8I96J5IUlAHVTWNM8+4HHvssTsen63ApFw5xI7uN73AOPmMs3D+eWclHNOgF7JlnjG3yGBW9ViNFDaNGGefew6uuebvMTu74B8i4yl0QkDA90GFD97zL7oAH7/2akwPDBbK2s2P4QCdyakCDzzwaxx//HFYv36jf02VD95aSoZIuUwcKIwJFsHQWsHMzePEs07Fc5+7N9bNGl9BhD6QMD0A3vzn70K/A0yJh8UCmGdgetZiWLEX0PPAz0KF3dZM4YILzsU73/E2EC3znGtZ23laYaeANfO48Nwz0et38fhMCfge3gZhetXD3334Wkz4a5CpZKYCtiy4328rRDbd9HyF3dfugDPOPBX/8KEPQnd6YGOicKIEj8J7WXpNMhuXNQLCb6JhHikFrYWMkidXkAK4XMD1192C977nPXj04Yf8GM8rYoZMFaVnITgLyDS0uIXyyYmBQmvaFQFeSHZsinRxMvgmNDWuKKEJcrLmwUjV9pISJp78UVoJXQJGpUJVWRhTpraKBAw3zeAzn7oeBQgfu/46bJhj6e0SneuOesXLcNuttyR2nAQFU5bo9Pp4/eUXY2SBka0f0EhUIMbMImPbgvNCChYuld8W1JqSkVBA4bfNGey6x6444YTjcMMnPwbd3dFnSSt0jx3NUBcFqq3rcdb55+C6f70aWwcWc2Wt8k/kRlnLl2ls2bAep518In7/299Cd1f54NWpDljogQPfJxFFcyUkGwtoxmsvORcWwGLJfjmjHk8RAVtmbCwBg2Cb4/QQOlpFY7KQWSwrbFhgnHrGWfjA+6/B1m0LoKJIgFfyD7NdHGLN2j1x7tlnYHbEGFoVKcDh9zMTts0aTIOhFfltL3f/SSlnRWUpGrEHzvDWEjj/wgvxkWv/FcPRqNbsEuyvsCZv4d778DNctcPoFAor16gobTsogbl5CwtyCcd/9VRHwc7N4Z1v/RNs3bIBRWcFKjNyu85CQC+Y6aWKlakJX8OMh6WjRtPIva2KVq2SlcxNK8T8RLCp9hW1nhCUGV5zzMClZd9TMAYVMDOyYHasGqULkNZQ2u1hKqVQdDW63R6+/727sXVuCEMFSuN+TuipF4mw6267etzGxOyvtAJX03jFUS/H/gfsj43zBpXVGFnXD9nYh7ve00KhZMKInQG1YYIl90a60rvu3UYGGFbA5iFw3sWXQOlJN2eORtwG4BJs3bJAtW09TjrlJHzq4x/E5kWLrQPX04+M+1mDkqEnNObm53De6WfgwV/8Cr3JHdxpG7dkOtBF1+0CFwUKXfjNLRLSNdavXWrw4gz+4Hn74rAXHox1cxYVVLz/7r0ARsYh66yUN9/WqKBgSMGAMDAce+D4/jFhy2yFnffYFaeceiJgZxzOwGKtzlaOPDLahrPPOAk777IjNs4ZlEwY+ve/4vqZsN6MzYBQssKINQy592NogFIYe5eWULHChmmDffbbB0cf8wqwnYeOm1LZM0yefW5cEA8NY1QxjCI8/Nij+PO3/xne82d/iXe87U/xne/ejWJSYW5gYt9voDC9YLHDzjvhk5+8zrPQSk8v9sgzZZbuApeIo9ac0JztFLZq67Wu8aFlG8l62l2UdU23nlrpI1JBBrWGLo0hYRtvK+nc1gkwboW1Khed3rAJiwC2tpcxADDE05++F1ZPdbFpi3FuhfE8IcyHvgvw5Hqf2IwBqQ7e9EdXwABYHFnnEu97Tcf0qRKvYWSsmHCfraceal0zs6xVWL/V4OBDn4+XvuzluPMbX4eeWA4bACwASheoZh7D8Sedjs9/5sOYLYHpgRsxWXEIFR1g42OP4IITj8MDP/0JAGC4sCGTWiUh8OelV6Gd8sXkpKcN+gysHQXz9ZddCN0psGlL6ZznxXtrrPHzWo5lfCB3MIvlUHajHkep9JMEA2xcBM55zUW4/rpPoKoqJ7sLODQYgBlV6PQKXHTBqzHw1Y/UIWdrYY1tMpJIUFy5nmorXdTbcH6dctpoXHDJJfjSLTe79Uo4Vc1YQvs/DRxgxuSdLw2jmCI8su5R/PP7r4zX8MVP34Cb/vO/MLFsB3DJKJSXhmDCLzZUOOyVR+O1b3gL/ukfrkbR2x6VqWLFWeuQo5awJZXqvwpt9ZqdRck6ZMMfq2WvoeBMTIsDn01xOgYmYXqWMzKoherMuTqCiuV56WeJJbusRgB6yvW5/X4fXU8dtH4hXmuNZVMrcNBBL8PVV1+N2cplTuMR5EDFrJixactW/1woMFdQpGGrWRz6ghfhiCNegsfnrEOShbOmBbBqZQcTHTHc9y9VUuYCcl4uAoNFW7vGsxvoj0jjoksvwJ3fuB1sAiNJgXQBO5jGiw4/HJ//zIexyB1sXrAwIFTeptMZXlvovsbP7vsFDn7+ITj+6KPBpnRnu9KR1eTKeIL1wU9gLJucwkO/W4fP3XR7pE0SAXZxHk952p44/bST8Pgio2IFNhxdT0kp7Li94xqPbG2antwHf4+MBeZnHWIb/jeg8chmg93/4CAcdvgR+Nadd0IXK720rNvoMoPNOPzIo7H//s/FL7caDK2qQU0L9Hoakyt1dGhQkgcs4JiRcZl6YcYBmOSdziw0Ht5sse9hR2C/PzgQ9/3ox1CdqRTX8f+jtMDQHyDGt3JdC6hugU53Apa7KJTC+scewZVvfwved/0NmN9UgRShNH4+bAkPrq/wrivfi3t+8F/44Q++B91f6TGXWsJJWrXIQj7RiJeWK4ldbC6QwU3dHQoZuLHPa/0+K7efGrWzcnoBCZbdlDgJARzKtlD+Oi7jBG64+TYUdgRFQKHJ+dwY16+tWrUKq3faEVsGwMMz7kEs/RuhPCDR14T/ufe/fQBHk1AwLC69+DWwSmHTQgkDHfs/gGCUxTVXfQCj6c2Y6PcjWcSyjZ5LxpMuhsMSRxx9EvY75EWYn6u8+ZULhN9tsjj0ZUfhmc96Nh584OdQneWwbKGVgrUjHHXUEehP9PHQ+iGU7mDksxjDMYMsFGbnLA55yctxxLEvx/ICmFTpexYCK9iiMrmEu6oD/PqXv8cXv3QrytJlIKU0KrMV55z5Rixfvgy/XF+/dhiX7Tdt3Yj/58r3o6vYSeFwOI99deEPDAsXNCec/3rsuPNTUQ0d64pAqIzFrNU448KL8a0774gSQhT1kgu87vJLMGOBjQtOhTJI0k4t07jvf36CO77wKfT6Pf999Z6z9rRVwxaDskKnO4FzX/tWTEysgKk4HqLVoMLkyi7OuegSvO2Ky0FUOI62aN2UUg6Bt04FvPI7xz3rgcqqhPWVmS4mcfuNn8aRJ5yM4047BRvWl4AqPPAKlCPGPPVw7Sc+gpe+8EWYnh1CFT0PjGVkjVTdtiFem3siRZSasxETZ+o43FZCkxCxo/T0ivTK3AiMmyLk0Zco6dDrOXDF5LIoOx5spRSWrd0DXc+C1J7Sa/0y03QFPP54BfjRTCkmVJVldDqEDZtmcdtttwHoOAtTpWDNCHs9/Tk4+ZRT8Ps5xoJVcfJlrMGaVQXuvef7+Md3/+mTVia89z+/h2u//l0MrFNeJm+BMVysMLmyj5PPOx9XvfPN9UK8dYqUtirBzBhad19Gtj7+rChmpucMNk+70qSjUo/kBI3wTJzKMNDT2LpxBmTnAOv42qY0mFq5Gy6+6DVYN2LMVSqy50pjsHZNB//xuVvwib+/+km/duoQXv+X78emde6eE9w4aNNWi8OPPhbPfu7++MXP74fSPQd0jWaw/wEH45XHHYufb7EYWgeewTvmrOgRrv27v8G3bvnCk76GvZ7xDJx49nlYt6GKbDQLjUc3MQ4/8XQ85eoP4pHfPQYqtBdJCGYA1lVQFjBwvTdbVxGWEf9xZQgzgVQX7/uTN+GgF74AvWVrMTtv4oFdKI3HtpTYc+9n4Mqrr8FrLzzfkU/CegSLRf1k9z3Vf6bENLCWVG7rdzkHu6IxPbesLVC2O9kIXEarkXPm1MZBWpPqYC4tUPl+JPw5ssDWeYPNMwZbZg0e32awbpvBxmmDTbMGs4sGpQeVHJgRgAyLhVGFldtr/NM/XIPf/ebXnuhAjqXEi3jtZRdhxYrl2DTnZq0j68CQhQooC8KXP/Mp54bXWwndWQndXQ3dWwPd2x66tx10f3v/9+3R6W+PX9z7X7jve3ejv1xjVFkHaDEwgsajWxhHnnYutttxN5iyjCR+oHSoKRFG1gE4EkQqORxsLjuQV1qsUMBAuw9yH5Y02Nu7uHbACQH2Ot5WxVZQZMHlZpz6qhOx5157YN20QWkJAwvXh7LGhnmDL33mU9C6i05vtduD7W3nXmt/e+j+DvG1F/0doIvluOumr2Bu6zSoW6A07MAgC0wvGujlEzjngtc4UkXwguJFXHLhq9HpdTGzWMZ7tVhZqH6BBx58CN+785soiikU3dUoemv8vd+uvhb/PnQmdoTWE/jSZz6LhYoxtDrex5IJswsV1uy0GudceD6Y52q3w3BIWhe0Q9+Hu+fQ/4l6VTZ2kXoCGx57BO/54zfD9AgDX8JX/vkpofHAoyVOeM1ZOPf8i1AtrIcuuk01Ok96Slcrc624VLa9wccQHmRMtUOhauJTgcUS87n4HTZzYc90o3MbE++S57x6FNhaVMwOyfUfxotnG19OV0woQaiIUMF9OETSvfFDYzEyBmVlMCwtWBdYvraHT3/sk/jw+/4WSi/z+k4atiqxZru1OOecs7B+YDG0wMCE329BHY3/uf93+MZNN4G5h7I0MN6e0hj2f3elo7VeaA/Ovf6m6/4F1PU9sWUMLWMIwsxChbVP3R6nn38+YBedqgc7l4mqHDngB+wRV67vh6nvScmMyn+uZIvSMkZsMbLsP9zfh4axWFksGPc1RUFO8ZEZtlwEyOKyi8/BdGUxPbCo/PcMKoPeFPCjH34fP/vh92G5i7Jy1p/uNXPy+q3fgmLVx6O/+RW+eduXoKeAxdJiobJYNIwRAw+utzj0pDOxZrsdYKohTGWxZs1OOOnkV+EXMxYDq121xYxBZVH1gS/feAMGs9vA1BGifv4a5IdhVFUJS5P40d3/gR/eew8wQZ7e6e6/IcK6bRavOO0MLFuxAqZcjFtzRAqKCCPLWPBfHz4Gxl0PZzK01lro7mp860ufw6c/8mF0ty+wODQ+4TAGFlisFO5bZ/An778Kz9lnX1RzMw5ko7SXbZKh0GA+pkQoGpuB4/iWvAtWIvBlxUxXNtXyl3DK8OBsUykUz6EHDijcxMQECiKMqEAlsolVGqzd/65IoYIbZVhyY4wKbqzBSoGKAqrfQW91BxM7dbBx7jG8721vxt9ceiGs6cGGbRylwLyA1196CXZauxb3byWUVIBJYQiNRVNg9Q4K37/rq5jduglK9/x1Bk1jnbgPhoxnLUB6Je6+43Zsevg3WL6mwMBoLLLGiBWU7mBuATjt/PPRn1iOajSI1Uy/P4EOEawqUCn3uq3y9yH8Pfy7Fn9qDasKdw1ag3UBSxqV0ihVAVYdGEVY5AJsBiCysGYORx7xchz6gkPw35sVtnIXi9AwWqOiDvqrFL596xfApoIqOn6DSbC6lI7G1xwN45x53G03XI9Ol8CdLobUgVUFVNHBlnmC3mUtTjz7HICHAM/j0gsuwK677YzfTCsMqcBIFWCt0ZnsYuNsiTs+cwNAfQeYCc/lBsPM33/V7aAazeGOz34cU6sIQ1tgAe6+UVHg0RmFib32xNGvOgXMAyfNQ25yMNnvoSLCIjqo/D0vqYMhCAtc+AipPa+YnJCh0pP4+F++A4/+6gGs2qEDYwlDaCxYhQXW2DxHmO6txHWf+ARWrVoFroyn80rjQG4x+kY6ZmUpW84Nfeh0IUaMkTiTtiGkdK/mWoTQx0Iu7UkJkcMFk/v8D+/5MfZ9wfMwXRqQX+lK4PZaAktcR33RxhjMLcxh05YNWPeb+/GT73wLd3/5q5hZ/xhIr4xODKQ6MNUIy5ZvhxPPPA3f3zaD3y5UWO77l7nKYMSER366Hrddfx1I9ZzHGFyghoe5tqes166YLVS3wGB+C7740X/Fae98B9ZXzp9oolBYVhAenmF0n/IU7Puyw3DPrV8Fqe0B9PDgL3+P32zdhkcHBh1odLTDAYaOKQBSHPvDhtwJ1+ubgfwQ+jhYi62LBR7Z+BiqchFEPTC6eNUZp+Hn26bxwNYhKutO637BYF3gvu88gO/e8iWQWubaDaWFWZwShPwgYO+IHNRdjfvv+R989+u34ykHvwgzgwEmC4UuAXOlwf0bChx0yqn49L9+DHY0xKHHHIm7N23GtqHBou9/+4rRnyhwx42fxYbf/BrUWRVsEQVBRQChgtPtDtBVuPvLX8MxF/4MeoenwJYGk6SgAExXBtu2FHju6afhS5/+tJOfVQ7QenD9JoxW7YxNoxF6itBRrg2bG3bw+PwW/x4Ey9GatEOdSSzOTOOf3/5WvPOTH8eCnsDAg4iaCEUP+P0WgwMP3BdvfPfb8NdvfRdocqXQqmNBpuVk9xdLrP80pz2C7hz+boxlpeClQzR+/LOH8LwT3gRLqjbwpmwVQqBjHPSmomxp5cWtvQayCVpRJWBK7LrLKpDyRP9YtNTym40XIrSQq6rC/Ows5qbnwKOFYLgB1el7yVdK+MCdToE1O63GiAportzQHYHNU2Jm81aYBQMUPS++HTKvanoPJ/K4fuPEVFiz83KnmEpBXN0BaCNbYjSzgLkt8yBV+ODQWL3TCpfUxeu21npKI7eucZLoz5IlERsoggTDFqPFAQZbFwDVA9DBqh1XwigDTTbRlWJYTK9fD5QEdCb9oambrn/yJImuGxZsDFRBWLnjMrdtFZ4Va1BZQOke5jbNg8sRlm03AaM0ulqDuXJfrwqANbat2+S1pINJmZChhcrBFa9x5XjoXBn0l3WwbLvlXh3GP0NcobKOPjv/+DSMUe7+k8Ky1ctRTBVQ1l2HCjpbAAaL81jYOAdQUV9ThI39ATcssWLtckys6HmRALf8r0gBqoMRddFlxrrfbXCmKMKDmKTxWtzfRiKIwZwpt/hUqJVGtXkT/uWj1+Cyi85AVVW+NQOKWjm0dvBTzLBysMtit5NTuCuZR5M0gKaEFO6UGgmP/n6T1y322sWJKyGnq4CNVERx31V1nAGZkzexyTaOexGOqbX+txv8xVkAI/97dNQwpk7PVwtFYtURDaPl0C6M17iW2d3y8MYWYC9ccwfoOBlcV5kxtj62pdZsQpW93iXx3yW4sXXph6LnXwOw7fFNtQtiQno3zmmxW8RVROlan+uNBTkk9gQRaMAag62/3yTsWW16LZ0+oBRm1s8CYMxHZlStt0adnnu4gzqJF34PKibREocE51a5sSB1NQZzIwy2bQiDtewaABQTgPaVlCLMbd4GrC/reyAZSFBA0a3N5pX8/e5DTXQxs34rZh4vs/fDk2gCzbU3Ucv+Jne+xSFbuOPFzMrp/kAYxU70ug0UushRL2dh4mZ7ic9pKAESnyTPYfXSMJScLjZyQhGpZoCamARbH8Bc+Yc51y4KRlipoVqqqpBZW5ISps7uYSRFwGQh1ssKscusBPKn0uCNGSBYV1Kt9EC1xhSDQRNTqbh4YPJHySH2D6T7+RTmZPF6ckSSmlS7hiMGmjS8YHUaVpkYoG5X3EMpfG49zU9793ppii6MsRMf6MBs8aqPhXaDZOtXPaQRPOoNHOr3hWUqZ64LXvJI+Pqmtq0KqWG8rc3MLIO6PaDT8fu/Raa+ohIjAkCBOh2gUwg9aU6W7ZkpGdqyyJiRs92bADCRAbgBd3F9OlvJ06esh82ye2qFkYkBcLJ32CmKeItZCrvLs7zX7aBTaAxLA9LU6kmaCMsLQe36Aaz7GFIKjALgCraydesddmQ5PBiUvb9S8iN/UMULF+VudKgLdMrkgpX4fv8whW2e0P+p2k2AlRQUgKC7+R1ja7x0MAnUHmLrqPYnDv61kELp7Mn8XsGRKQMywnyPpbudCGLJ7xT3hSgr0+rBvFAoUdGQDA2D8rBbDLG4Ecpniras7LWWI6VL8H+llWvERELPFzS6qQ60tMzU9XsZ/J7jLp8vZ5nB2op/9+9RcHVIgBTpLGLrexV9omtllPTZkvpiSIT9ZBWB5DVKvgOl90QEbAPiiAWu1IWmmgLq/3+n28k4WiyIHP46Jyf76PX7mJsfODZFXsTlEHdc26odHJy6eXhAOHo/r1xegtCBMQCbAtq1kbCVl7JlFXdG2PNwFWwUNiRRlkQR76C5ZGstbrcPTCJTUyJ7G3i/da6zAlG3Md45H3J7k26OfbA0JheeN7VwUJ3JG2WyBfu2gXN+XGOPk4DxY/0WzaM2DaR8yki5XEPNs6ZMRA1hfKiTHe/G+DGj5OcewhxLaJUCnt5qhcMhourDhUOJKshEHK9BHk46u/81KMZK8se5fkbDgZbb0IbXr1qMwFkqaZF0jc8wE5XoxnGmo96Iq8zMO2pOh2vUBVauWNHYTSjSjAdM9Hvo9/uilM3TfCYnEDITycMnLaU1j1DNzOEtf7sLTjx3Rzy0bdqPRQwWq0VUbFFZt7pl/QMY5o+FclKv82XlV/6AipVbwGfHwnLvp7tJo8rtrRYgFETRvqjwD83I+tKXAU0KI2sxqKpohF1Z42a0TG5GbSm6LIwqT9QRwu0qzIz9PLs0jiurvfAdmPyGDsXNcKcD7TtxZlQlx6w2NPUbOiqBQjkTkkHl1upiBvPKiGXlrtW1+Rx3kI0hwDhRAWMAW5Ejd3i4gRShqtiJtAXpJOtLRRuYSw4os4ZjlRV81hQRaERQQYSAXVmrAGez4t3pHSfdCbK7D0dmYX/9xOQLMQJb9+GEuBHtcTgs5RK53GDg+NyGfXArD6j6mXsgrWduHM7qwbM0rDh3Qtlq820WzoQB7BIHaukCvui46+yQWyTJ/KmR1SmJXbAQZpYrq8wMdPtYs92qdFQEoAgi6WH5fvlUH2tWLsejv6vd6/M2LO/TJMYFKw3QXHnqtH5LfPTD6/Cy85Zh7TMVZkBYAKGDbi02JnJTuPEjT05TCdTlPlfBjVKkxq/xfV7Ii8rfvEqcpOy/dxg72UKckB1/3tsYLIHUrwQSLBUCg46GZRU7a/b9SZT2UbVZhwrPl38btSDsF/67GUCX3eGhwJggMVOkup9y94Qzozu3lmeDVK4vxci/hnDpJSxKa2NFY1nVkBrV1+GWGcjzjhmW/DNj3PaSIhXjoWASXkwCLrJey8rbjbDv15lt5IG7Ht4HkrEuSGtWQa2uYN3nUNWVXhzZkKOzcWlqUQm/0xztTirrDgLU8q5hIYctgaxr6axloSfun/GKHbxTEWgI2BHDlgzMWWDjCJgjYAjwnQR6SAG94Foilvxb8IyQJOro9UFFBDYWE5N9rF61sqnIQUK3xxqn3rB2+5X4Hw9iMdvUUU2ytFmsOiRufoH94v7dqj7U8in8/tdb8FeX/gLX3LIPNg5LDIkxJIURs3MGYvcwGq7xWeuphcYHUsjSbn+X3VYRuwfOIGTCuq8JO5ohrMJhbgJhP0rNiaUCIbhnUL8BLA4wG9UsJAbLAuc1aDO/DDQ9A27shFiERXN/DtYNhTh0ScjEszcoTy044iKCV54Qj2mskNxyvtP1YqbIwrWhF1NIJemZIf8P3m5GKeFuR7W1GAdKYvgOdjL3LpHXvaUNZbP24JumGp9Q1ndnuTOmakiyNsnAtRIpQwBDltyWY0mg0oPXJbtVp5Lcx5Bqbuu8BW2zwDYDzGtgFuBpC14AaE6BZ0rQogUvKGCbBQYMMh3wPIN7LaqUogZmIeIghTEki9mZHVpst3oF1qxe2Xi1Rbqx5PqTp+66g59ziTER2KPNOY2SssZd3lwVe0FWU9CrK3z9S9P42F89jFe/ey1+NnJ6TFYDJTuaZaAQVvBlrM+mxnvzhCA25HjUlXUZwcJ9rQXDePCHxTjEd7fugSK3j2yT7pViRWV9AJmgMcbkMbZaJt0yw1KdmWxGU7fhPoSBO6u4Wxt+VnjIWe4dU62+ybEv0qAWJo50/Il7Jv7AsqEUjsohiGV2UDe1YflcCfUZb68C7UoGVsLJL4gFCIzHKN/jCUwnJAUr+33DNVZha91xFbKuAXhQ33weWve/SwAjBQwVUBF40QILDIwYNFTAPIAFC5QKWCRg0QCLFrQIYGDAI4BGChgysMDgBQaVBIzCh5eIGbF/08ldq/X324SKwKdoCvNq+EokAKEM1hP1uja5lVzpcdRSygqjQPJTgmzMRAqoLHbYYUcsC7ZCoCyAM1hsr93XAkYKUNtopRKZUyxYStmOE1uBunGQfQGsXga9knDNex7GYjmP4/76WViHAvPDEhUBJRmUYOfXF7aVAFcq++A1MQv7B50oStTGzBr1nijb9uGY5azPCEZoHoWfaYXMbS1ny3FVzLKX8AHJjsEHlM9iql6fjKZpPkOy8kEccSNKoC8D654XRTEDJY6RzLA+K8UMF8Yr4to5RHU4eJm9RZB/SIPIXoWgqxvWctzPqgBU/kQZWJeZLANDBg8ZVBF46B/+CqCSwAOADICBBS8yaEQuuAb+5w8ZNIT7HuP/dJsg7mcZAqzygavBYVWosiDremC2lI7P2c/5E4cDP9vPMFaSmggBwFLKrUYpN7qn+iRKUW2kbgvEwm2ERegxuwMbKRU512Wn3MIowSwpCuihsth57c4oChWthILhXtF2KuzzzKcChVuoB9vG3m/TX5TSjWASmdiPB5ycagHbmYJao/Hh927Dr3/5IM78u6dj+a5dPIYSC0MbN3QqvyQw8pmZwe5Z8gFkfJlmUGtFRxyYSMiruofbwj30MWv6DBSye1JSh8NH1W3XyC9buMV+D7JZrgMMDmyxlRMvjywyJpBVjoxmCWTqHUlbMsgQtCHYisAlwCOGHbmMRIYAo9wFRidScgaMI3ZfP2Tw0Pp/dz8jlIZcElAp0MivgI0cd4TD360PtpH/t7AxYvwgwRC44rokseEgUKCKYxalRhkhmbskkGX/fqA+mBqAuApfSxEMZsVATww0ibLtHRYgUDZ+CWMwTtgMsdWkfOW/YVIg7D+lRy+nxCaxIOi2joIemrQaClgEpb2T9LuuszVFaieMwXOf9bQoXKFUXV8Xso0I61fP2HMX9FZMYVhWtUVH8LiJ0vNeIiTUXiQC1mbdOXsxNu0zgJ6E3qmPb3x+Gvd+914ceflKPOX0FVB7T6JADwzlASqDEdg/a0oEqet93WqahTEUHR2qimAqgjWAZndij0pGOXLyLyYY1Y3cw1kOLcqhNxYcEewQsEOARuz6IQOYEcPMOSQXFWAHBLvI4JFyUJXxwRP+HDBQedNrVsDAB4nxQWi87Gto/C1A1n+/9XNapphJAlqbzNmlGopQ5adaTa4Gkxh+lVE8IgqpyySxhGRrUcKwk6+FDCrV/XcY+aUEffYz3Fw1hsWqSzan55pUyBTUKUQvKL2WqT4g5DicotqFEss4aSDX0jYsClWfJ8UeALEgLoWgp+wI8IorKdDLsfKkusEVgDin9AYxNaK8Xw+2tkUXB+7/XJEUUPP+rbGCMedUEBYWh9j3yMvw0EOPQPV7ca7KpBIfWeR07IQCZjwn2qaK/Z4vDWtAysIuDIC5WUysBnb+gwlst+8y6B064B4wqhiDgUU5YthKoVp0wcQWqIYMM7IuWEfKZTBDMEOGHcFlosqVH6aEDw7nWQTrMhMkeSo0glYAcpSlh3zYT/WfdR8oyBQEsAoPBtfm6KiDqbbLqAnvIfsw1dklPgwkmEKcUpYTeSTOfTGoVZyQQqkm3CJq4ZXcYa9eeeMWuRpuIX9yy98g7Udk9chZV5bQjrglY6ZsNco4e7WssdimaxBmmm4iyeGR04YTvroVUyrODtPmNh+zTWx+KFtW4Ow3OTYaQTPhv79zI/bfdy8YY5wZu3/zi1yNw1qLyYkenr3XU/DQA78F9XsJAai+y7mYTsoScieaRxhtTPHu9lrvcmcr0MQE1FQfiyOLh/7T4qF/H7lVNEn4DMAB5JAf6eBcZZ8L6GjQUFbS29hzXTWJmVrtM5wQOCSpQQlmVobNsyAPsFApTBk84t4kGSBTRwoUTE4f1drqpx5nSZ1mQm4PK9RR/H2pHyYWeSjQWCmqQXC2NipJNBGcE2kjeVVEaPsySFm1mEW5McAApIIFoum3c/wTT1tsP8W9pLoSif2qZ7oRceMdC9VJcugRSfwxLXRIBrKOd9BVOBwrEmoEY5qjxx0gEFJPSivwsMJue+yGPffY2YU0qeQai5xUZYzzxz3ogOfgtq98x70ZllMVPbmUTNTk6YYyRlCI4Qf1FALJqmj9adiCOgzqSqdjriurBktGjWEfSSUQWaoJ0XNJ/cwFi1jO7OoJr3szlVM5DKijzD2Bb0+1kFnyxrEoaUmWSLKNooSzVD+ELdyr0HPL4I5ZNv0dcYPIUzaDa73c645ZQvl5KvEYSaWMcJ9VE40HNoB4lPywzE8LLWNKP7xKlJ2oMY0JgUL5sxgHI7Zh9ROfY8qAJOZYKaWPUyp/w6JUSFoFeGuZMHmh9kpI9AgxhhJtdjGCVaRhRwMcsO9zsHz5ZASw5LPTqokFAC886FlAr6iJKbJIT0gquYiXDwTyEDrpuu9RynNZFZiso79xbZbGsJ5SmdVUqPtuJwRUP8CSRUIkOS4iyKPdpspogkKnN+r3UkKBq2ea/vrDzwGEdlgI5FqFkBOOMCe7KMmt9MGQCuqLwpfzIK83vBzPnGL561BRI7adarf6sG6XHFi+HyRZt5IUF2/APrGcrxM/5/Lk7VylVr5g+7OX6o3nnHh5PqRyq5yoVXBNwSQxY22MjDlt/xii1UFyoMsgS/AgFhYphGxrj7N7WR90KTSsRLXj6aOqA1iFww45wAFYzA0h94Yzg3YQFw7a75nYebedse7x9VDdruuDpUq8LKkpRx3DNWXAC3Ekw4eHKiw0MMsNkaZTRLiRpFRGF6Y040S2VB2QFDdAVE0KIFkyZ9k92RZRddah8PNUHehAQ4FfmuOEACPh90pJUCzNbq7nuPWSRP2gGpCpHKHclA5X8PamTCzkTV07Q6zj+h7a5odph9RUUhN9JS0RrtQWlK2SMi2c79Z45VQkLvklnFhbx+DNxZWjJlW2054wJny2FkFNlODLtf1nDGKkv4vzigKN7TKKLRXFZ4tY6nFT9CBWy5bj8MOe51MSNU7JIl2idw+hMQarV03h8D/cBzfe+DBUv1cP4uXJ2HjvqBF4deLQNTIYsjAzSNsaLGFpCo6mOJjPbLJPrYGQbJ0xZl7UWy3JMDAtzWUQctiiimuKdclNctNFlIXBzCwvU4jroENzINfcCqSaaRUfqrD+ZirAjrwLYBBKsGmfRiq65KVlejZLRsuKYrb0FA7hpNyOD22mFiKkYNrCOe79JuuJ+X2oCSdy0kKiXAelrYnMlqGcp5iBORU0keARySojF5oLP5fF1lpzjJWU2/l6UbKbzNk7TyBJ5Ay9ta2FIJUqYBcrPHufZ2G/ffb0dNymzWHRduYHaP7Iww7A5z53e/rAy/9PbUvmhAbJM1kJZO9lyyCvROGunJMypj6882CltMfM/p4+gaoOSLmoHr4nZutsBTKuQuosMyPbQklJGCzIG/LzouWqQSZCKhsDt2vLwVvXlGAzAlVO+MBRWjm57+xFB+IdkCgyUUS00SAdUsagk4hTxstJelpOoZCY7XIn3GZpTI3HLC3DpTJFiF7iLGjzg6NRxXDy/YEaQ5l/dt3TikMk7J+TY/JQMt7iyLeOe+Cc3htq7Rm4LpZFv9usteQOsntuFWnYxQGOfNFB6PWc4F+ojpMSuplFnRUkATjqJQdh5U47YGZ+HqS1oIM1TwJKekGx5hfJ8/Lh8zdO+b4t8K2JG+8TZ48fkdzXRKKflAomU9rTqnpvuA7emltMJCVdkJTKtexLPrCn9O9BlSTutlKiiQShAUbkSdHVCCiHIDMCjwauFI7awuEh96g9UqVtEic7h8VyZlEG1z15rgcRxxR5lUttq6JpidlYUKNUPaIxbqG8aJf+A8GAVZbR3MToIwliXJaTCjEiY7MSc+4xvUrEV7jZr0s8gmqWF0fybY5GcstrRda2ULIDHPac5SqiZQI6XRx71AuSZ5+zsq0QWHp9C/wK31N22R4vOfQAfPnLd0KvWg5jLOTyg1RsaAR3IsClWvolrmeZ0m+4DZRArdcby0SGWMCXPrzyGkSwqlrpIZ+nUlQ+rD9PkWGlUrAr9tkB9aW4cxr7IeW8Zom0B+4YsCW4HILKAagaAOUQMCNXFof91mSxPA+sNHijCJwIa46iIQwpSldnCcoCjRpm1HlfDsp60AZQRIkMDOUrzNIlMGl9GI2oZyTyxHmZSzntSek4EqPWa6bMEij3GAoUTMFb92olxA2KldjcTsXZUxmc9MCEFK/jfAZOWUVEIGgQadjFCns8fS8c9sLnAmA3+82rXSI/RhKc2XpG7dg6Z530Enz5y3cJtk164qaIVguMQVlJ3QiyMYUHoVGOk1yQ9r4+aQ+bBacAr4hUU7AtAa1SdY90oVu89EQ1UagFKidJy8oX5NY62aDFOWA4B4wWQGYINpXrYaOQm5+Xc/rsSVSfxaAhMf6q2R5p4iBqBkcE9TjFJ1pbIcr6tqZ6YpgTkyQJUFaW+8OsmdlkkyuyraJmNUyUVQ/tOzSOUyGZCfkgmRvocK3OIenCyoGr0l+4QX5JF3oisCfn55xfS4qXJQQbBNUQ5SxoVRd2cQ6vOu7FmJrqoaoMtBTX4Lp1LPLyI9wq5W/8MS89CE99+m743cProLrdaK7VLEHGACTZfDYvq0jOvnIiQK6QELKdzCxC1ZByNYkAeFGmliAIGhKdTpQDVSpvGrOZ+F4nPetPb1uCR4ugchEo54HRAlANg61iXKEjpQHW6SHFoscimT1TdL/m6IrMqWTfytmByVnrkj1MDcwg7ZOj1EyLVFccPVG9oUUtgE3d2yGbUlBEykmCX8wtWRS1cXZDV0tsW+XWJSQSUxbLTPmKUP2PUcq2lWTBKUIf1FQT8kutcUZ5K8F1Bg7GByFw3TNcwBhCb9V2uODco9NKjNMTPmyyJyWrfGwqY7F82QTOPOEIXPX+66D6fVTGtsD7avxcryUDx744t2GBlJGlVOrEi5RRAjqloyCWIyRSIrjTrMvCIDv+vigijgRQkGh0YJaRD1gM50GjRWA05z6qYRIY7tboLMtxehggkERQH0yUZyvxsMkytI1Mk4yCqPneUEa4yND0yMYSmTSWerJsTuaJlJ3fnGEl3CIlk1YC1MpOojory8Ot9T+uKw05ppLMpRBoUQmTW3dyOGMVIsu4tVGVbREl5ISbLu8TN6pWTw6Ccprk0NC6BzO9gMOPOQT77PMUWGM9+4qb1WuyD0wtAoj+C19zxivwoY/c5JYblMqGhZz1MTm6mT+MMgCRZESSSBxlZTFqMIkgBdlqcKimVapEJJyQjY0k0CTnvmLRPLoBeJQXbMHlImg4Cx7MgEbzDoDyGtGsnP6wzDaUn+KJfpikU1J9MACp3pNMRKwyFhTGrqPJ2bVg+zeCHS3gSjLbCgdBMn+pcQ8iuVWTlvE1q4yyXpEawGkteUUpaSTpRbMGW9ImE7VUJOqpSZVJtRBDglHZ7B8ILZaeYnTELd5hbS+JRSzJ6iU6N2qfgQuHKVMXzCNcfP7RfvvIQhe6pbNJemBOkOTwn1IEYyye9fRdcfIrD8NnP3s7itWrYIzJ1OI5Y7bIclxlhAmViYa3sKPkvDYpY8XnggRqOMnFnJeoVoIkMfdln+0isEYU58ogAmsN0h2w6oDYgsoFYGErsDgDjGYBM/CIuYoyrAyVHjwy21CCgCDdPqiBjLzFYBmAcvyQtBbZiczZKIjSErmesVJ7L9gKXlGW+Sgb01BygBOaCwdELSNS5uZEqG380lDlFCiQyLp57BBlfbckILX0sywWDMZpXiUsr7C1ZbkZ/JwcywmhOr7fLMUOXdnMKKB0D3be4NkH7ofjXnmw8/jSqgX/rRNkkfav3F6aAHjzpafi87fcBWtMvYDVIFpIyJ+TE5dDvyZVOwKa7Bcfah9ilaLG8UbIoFYJiseU61JnqoJCHTDJTqTBRdcDSSUwmAUG08BwGhgt+j1Dn4lIgVXR0i/KykVlO3TyYFPJCR9ZVixmtomkLrdkbVEtyluvsh3SjChCGbi3tE48pdfNlKGLnIAx44hX3Cgjs0DiNKQon82i7Xu5JcVBAFHZOcASLsoUQLkmDbnz1avQsBVLIUJoTpA32AcyWYb0B6Nk9zilVbJMTrHv9d5T6IB0H3Y0wpsvfxUm+p3agSEDfeWIza0TxpGO3PcVehzWaWWdcsl7cfNN3xQjJZlpVHM7CCqzKtHJmISFEXj8HGTw1XPZBJTyBIZwQyIiKx9QL6buUGEl+l4CUeH8cohA1QJ4cRuwuA0YzoLKgZdDCTYrOeMqQ0jHILqEbL0PKaW0zr7pKZ1mPW4M+pGDFpShnY3BLqeHWwOqQrqW19xQR0NknmUA2fHTiSRjc9IbJ4w7ZHz7xmXk9raICDi3kH+ikCC3EKilwDxzLVjX6GP9rDcx+rNuuhAov4GIlBhyZ5xUrvtfCpt1TCJwCxA6INUDD4Cn7/0M/Pg778XEhJj7U1ul5D5bJDq0ecmXHbF//dbzcPs3v4eRsbXQdwrJifeSEkAohemz00g+wEqKi+fbR5IOWQt2E7VpGdcMLKjC9afK9xvlAmj2cdBwKzCcAZUDrwVVxHFQmAnGikFRviDYUnqyuM5MoDvZUFLp3DwiyxzJG0hGRNn70sAWmi1lPaenLCNw3l43U3BbRcZS7pRSOLcVtOHm6EY6zjcKvToI5DPJycHCWQbm7DBhIUQPtO79toBOlCwcyKC2dcnMQvs0Hg5j0GamZvCGBMcUM28onRldaN1FNRjh7W88AZNTRTo6SmIzPdRjUUs5P1h8veuFDZ6z9+644MxjYbfN+sGyTW8ScyLnndf/aNgjUhqkSbZujns4KZFVUmpHbx+lwapwp5vqgos+oAuHEM88Cqy7F3j0h8Dm+8Fz6x2ZQhcg3UlPN7bNvknIvtRz5Seaf8venbKZaRYjaC6gYxxVkNp6WBLMKE73WyEexAZjKAiB5WbuzQScBk8aUA1esR+zgNNMlgZhvY2WPEe2znLRekcazEkZnTzAE4RY2PW0Bb8MYoQlG66Dl+s/yRpHs2QpY8gJ+MgNywUxngwVpc+8zAWALnTRRzVb4pCXHIjzzz4UxtqUNjkWeATIGsOtM9wMLQzl9eMbtmH/Iy7F5m1bgW43zuHSGatOLTtUan9CsuxWqrbzjEQL8bVEqRIZKc851qLHVTEomDSg++7FVQvgxU3A/AZgNAeylS/PdQ2AyfGVaChrXnNWuifIbgsK3BrM44CalMvNgbsr2osGitxYP+O0vwrZpHUMhfZSvG38w239Zj5OyQJ63NdllMgG0i0EC2ozCG5OOBqHG0T/29YXi7ltUvoLXyTpkSQOieAhlY6MbC1YwbbmagsdMBaU2eA0Ust+uuBlrktnoAul+8AQ+PevvweHHbqnyL6SmNrG+yaMGeAiHRP5CzLGYuedVuOv334B7NyiM0+Oh17bhglnpx3GyrrUL78+YakB0dforQwuVhooJsDdKcdymn7YZdpHvg/a+AvQYJs7xSncwDpQmhUktdAWbTrY57YZJLVnyxY0h7LPJeqFUeIGja8nWaLFhwo18d//bxoXXFl2JBaZVGZAK5BWbglK5iXmn5wa1bHNzN98gMjPW057yyTbZuymvEoQC/lJRs4W+YmRvc68H7ZZdpduijbhgzPXoBYn4t7e5C/o8SYgVeEClwvABy6jA93pw2wZ4vJLjkuCl5ibhz43F07JGMOEbG4nvyHhz3LUx3rZaX+Kb3/7B9ArljlkWtIUE8MswTGOpAYljLRIZOHaUY68V06dscV6XyibVRdU9Nz1jWbB84+BZh8HygX3O3TH82VlYgnjFJVlUkpMyVICQM7wSoXHUtrdeE5LopwolBlSzpXg+rRm9JZRSgPkat97aUefuQVIy7JZXAXkJrWyQV7wPWSjDuH2bJ9k0LxAaUOkuQF61fPiMUi1aAeDEK/UAKuvP9tHz8r2pE9OWg5KqiDmmmHlEoYzymMuvNRtB4QCpHuwCxZP22N33Pvdd2PFSlfRqnztM5v9JrsLEoVunyuk5Za1zgj8p/c/jEOOvQKDsgQrSktpysya2z5kLwuheSW3h8S8FRFJ1qCi73xwbQXMrwfm1gHDbYgm3STc9SiTN00IJKoFQc68bESwk2wpGqwYqhe1Kd/Oa+EiZogwSeZTW++br/o1ACPKCA/pDJSzcr3ZsFFrANU/mtNSnlPjb86DmXlMC8FNUCk52GS5bbN5rUWLC9iYUdNS5X+oAgQSzrYeE2FMthftCdtU4CKWyyyFp33wksu8cVxEXYA60NQBz2vc/uW34qgjn4mqMii0qnem5UQhpyuH22WtbbeFb1DiatTZGIui0PiHj9+KP3rLNShWr4CpqhYBOJ1uAEH2tW3bQdSepYPlp+46B3U7BBY3AfOPA9WCb1t1KjgXwC9OecUNobpsF7NJmECCgkvyPo8BFnLWT3sfnL05gkoZ1tbSDYdMsz/J6M0ArGNsiSBNsiCaJnY5Lxlp4CaEfiCdnSZjJWqAXSz4AjTuMnlMIDJn3aEgkbR9r8yUxBmgxy2VRAqUUS63I4QJ4xI+U1xIcL0uRZYVPNpM6IDRAaGLojuBcsMi3vGuM/C3f3GsK52Vahlq5NRVTlRqyForOOvcqqLXVr0Ytii0xpmv/QBu/Nwd6Gy3ClVZCrlVaZRNmWNhEHuXwSs8YgPIFNQ0ir7TByrnwHPrgOEWwFaOZ6x0SsNrZNEUFeao0pHNVyklS3DCfkotIpv7rS1lKje5x7yUHpSk+xMycb204mZZClvOQLi2eWH+z9QU5+IGezMpf2XQkZizNpBpPFFmbCnfc/kbSLH2dHGB2mbWYzammocNxtAf23prmwZtUi0gHZd6bymEUlmUz86L2QUu0I2os5lmvPCw/fFvt14OXXDUZKe2w51obEj6EhpPHPkCiQ7kDqUI26YXcOjxb8EDv/o99FQfxovBR2ZV0hvnPaZK1+rCrCxkU9V1fx/NAwvrwKNpBz6pTv7Ip+VuoCYlergpUp4MyXOtZ26B7qMsK43xueEWxJdS2hSnWl/MY9hvDQ1WWUG3VUhoEi2yGTG3BEkNc1C2/tZ2aucILzcDs9GXNwXjGs+ZL5NZLrijKRQv57rxa5NNopw62XK9kgYqASz5tQ1EWh4g3CLt62e7HALYT1Miz9lxnEG9iDjzkLD9yh3wvbvejL32XAFT2ajWSmjvdccd93UJ3Rrp+elNyZaWZcfQuu/nv8OLT3orZhYHoE7hlCUb5AtqXfdLWVpB07kH6J5by1tYBx5u9TFUZMyoliBrbNhQTRCBLJPzDSjVZFWJ01DSMJsLc5Ta6LSWy2gl17cHcDsAlWelNjm5RHkxvz/MaMc78vc657MjLYuZWma6YwJVlJ3tTyI3LAoSbJG5KXDXGCVxfUiRFHTnxrhq7BxblvNJ1s6IKswN9QznSSVmvdBJ8BL1wOhCqT4IXfBCB1/94mU49qi9UFUWWlPLPVkigLleMvHODMINfOzWSDvpPfTDt915D0467y/A3Q6YnNkzS1WLrGyN2VkAXqwcMsdmBFp4HDzc7B21O0LPSqpEqjEECtXccfWLC60MZkqlapsKT1RzoUMoxZuIFDUWWAyPBQWXCGhKF0u47c3LAaKsR0JjJTELFm5A46nDQFKW5q8tz1YsqhIeS4msA0TONdtZfyRl4jk7rKSfitCvpkQwv43txS2ZOQ/itjJfgsCZggZTFrh18Lr1QEfUAPVBqg+tp1BtMfjHD70aV1zyPJSlQVGoJQ42Gv+5cNBHIgdLzdt01p8m5+ZuZwjij97wDVzyR1dDr1wOK+djRLmUhAjgoALZd38ONgKLG539il8caGZJ1ZKJW0QAEu5tQLHHMKbGChKIr4u+OnkOpRZgKjee4TRjI+hK89iUnb4tIvu2lcNols75JxJ+RhLIYp0vUWqkJXrXMaOa5KDgzOEPLfxrXrIYkUI2zbl9U3UyL+vr3t22M7ZkaY7UfcSV6oREjo59K8W1IXlw4HRBq+qyOfS9qo9OZznKzYx3vvNY/M2fHe6CV6vGrndjrLdUYHNLCR2NsRtpXA5Ts+zMQGUtOoXG+//pS3j7u69FsWYFrLHRE7cp46K85phbLKDRLLC4HrADDzSpeBODLKxc6m8to4MyB7WJoFAit5MsE4Bay9aGCFzbTW2luVE7qDJufCRZ5CxBtXHjknGIbdt1cjsbaxyrKf/hPA4kGtP7jrMMGTfowDiAK/3iRM62Ud7kLDC0lvac0z0Z4/d4E86x2GEP0kRQINa+bdGCIqkB6sTgJepDdyZRbTS4/LUvx4f/7ihUlfUWwzR+iLHkjas55i6AY6xmulgtjgER9MgxBD8jLgqNP//A5/Deq25AZ81ymMoKVktKu2TVBdkSvLAOKKc9QaNIg06pBpmCmVLudo4kN+w90u9PSuSGMoiMv6YoQWtvSmMEVRsOd82d60b/KTSuWTCmuI3k0L66g3QrisFth0ojEHhM0q3dDZvEE86AuBbHxBZEPJd+o0Y/TI0et2EGhrp6qCt2zn6MRJG5Nds3rD05H9kFDTYxSvTocly6iWwrN+cFdQDqgagHXUyh2mpx6cUvwb9c/QpY61cWSdzbPEyJ2nECuSAUEm0yB2ZuB1AyUbJExTcjblk/XvrzD9yI9151A4pVy2CtccBW1FFSAHWB0Tbw4jpHyFBFLCspWUtUKYKNfAQkMrooHxu+B6SE9Qol5IbEt4eXYi+lrKv6r2N4z5lZFlObtEx7WUzJlBNjAmNJ7lfbvsSY7RwanwklkERL/JwxWZyzkfOSzKxxvzf/aZ6TPDaoxS9jy6nm1rjM5nto4jpw68osCDcoT8wI/W7HldERsNJ18Oo+tJ5AtZXwxiteig/99REw1maLQ20EjaWAq+bX+Qw8ru5uZ2O12YLEEhzupmmt8L5/+gr+9K8+DprsOWpkNXJAFQhYXAcebYsMLKlqQcJZoUljbMm8QPNz43ralvlwai+TjV4a6DTaf0fi1tcme/NEFRI3mFdJewSMMfEcQ9RoLfFT9lNqNt2kOEZYqKGAQ2lAUHs2e+IAzf6duP3lJQeXvBOcanUxjS/381auhdnEolyuJYNVq/Ack19IoMJnYN/zUheq6AOqDzuj8fY3H4X3/emhUZKZcpPARkfR0rqCxn4+ltASdAilc1Ncu6WfHQN5G+sy8Uc+fReueOe1KBnQvQ7MYBYYrgfMoFbkIM6cA5tCdIlaRVIup+t00adX0gmlaHcmTZv3iYQW5JfyrZ7siRZugem519aXUWvp3OY31I7rZNpT40C3th6+rdQFN+VTM8Q4iX3KKQJiA2pJMsj4bC1L4IRKJIy+qT0iW6oSbm4hJRfeMoVAzaaqJYfCe+7KZPIlM0P7Nk+DKJTLDm1mdKE7EzCmA1R9/N17jsabL94fxpjY7zYOEPFnbs0adcfCRCLiAPWiUZqB8yw8Ri6pUbrktRql6PQ3v/tTnPX6D2HTww+h6M/DlCMHVHmVg9R/NlOdpIbocTOAuaUXZozfo6TMUZE5U9JoKYujllE2CmqrXMRKXqN0y0c5Ir2ytO8UatDp/W626HGJPZeADQv9qJf2KMt+1OhMa8mYWj4rFTLIR1zUSkghsa7J2VHLDTAm9Z9BU45rDABWs7PSsZM0S28N1mQeIGi3QcMNwee5ZTREoVTugFQXTD2AuiiKPqoFYNWq7XHtVcfh9GP3QFUZKGm5s2TZ3Ka2Qk36pLyXaQmNjECdA6sZyDCuHBEPifHA1v2/fhTnXfxW3HP3PdBrtgNbGx0POcs41AZKxfhUghiSG1kg9SIKWTbvYZM9WW72uW09cHIy5oFCzdQDXmI2Mg6tTYkzKZq+FA2Tlp4itbZ8uc14XtGTcOlreRhoqUMpPdRqCiZlSPD/cv7ZCvK39L5tM/dcWTOCmHWpXM9yBdUXzmEDVES0mVA4sQjqAqoH1ZkEqS7MliH22fcZ+NSHjsMBz16dznnHkTNy0YUGG80fRUTtGmQBxAriejQWgc7odkRLAdytZI+5hUW85Z1X4yMfvRHodlD0+zBlmYqdJSXaGKSZxojFAw1TseTCVPZ91AbqPokAbmRd1bqmV2f3ce3gGKSVM5tZHofgNpSWa/iOluq1W/rIxpQ28xnK6vZWOYBGaU/isREHBnN7Oyyr3LzyoDZwMnMgFJ7BnACBbYL2KqqUctRz06Js1vHfXKms/UKCBlMHUF1QMeFGRCMFlF1ccNof4Jp3vQSrlhco/WZRa93KLY4Rre0VPSHIJVBozvqEcbVzixYWyxvMjuCdUfZCEAPAjbfcibf+2dV45NcPQa1a5Q4PG/YtRbEmOfeCr5w4MyROM0z0JAAAC4tJREFUgXnQcwsZg57gYKelEei2g6J1DmxbVvLSB7jmY2eL8zS+bUxvPY9PTy0HbF1oLTF7HUsEyV83GuObvEQlWeEwt01BslZCtc+GswonWXEcw6BiRlOFNLnawMUP0sM6fjC0B660A6uo48AqKtxSgupAdSYB1YNdUNht97W48k2H49wT9gIAVMZCK3pyFQZzfnJlLSE3KxvpfcXWMicjJNmxUGtDUs8Fszc8b1pa5srWMopCY93jm/Dnf/2P+NgNXwIso1g2BWuNm5NxM4DrvgRilktNxzqZJRgtBJIxALv8nBART6uNFOhKVQPbKI1LjS9aZiz5A9kqTv4ERIn8qyRBvu33iuCqAfB89s/ZLnSj4WmDjdNMzy3zTTSXpJI3pWE4IDjswnw7YW42KvB0ksHJUku9qkrwemqRUaX98+YCNvS8SvdBnQmYRQPoCVz+6kPwV284FDus7qZIc9bDNsjybaQUamn85VomcvXRLAO7vmdMYdyWdRsjFEoKwsgZzkpuYwyKwhE2vvmtH+Cdf/kP+K8f3gdM9FD0e7BV5VzmmRt03QSAkj5BcjmhUUHQmLaRxv6bvPaEzZSd5LQkkaMlk/BSM9i2nq590b61jKUnF9vpoUJZy9TYRGhgc0tl67af3RpYDcJQSxVD1KzNxfSgrapJDnEWvlkxgKXFrPIZVvtM7Pd24ypsAaYOSPf8RxdmBKAscNDz9sRfv/ElOPqFu7msW/msS2Pg3iwwI6Vb7CGkPTs3DrNYecoMHEGsVh4mx/kYIW/OnqApT3plTrKcK5kZFoxCa5SlxSc+eyv+5oMfx+9+8SDQ70H3e2C2YGtTqVBa2mWeMwfd9vKTGkhp/mClE0XBqZYrizzufKAWFQgaC2JxJmvXugXWSl1sD9xkIwltTLoxLRI1587UOL95TADncFgqHTQGRxKyq1nizaqeCFwm1OvatzfOccXWm3QCSex4gpEAKbdTHnvewv97AKoKqM4EoPowQwIqhb2esQvedO4huOS0fdEtCGVloBWNsRttwyJ4zHuSxV/CvkqztJycCC70GPSSuT3lNyooav/3NpKI+JmyN960ZRrX3/AV/PPHbsRDD/wa6HagJiehyMnaOlYNjyUxNLJvIqdMbueyAfhSO1khRzGTN4RaYAIaT1Ro2UGUy/30BOVxGnT5/ZeKiM1ZckOdJR8ZUnrgNJUuWg5B5vaRoggkSteZWw/JttvNifthvqxCDevZNJgpGpsnK6tQiaZa3Dsn52fFpH2P61Fm1YUqOqi4AwwBUA/P3WdPvOHVB+PVRz8LK6Y0mBnGcGMVMOFst1an3AorNaosalHxbBA6lFfkSPYtmm9k64jkiaD+pdCzjLLp5H/rsnrb9Dw+e9MduO6zX8E9P/wJMBwBkxPQva4AvKzTDG5LhAlizHELidAEQ8JwvZ34Qq1kCG6hkEQ1kNylntu9jmKPzOmmUTMYshYkWYXLEdum7HxbSU2Z9pQ85Ckz9uKGudn4h1AKB0pchgXbjaQ3E7Vd/7hNsdopEVyvfyZldeSrq2RzLYohxpJZun44PyzSXSjdgWECjwCUCmrlCrzkoKfj4lMOxklHPBMTXYrlslKUwj8RJ0izWIIfJHatYwDI1vgag0ijoYnVgiznv6zhxtBC++K2uTHSF8fUcqgwjLHodFwgW8u469v/jRu/8m+4467/xCO/+jVQVUC/B+r1nHautXBdgM1OZzHrJBKjtvrkBrWZQmeHQMOsoknMj2GRI7+yX6VGC5soZVDrTFiw4WRJGaVNuXYvEMFDyRaPPyCSU8HPeDMkPXg/N61CqWV2LDJmYqVESdZNxjnJQZZOLmpYrOnHzMKFg6VYOol/gzTQq7W/KfS9qkabSWkQaZDqgFUBAw1UChgxMNHD3nvthuMP3xdnHLMvDnr2jvE+VBVDadHucKqbjqRlbIsTGZziNbd4GLdLWrWpUlrLaJIms5KguX0ULB05YYlwaqnSGE2N23RqkgyC+mX4mq3b5nDXt3+Ib9x5N/79Bz/Gg7/+LTA3D2gCuj2gU0Bp7b1UvYJh3Bhr69va9lCpiQrREn60jR6V0JR9HQOatapZZBkuoYRys02B0IamNoLFOEQrs7cfMwpq/1zulN3WciyxW53rkcl/k3YykgcPlQkW6hZ+fCqOGHpb8kbs0K5EtgCsscDIAhUDRR/97Vbh2XvujmMOezaOOeyZOPBZu2Cyr30SsbAWjYy7BJ91yee+vTptKekaHsvIdvZd/Dhd6LHLw8g40gKmIBrfnGfbS0uW3XE+2CTdMwA2bhVRF0X8loXFEf7np7/Cv9/9X/jhj36Gn/zsF3hk3SYM5xaA4cDdvKIACg1oDWi1xAw4N9XllDIZFyvGMaZygzJueaOoRbdqjMNB64BlDKMr11MGxgKKS6piYhxe0SZfkB0wS5Kf2ySKMors2HVQYZAXe1rh1Cf9n0mBlXCy9J5ELloZMP59UAUwMYlVK/vYc9e1OODZT8VhB++NQ/ffA8/YfXtI3kVVGRCRE5trw3VEr5og+O1Q/RIjxKWCeFx3Wie/piaWFMsmap/XPVHPm+8XPwmRvHE0usgH9lkZoAh6hf/m5hbxyGMb8cvfPIz7H3gIv/zV7/Hw+q3YvG0rtmzajG1zC1gcDDEale5nBEtPqv2Co0ROwqV2IvIUVhHZeksNjhKq0QNZiS2qKAPjy1UvF8qW4w6te+2qBta8D5C1Jt5AV+pR1HiKY7Ugf2SquM4oPZKl9EwYx8mglaWmlGFljym4UrPpLCF/NokyOLE+BoG9b65SyplpSxtRUlC6qMUjuBZtCA+xUrXPFXkXSreq6u6J0oXbbuNg1k0RkFJaodftYGqii2W9LlavWIYd1qzEM562M/Z+2s54zjN3wzN23x677LAiFVBnRmXcs6FkQqHxGM5Ydl1b/zo2A3ONxD8BM7kVR2rbB24E2Jif2Cqu0KDdtTC10E7DfCIebA16se97GaQIhdbtZ4oF5hcWMb84wPz8AIuLA4dmA1D+wVPB98gHB2Xi6qTc14ZrtsKeg4VFJlFAuaUncm1Lw5kYulP1FAHs91yNrzjcz1P19TA35qVsbBPkklsv/vfYgA+E64RLSvD3QfnXb6yN94CkGwMF5xGOiZH8hldcGxC2oda66w8BbP21OxBL+QD190E00Wzd+6miAmg9srPMcPFF0ErFBBGW6RiAVgpaa0xO9LBssouJXoHJXhdKU2sWM8Zb0Whynpnj1D2XAGSlkB4ROVeaxDs7a6kSl4sUf0iXUVpHOg0cqmFuNnY/EU/iJGpZkUrWucDpMJpofJEh+jdqE3fL3oz6NHbbMqSVC7wnQsv////+P/2fPOzjQRur9qXK22bgtbYaWTndloRYTF2aCbhWmOSEj0FL9sKBYVdTKZ/8LUHrgvETBbjYMW72Z/TEPcL/4vPhhJMKkpyoGebm1oR0ksot8HMu5t4mbZcqXNWCeilHqc1jeOzvznQcxyaJliMuFSpoaYeJErmeNmEDecMpI2qkO9XjsgaWEKxrfyOfDKFMsF2z11THHi0hiN5o5Z4QExhjdTIu6PAkVDbaymk0yTFPuoRu1zz+Xx13jbUnGkP8a1d3TE/A1uX68fhmmrjpyTbv/7eOeiyxJsTtbg7xPW8JtCc6oDJ+ScOIDHkRlP0OfvL3pG2n9wlX0PBkf3bLe4YWSaHGtbQfTv/b15cAQuOe+0TYkdo1Ap/EL26VqnoSFeJS8ajaxA7Hvoi2wGFeUtSFuT2C8glHwwL3iYKXOUl03JixNs3AaBzhaQnTPempnQ7bBWYhwdRWSRhqXK+8IOYlFByXmF6N8yZjObPnZi6vW+UxlU+b6TgvIVBJT3DdbQ+WILK0r0Qz2glGnBBckst4AnWh5B5ybtnagrdzW3pPw5RyUD73MWrITgurXWQrqpLhlrDduPnesLsv/y/vgYX2dTxLiQAAAABJRU5ErkJggg==";


function GoogleGIcon({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg" style={{ flexShrink: 0 }}>
      <path fill="#4285F4" d="M17.64 9.2045c0-.6381-.0573-1.2518-.1636-1.8409H9v3.4814h4.8436c-.2086 1.125-.8427 2.0782-1.7959 2.7164v2.2581h2.9087c1.7018-1.5668 2.6836-3.8741 2.6836-6.615z" />
      <path fill="#34A853" d="M9 18c2.43 0 4.4673-.8059 5.9564-2.1805l-2.9087-2.2581c-.8059.54-1.8368.8591-3.0477.8591-2.3436 0-4.3282-1.5827-5.0359-3.7104H.9573v2.3318C2.4382 15.9832 5.4818 18 9 18z" />
      <path fill="#FBBC05" d="M3.9641 10.71c-.18-.54-.2827-1.1168-.2827-1.71s.1027-1.17.2827-1.71V4.9582H.9573C.3477 6.1732 0 7.5477 0 9s.3477 2.8268.9573 4.0418L3.9641 10.71z" />
      <path fill="#EA4335" d="M9 3.5795c1.3214 0 2.5077.4541 3.4405 1.346l2.5813-2.5814C13.4632.8918 11.4259 0 9 0 5.4818 0 2.4382 2.0168.9573 4.9582L3.9641 7.29C4.6718 5.1623 6.6564 3.5795 9 3.5795z" />
    </svg>
  );
}

const DEMO_ACCOUNT = {
  identifiers: ["demo@ipobazaar.com", "9876543210"],
  password: "password123",
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MOBILE_RE = /^[6-9]\d{9}$/;
const DEMO_OTP = "123456";

function SignInScreen({ t, onBack, onSignIn, onSignUp, onForgotPassword }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState("");

  const fieldInputStyle = (hasError) => ({
    width: "100%",
    background: t.surface,
    border: `1px solid ${hasError ? cardColors.red : t.border}`,
    borderRadius: 14,
    padding: "13px 14px",
    fontSize: 14,
    color: t.textPrimary,
    fontFamily: "inherit",
    outline: "none",
    boxSizing: "border-box",
  });

  const validate = () => {
    const next = {};
    const idVal = identifier.trim();
    if (!idVal) {
      next.identifier = "This field is required.";
    } else if (!EMAIL_RE.test(idVal) && !MOBILE_RE.test(idVal)) {
      next.identifier = "Enter a valid email or mobile number.";
    }
    if (!password) {
      next.password = "Please enter your password.";
    }
    return next;
  };

  const handleSubmit = () => {
    if (loading) return; // prevent duplicate submissions

    const fieldErrors = validate();
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      return;
    }

    setErrors({});
    setLoading(true);

    // Simulated auth check — replace with a real API call later.
    setTimeout(() => {
      const idVal = identifier.trim().toLowerCase();
      const matches =
        DEMO_ACCOUNT.identifiers.some((d) => d.toLowerCase() === idVal) &&
        password === DEMO_ACCOUNT.password;

      if (matches) {
        setLoading(false);
        onSignIn(identifier.trim());
      } else {
        setLoading(false);
        setErrors({ form: "Incorrect email/mobile number or password." });
      }
    }, 900);
  };

  const handleGoogle = () => {
    setToast("Google sign-in coming soon");
    window.clearTimeout(handleGoogle._t);
    handleGoogle._t = window.setTimeout(() => setToast(""), 1800);
  };

  return (
    <div
      style={{
        flex: 1,
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        background: t.bg,
      }}
    >
      <div style={{ padding: "18px 16px 0", flexShrink: 0 }}>
        <button
          onClick={onBack}
          aria-label="Back"
          className="ipo-card-btn"
          style={circleBtnStyle(t)}
        >
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
      </div>

      <div
        style={{
          flex: 1,
          minHeight: 0,
          overflowY: "auto",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "12px 24px 28px",
          boxSizing: "border-box",
        }}
      >
        {/* Logo + app name */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 12,
            marginTop: 8,
            marginBottom: 30,
          }}
        >
          <img
            src={IPO_BAZAAR_LOGO_SRC}
            alt="IPO Bazaar"
            style={{
              width: 84,
              height: 84,
              borderRadius: 20,
              boxShadow: "0 14px 28px rgba(22, 83, 214, 0.32)",
              objectFit: "cover",
              display: "block",
            }}
          />
          {/* Wordmark sits on a fixed navy chip in both themes so
              "Bazaar" reads white and stays legible either way. */}
          <div
            style={{
              display: "flex",
              alignItems: "baseline",
              gap: 5,
              background: "linear-gradient(155deg, #1B5AE0 0%, #071E4D 100%)",
              borderRadius: 999,
              padding: "6px 16px",
            }}
          >
            <span style={{ fontSize: 16.5, fontWeight: 800, color: "#BFD4FF", letterSpacing: "0.02em" }}>
              IPO
            </span>
            <span style={{ fontSize: 16.5, fontWeight: 800, color: "#FFFFFF", letterSpacing: "0.02em" }}>
              Bazaar
            </span>
          </div>
        </div>

        {/* Heading */}
        <div style={{ width: "100%", textAlign: "center", marginBottom: 26 }}>
          <div style={{ fontSize: 24, fontWeight: 800, color: t.textPrimary }}>Sign In</div>
          <div style={{ fontSize: 13.5, color: t.textSecondary, marginTop: 6 }}>
            Sign in to your account
          </div>
        </div>

        {/* Form */}
        <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 16 }}>
          <FormField t={t} label="Email / Mobile Number">
            <input
              value={identifier}
              onChange={(e) => {
                setIdentifier(e.target.value);
                if (errors.identifier || errors.form) {
                  setErrors((prev) => ({ ...prev, identifier: undefined, form: undefined }));
                }
              }}
              placeholder="Enter email or 10-digit mobile number"
              autoCapitalize="none"
              autoCorrect="off"
              style={fieldInputStyle(!!errors.identifier)}
            />
            {errors.identifier && (
              <span style={{ fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                {errors.identifier}
              </span>
            )}
          </FormField>

          <FormField t={t} label="Password">
            <div style={{ position: "relative" }}>
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password || errors.form) {
                    setErrors((prev) => ({ ...prev, password: undefined, form: undefined }));
                  }
                }}
                placeholder="Enter your password"
                style={{ ...fieldInputStyle(!!errors.password), paddingRight: 42 }}
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="ipo-card-btn"
                style={{
                  position: "absolute",
                  right: 4,
                  top: "50%",
                  transform: "translateY(-50%)",
                  width: 32,
                  height: 32,
                  border: "none",
                  background: "transparent",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                }}
              >
                {showPassword ? (
                  <EyeOff size={17} color={t.textSecondary} strokeWidth={2} />
                ) : (
                  <Eye size={17} color={t.textSecondary} strokeWidth={2} />
                )}
              </button>
            </div>
            {errors.password && (
              <span style={{ fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                {errors.password}
              </span>
            )}
          </FormField>

          <div style={{ display: "flex", justifyContent: "flex-end", marginTop: -6 }}>
            <button
              onClick={onForgotPassword}
              className="ipo-card-btn"
              style={{
                border: "none",
                background: "transparent",
                padding: 0,
                fontSize: 12.5,
                fontWeight: 700,
                color: t.blue,
                cursor: "pointer",
              }}
            >
              Forgot Password?
            </button>
          </div>

          {errors.form && (
            <div
              style={{
                background: cardColors.redSoft,
                border: `1px solid ${cardColors.red}`,
                borderRadius: 12,
                padding: "10px 12px",
                fontSize: 12.5,
                fontWeight: 600,
                color: cardColors.red,
                textAlign: "center",
              }}
            >
              {errors.form}
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={loading}
            className="ipo-card-btn"
            style={{
              width: "100%",
              height: 50,
              border: "none",
              borderRadius: 25,
              background: t.blue,
              color: "#FFFFFF",
              fontSize: 14.5,
              fontWeight: 800,
              cursor: loading ? "default" : "pointer",
              opacity: loading ? 0.75 : 1,
              marginTop: 4,
            }}
          >
            {loading ? "Signing In…" : "Sign In"}
          </button>

          {/* OR divider */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "6px 0" }}>
            <div style={{ flex: 1, height: 1, background: t.border }} />
            <span style={{ fontSize: 11.5, fontWeight: 700, color: t.textSecondary }}>OR</span>
            <div style={{ flex: 1, height: 1, background: t.border }} />
          </div>

          <button
            onClick={handleGoogle}
            className="ipo-card-btn"
            style={{
              width: "100%",
              height: 50,
              border: `1px solid ${t.border}`,
              borderRadius: 25,
              background: t.surface,
              color: t.textPrimary,
              fontSize: 14,
              fontWeight: 700,
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
            }}
          >
            <GoogleGIcon size={18} />
            Continue with Google
          </button>

          {toast && (
            <div
              style={{
                textAlign: "center",
                fontSize: 12,
                fontWeight: 600,
                color: t.textSecondary,
              }}
            >
              {toast}
            </div>
          )}
        </div>

        {/* Bottom sign up link */}
        <div
          style={{
            marginTop: "auto",
            paddingTop: 28,
            fontSize: 13,
            color: t.textSecondary,
          }}
        >
          Don&apos;t have an account?{" "}
          <button
            onClick={onSignUp}
            className="ipo-card-btn"
            style={{
              border: "none",
              background: "transparent",
              padding: 0,
              fontSize: 13,
              fontWeight: 800,
              color: t.blue,
              cursor: "pointer",
            }}
          >
            Sign Up
          </button>
        </div>

        {/* Footer signature */}
        <div style={{ width: "100%", marginTop: 22, flexShrink: 0 }}>
          <div style={{ height: 1, background: t.border, width: "100%" }} />
          <div
            style={{
              textAlign: "center",
              fontSize: 11,
              fontWeight: 600,
              color: t.textSecondary,
              letterSpacing: "0.03em",
              marginTop: 14,
            }}
          >
            IPO Bazaar • 2026
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   SIGN UP SCREEN
   Same visual language and theme handling as SignInScreen (follows
   the app's selected theme via `t`, no hardcoded exceptions). Three
   internal steps: the form, a brief success state, then a mock
   OTP/email verification step. No backend exists yet — swap the
   setTimeout blocks below for real API calls when auth ships.
----------------------------------------------------------------*/
const MOBILE10_RE = /^\d{10}$/;

function SignUpSpinner({ size = 16, color = "#FFFFFF" }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        border: `2.5px solid ${color}55`,
        borderTopColor: color,
        animation: "ipoSpin 0.7s linear infinite",
        flexShrink: 0,
      }}
    />
  );
}

function SignUpFieldStatus({ t, state, size = 16 }) {
  // state: "error" | "valid" | null
  if (state === "error") {
    return <AlertTriangle size={size} color={cardColors.red} strokeWidth={2.4} />;
  }
  if (state === "valid") {
    return <CheckCircle2 size={size} color={t.blue} strokeWidth={2.4} />;
  }
  return null;
}

function SignUpScreen({ t, onBack, onSignIn, onSignUpComplete }) {
  const [step, setStep] = useState("form"); // "form" | "success"

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    mobile: "",
    password: "",
    confirmPassword: "",
  });
  const [touched, setTouched] = useState({});
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [formError, setFormError] = useState("");
  const [loading, setLoading] = useState(false);

  // Inline OTP verification for the Mobile Number field — lives
  // directly under that field, no separate OTP screen.
  const [otpSent, setOtpSent] = useState(false);
  const [otpDigits, setOtpDigits] = useState(["", "", "", "", "", ""]);
  const [otpStatus, setOtpStatus] = useState(null); // null | "error" | "expired" | "verified"
  const [otpMessage, setOtpMessage] = useState("");
  const [resendSeconds, setResendSeconds] = useState(0);
  const [otpExpiresAt, setOtpExpiresAt] = useState(null);
  const otpInputRefs = useRef([]);

  useEffect(() => {
    if (resendSeconds <= 0) return undefined;
    const timer = window.setTimeout(() => setResendSeconds((s) => s - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [resendSeconds]);

  const validateField = (key, values) => {
    const v = values[key];
    switch (key) {
      case "fullName": {
        const trimmed = v.trim();
        if (!trimmed) return "Full name is required.";
        if (trimmed.length < 2) return "Enter at least 2 characters.";
        if (/^\d+$/.test(trimmed)) return "Name can't be numbers only.";
        return "";
      }
      case "email": {
        const trimmed = v.trim();
        if (!trimmed) return "Email is required.";
        if (!EMAIL_RE.test(trimmed)) return "Enter a valid email address.";
        return "";
      }
      case "mobile": {
        const trimmed = v.trim();
        if (!trimmed) return "Mobile number is required.";
        if (!MOBILE10_RE.test(trimmed)) return "Enter a valid 10-digit mobile number.";
        return "";
      }
      case "password": {
        if (!v) return "Password is required.";
        if (v.length < 8) return "Use at least 8 characters.";
        if (!/\d/.test(v)) return "Include at least 1 number.";
        if (!/[^A-Za-z0-9]/.test(v)) return "Include at least 1 special character.";
        return "";
      }
      case "confirmPassword": {
        if (!v) return "Please confirm your password.";
        if (v !== values.password) return "Passwords do not match.";
        return "";
      }
      default:
        return "";
    }
  };

  const validateAll = (values) => {
    const next = {};
    ["fullName", "email", "mobile", "password", "confirmPassword"].forEach((key) => {
      const msg = validateField(key, values);
      if (msg) next[key] = msg;
    });
    return next;
  };

  const handleChange = (key, value) => {
    const nextForm = { ...form, [key]: value };
    setForm(nextForm);
    if (formError) setFormError("");
    if (key === "mobile" && otpSent) {
      setOtpSent(false);
      setOtpDigits(["", "", "", "", "", ""]);
      setOtpStatus(null);
      setOtpMessage("");
      setResendSeconds(0);
      setOtpExpiresAt(null);
    }
    // Live-clear/update errors once a field has already been validated once.
    if (touched[key]) {
      setErrors((prev) => ({ ...prev, [key]: validateField(key, nextForm) }));
      if (key === "password" && touched.confirmPassword) {
        setErrors((prev) => ({
          ...prev,
          confirmPassword: validateField("confirmPassword", nextForm),
        }));
      }
    }
  };

  const handleBlur = (key) => {
    setTouched((prev) => ({ ...prev, [key]: true }));
    setErrors((prev) => ({ ...prev, [key]: validateField(key, form) }));
  };

  const fieldState = (key) => {
    if (!touched[key]) return null;
    return errors[key] ? "error" : "valid";
  };

  const liveErrors = validateAll(form);
  const mobileValid = MOBILE10_RE.test(form.mobile.trim());
  const canSubmit =
    Object.keys(liveErrors).length === 0 && agreed && otpStatus === "verified" && !loading;

  const fieldWrapStyle = (key) => {
    const state = fieldState(key);
    return {
      display: "flex",
      alignItems: "center",
      width: "100%",
      background: t.surface,
      border: `1px solid ${
        state === "error" ? cardColors.red : state === "valid" ? t.blue : t.border
      }`,
      borderRadius: 14,
      boxSizing: "border-box",
      overflow: "hidden",
    };
  };

  const bareInputStyle = {
    flex: 1,
    minWidth: 0,
    border: "none",
    outline: "none",
    background: "transparent",
    padding: "13px 12px",
    fontSize: 14,
    color: t.textPrimary,
    fontFamily: "inherit",
  };

  const handleSubmit = () => {
    if (loading) return; // prevent duplicate submissions

    const allErrors = validateAll(form);
    setErrors(allErrors);
    setTouched({
      fullName: true,
      email: true,
      mobile: true,
      password: true,
      confirmPassword: true,
    });

    if (Object.keys(allErrors).length > 0) return;
    if (otpStatus !== "verified") {
      setFormError("Please verify your mobile number with the OTP sent to you.");
      return;
    }
    if (!agreed) {
      setFormError("Please accept the Terms & Conditions and Privacy Policy to continue.");
      return;
    }

    setFormError("");
    setLoading(true);

    // Simulated registration call — replace with a real API call later.
    setTimeout(() => {
      const emailVal = form.email.trim().toLowerCase();
      const mobileVal = form.mobile.trim();
      const taken = DEMO_ACCOUNT.identifiers.some(
        (id) => id.toLowerCase() === emailVal || id === mobileVal
      );

      if (taken) {
        setLoading(false);
        setFormError("An account with this email or mobile number already exists.");
      } else {
        setLoading(false);
        setStep("success");
        window.setTimeout(
          () =>
            onSignUpComplete({
              name: form.fullName.trim(),
              email: form.email.trim(),
              mobile: form.mobile.trim(),
            }),
          1400
        );
      }
    }, 1100);
  };

  const handleGoogle = () => {
    setFormError("");
  };

  const handleSendOtp = () => {
    if (!mobileValid) {
      setTouched((prev) => ({ ...prev, mobile: true }));
      setErrors((prev) => ({ ...prev, mobile: validateField("mobile", form) }));
      return;
    }
    setOtpSent(true);
    setOtpDigits(["", "", "", "", "", ""]);
    setOtpStatus(null);
    setOtpMessage("OTP sent successfully");
    setOtpExpiresAt(Date.now() + 2 * 60 * 1000);
    setResendSeconds(30);
    window.setTimeout(() => otpInputRefs.current[0]?.focus(), 50);
  };

  const handleResendOtp = () => {
    if (resendSeconds > 0) return;
    setOtpDigits(["", "", "", "", "", ""]);
    setOtpStatus(null);
    setOtpMessage("OTP sent successfully");
    setOtpExpiresAt(Date.now() + 2 * 60 * 1000);
    setResendSeconds(30);
    window.setTimeout(() => otpInputRefs.current[0]?.focus(), 50);
  };

  const verifyOtp = (code) => {
    if (otpExpiresAt && Date.now() > otpExpiresAt) {
      setOtpStatus("expired");
      setOtpMessage("This OTP has expired. Tap Resend OTP to get a new one.");
      return;
    }
    if (code === DEMO_OTP) {
      setOtpStatus("verified");
      setOtpMessage("Mobile number verified");
    } else {
      setOtpStatus("error");
      setOtpMessage("Incorrect OTP. Please try again.");
    }
  };

  const handleOtpDigitChange = (index, rawValue) => {
    const digit = rawValue.replace(/\D/g, "").slice(-1);
    const next = [...otpDigits];
    next[index] = digit;
    setOtpDigits(next);
    if (otpStatus === "error" || otpStatus === "expired") {
      setOtpStatus(null);
      setOtpMessage("");
    }
    if (digit && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
    if (next.every((d) => d !== "")) {
      verifyOtp(next.join(""));
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  return (
    <div
      style={{
        flex: 1,
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        background: t.bg,
      }}
    >
      <div style={{ padding: "18px 16px 0", flexShrink: 0 }}>
        <button
          onClick={onBack}
          aria-label="Back"
          className="ipo-card-btn"
          style={circleBtnStyle(t)}
        >
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
      </div>

      <div
        style={{
          flex: 1,
          minHeight: 0,
          overflowY: "auto",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "12px 24px 28px",
          boxSizing: "border-box",
        }}
      >
        {/* Logo + tagline */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 12,
            marginTop: 8,
            marginBottom: 24,
          }}
        >
          <img
            src={IPO_BAZAAR_LOGO_SRC}
            alt="IPO Bazaar"
            style={{
              width: 72,
              height: 72,
              borderRadius: 18,
              boxShadow: "0 14px 28px rgba(22, 83, 214, 0.32)",
              objectFit: "cover",
              display: "block",
            }}
          />
          <div
            style={{
              display: "flex",
              alignItems: "baseline",
              gap: 5,
              background: "linear-gradient(155deg, #1B5AE0 0%, #071E4D 100%)",
              borderRadius: 999,
              padding: "6px 16px",
            }}
          >
            <span style={{ fontSize: 15.5, fontWeight: 800, color: "#BFD4FF", letterSpacing: "0.02em" }}>
              IPO
            </span>
            <span style={{ fontSize: 15.5, fontWeight: 800, color: "#FFFFFF", letterSpacing: "0.02em" }}>
              Bazaar
            </span>
          </div>
          <span
            style={{
              fontSize: 10.5,
              fontWeight: 800,
              letterSpacing: "0.16em",
              color: t.blue,
              textTransform: "uppercase",
            }}
          >
            Invest Smarter
          </span>
        </div>

        {step === "success" ? (
          <div
            style={{
              flex: 1,
              width: "100%",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 16,
              textAlign: "center",
            }}
          >
            <div
              style={{
                width: 72,
                height: 72,
                borderRadius: "50%",
                background: cardColors.blueSoft,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <CheckCircle2 size={38} color={t.blue} strokeWidth={2} />
            </div>
            <div style={{ fontSize: 19, fontWeight: 800, color: t.textPrimary }}>
              Account Created!
            </div>
            <div
              style={{
                fontSize: 13,
                color: t.textSecondary,
                display: "flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              <SignUpSpinner size={13} color={t.blue} />
              Taking you to IPO Bazaar…
            </div>
          </div>
        ) : (
          <>
            {/* Heading */}
            <div style={{ width: "100%", textAlign: "center", marginBottom: 24 }}>
              <div style={{ fontSize: 23, fontWeight: 800, color: t.textPrimary }}>
                Create Your Account
              </div>
              <div style={{ fontSize: 13, color: t.textSecondary, marginTop: 6, lineHeight: 1.5 }}>
                Join IPO Bazaar and stay updated with the latest IPOs.
              </div>
            </div>

            {/* Form */}
            <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 15 }}>
              {/* Full Name */}
              <div>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                  Full Name
                </span>
                <div style={{ ...fieldWrapStyle("fullName"), marginTop: 6 }}>
                  <input
                    value={form.fullName}
                    onChange={(e) => handleChange("fullName", e.target.value)}
                    onBlur={() => handleBlur("fullName")}
                    placeholder="Enter your full name"
                    style={bareInputStyle}
                  />
                  <div style={{ paddingRight: 12, display: "flex" }}>
                    <SignUpFieldStatus t={t} state={fieldState("fullName")} />
                  </div>
                </div>
                {fieldState("fullName") === "error" && (
                  <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                    {errors.fullName}
                  </span>
                )}
              </div>

              {/* Email */}
              <div>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                  Email Address
                </span>
                <div style={{ ...fieldWrapStyle("email"), marginTop: 6 }}>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => handleChange("email", e.target.value)}
                    onBlur={() => handleBlur("email")}
                    placeholder="you@example.com"
                    autoCapitalize="none"
                    autoCorrect="off"
                    style={bareInputStyle}
                  />
                  <div style={{ paddingRight: 12, display: "flex" }}>
                    <SignUpFieldStatus t={t} state={fieldState("email")} />
                  </div>
                </div>
                {fieldState("email") === "error" && (
                  <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                    {errors.email}
                  </span>
                )}
              </div>

              {/* Mobile */}
              <div>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                  Mobile Number
                </span>
                <div style={{ ...fieldWrapStyle("mobile"), marginTop: 6 }}>
                  <span
                    style={{
                      padding: "13px 10px 13px 14px",
                      fontSize: 14,
                      fontWeight: 700,
                      color: t.textSecondary,
                      borderRight: `1px solid ${t.border}`,
                      flexShrink: 0,
                    }}
                  >
                    +91
                  </span>
                  <input
                    type="tel"
                    inputMode="numeric"
                    value={form.mobile}
                    onChange={(e) => handleChange("mobile", e.target.value.replace(/\D/g, "").slice(0, 10))}
                    onBlur={() => handleBlur("mobile")}
                    placeholder="10-digit mobile number"
                    maxLength={10}
                    style={bareInputStyle}
                  />
                  <div style={{ paddingRight: 12, display: "flex" }}>
                    <SignUpFieldStatus t={t} state={fieldState("mobile")} />
                  </div>
                </div>
                {fieldState("mobile") === "error" && (
                  <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                    {errors.mobile}
                  </span>
                )}

                {/* OTP Verification — inline, directly below Mobile Number */}
                {!otpSent ? (
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    disabled={!mobileValid}
                    className="ipo-card-btn"
                    style={{
                      width: "100%",
                      height: 42,
                      marginTop: 10,
                      border: "none",
                      borderRadius: 12,
                      background: mobileValid ? t.blue : cardColors.blueSoft,
                      color: mobileValid ? "#FFFFFF" : t.blue,
                      fontSize: 13,
                      fontWeight: 800,
                      cursor: mobileValid ? "pointer" : "default",
                      opacity: mobileValid ? 1 : 0.75,
                    }}
                  >
                    Send OTP
                  </button>
                ) : (
                  <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 10 }}>
                    {otpMessage && (
                      <span
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 6,
                          fontSize: 12,
                          fontWeight: 700,
                          color:
                            otpStatus === "error" || otpStatus === "expired"
                              ? cardColors.red
                              : otpStatus === "verified"
                              ? t.blue
                              : t.textSecondary,
                        }}
                      >
                        {otpStatus === "verified" && (
                          <CheckCircle2 size={14} color={t.blue} strokeWidth={2.4} />
                        )}
                        {(otpStatus === "error" || otpStatus === "expired") && (
                          <AlertTriangle size={14} color={cardColors.red} strokeWidth={2.4} />
                        )}
                        {otpMessage}
                      </span>
                    )}

                    <div style={{ display: "flex", gap: 8, justifyContent: "space-between" }}>
                      {otpDigits.map((digit, i) => (
                        <input
                          key={i}
                          ref={(el) => (otpInputRefs.current[i] = el)}
                          value={digit}
                          onChange={(e) => handleOtpDigitChange(i, e.target.value)}
                          onKeyDown={(e) => handleOtpKeyDown(i, e)}
                          onFocus={(e) => e.target.select()}
                          type="tel"
                          inputMode="numeric"
                          maxLength={1}
                          disabled={otpStatus === "verified"}
                          style={{
                            width: "15%",
                            height: 46,
                            textAlign: "center",
                            fontSize: 18,
                            fontWeight: 700,
                            borderRadius: 12,
                            outline: "none",
                            fontFamily: "inherit",
                            boxSizing: "border-box",
                            background: t.surface,
                            color: t.textPrimary,
                            border: `1.5px solid ${
                              otpStatus === "error" || otpStatus === "expired"
                                ? cardColors.red
                                : otpStatus === "verified"
                                ? t.blue
                                : t.border
                            }`,
                          }}
                        />
                      ))}
                    </div>

                    <button
                      type="button"
                      onClick={handleResendOtp}
                      disabled={resendSeconds > 0}
                      className="ipo-card-btn"
                      style={{
                        alignSelf: "flex-start",
                        border: "none",
                        background: "transparent",
                        padding: 0,
                        fontSize: 12,
                        fontWeight: 700,
                        color: resendSeconds > 0 ? t.textSecondary : t.blue,
                        cursor: resendSeconds > 0 ? "default" : "pointer",
                      }}
                    >
                      {resendSeconds > 0 ? `Resend OTP in ${resendSeconds}s` : "Resend OTP"}
                    </button>
                  </div>
                )}
              </div>

              {/* Password */}
              <div>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                  Password
                </span>
                <div style={{ ...fieldWrapStyle("password"), marginTop: 6 }}>
                  <input
                    type={showPassword ? "text" : "password"}
                    value={form.password}
                    onChange={(e) => handleChange("password", e.target.value)}
                    onBlur={() => handleBlur("password")}
                    placeholder="Min. 8 characters"
                    style={bareInputStyle}
                  />
                  <div style={{ display: "flex", alignItems: "center", gap: 6, paddingRight: 10 }}>
                    <SignUpFieldStatus t={t} state={fieldState("password")} />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      aria-label={showPassword ? "Hide password" : "Show password"}
                      className="ipo-card-btn"
                      style={{
                        width: 28,
                        height: 28,
                        border: "none",
                        background: "transparent",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer",
                        padding: 0,
                      }}
                    >
                      {showPassword ? (
                        <EyeOff size={16} color={t.textSecondary} strokeWidth={2} />
                      ) : (
                        <Eye size={16} color={t.textSecondary} strokeWidth={2} />
                      )}
                    </button>
                  </div>
                </div>
                {fieldState("password") === "error" ? (
                  <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                    {errors.password}
                  </span>
                ) : (
                  <span style={{ display: "block", marginTop: 5, fontSize: 11.5, color: t.textSecondary }}>
                    8+ characters, with 1 number and 1 special character.
                  </span>
                )}
              </div>

              {/* Confirm Password */}
              <div>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                  Confirm Password
                </span>
                <div style={{ ...fieldWrapStyle("confirmPassword"), marginTop: 6 }}>
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    value={form.confirmPassword}
                    onChange={(e) => handleChange("confirmPassword", e.target.value)}
                    onBlur={() => handleBlur("confirmPassword")}
                    placeholder="Re-enter your password"
                    style={bareInputStyle}
                  />
                  <div style={{ display: "flex", alignItems: "center", gap: 6, paddingRight: 10 }}>
                    <SignUpFieldStatus t={t} state={fieldState("confirmPassword")} />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword((v) => !v)}
                      aria-label={showConfirmPassword ? "Hide password" : "Show password"}
                      className="ipo-card-btn"
                      style={{
                        width: 28,
                        height: 28,
                        border: "none",
                        background: "transparent",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        cursor: "pointer",
                        padding: 0,
                      }}
                    >
                      {showConfirmPassword ? (
                        <EyeOff size={16} color={t.textSecondary} strokeWidth={2} />
                      ) : (
                        <Eye size={16} color={t.textSecondary} strokeWidth={2} />
                      )}
                    </button>
                  </div>
                </div>
                {fieldState("confirmPassword") === "error" && (
                  <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                    {errors.confirmPassword}
                  </span>
                )}
              </div>

              {/* Terms checkbox */}
              <button
                onClick={() => {
                  setAgreed((v) => !v);
                  if (formError) setFormError("");
                }}
                className="ipo-card-btn"
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "flex-start",
                  gap: 10,
                  background: "none",
                  border: "none",
                  padding: 0,
                  marginTop: 2,
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                <div
                  style={{
                    width: 22,
                    height: 22,
                    borderRadius: 7,
                    background: agreed ? t.blue : "transparent",
                    border: agreed ? "none" : `1.5px solid ${t.border}`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                    marginTop: 1,
                  }}
                >
                  {agreed && <Check size={14} color="#FFFFFF" strokeWidth={3} />}
                </div>
                <span style={{ fontSize: 12.5, color: t.textSecondary, lineHeight: 1.5 }}>
                  I agree to the{" "}
                  <span style={{ color: t.blue, fontWeight: 700 }}>Terms &amp; Conditions</span> and{" "}
                  <span style={{ color: t.blue, fontWeight: 700 }}>Privacy Policy</span>.
                </span>
              </button>

              {formError && (
                <div
                  style={{
                    background: cardColors.redSoft,
                    border: `1px solid ${cardColors.red}`,
                    borderRadius: 12,
                    padding: "10px 12px",
                    fontSize: 12.5,
                    fontWeight: 600,
                    color: cardColors.red,
                    textAlign: "center",
                  }}
                >
                  {formError}
                </div>
              )}

              <button
                onClick={handleSubmit}
                disabled={!canSubmit}
                className="ipo-card-btn"
                style={{
                  width: "100%",
                  height: 50,
                  border: "none",
                  borderRadius: 25,
                  background: canSubmit ? t.blue : cardColors.blueSoft,
                  color: canSubmit ? "#FFFFFF" : t.blue,
                  fontSize: 14.5,
                  fontWeight: 800,
                  cursor: canSubmit ? "pointer" : "default",
                  marginTop: 4,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                }}
              >
                {loading ? (
                  <>
                    <SignUpSpinner size={16} />
                    Creating Account…
                  </>
                ) : (
                  <>
                    Create Account
                    <ArrowRight size={16} strokeWidth={2.6} />
                  </>
                )}
              </button>

              {/* OR divider */}
              <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "6px 0" }}>
                <div style={{ flex: 1, height: 1, background: t.border }} />
                <span style={{ fontSize: 11.5, fontWeight: 700, color: t.textSecondary }}>OR</span>
                <div style={{ flex: 1, height: 1, background: t.border }} />
              </div>

              <button
                onClick={handleGoogle}
                className="ipo-card-btn"
                style={{
                  width: "100%",
                  height: 50,
                  border: `1px solid ${t.border}`,
                  borderRadius: 25,
                  background: t.surface,
                  color: t.textPrimary,
                  fontSize: 14,
                  fontWeight: 700,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 10,
                }}
              >
                <GoogleGIcon size={18} />
                Continue with Google
              </button>
            </div>

            {/* Bottom sign in link */}
            <div
              style={{
                marginTop: "auto",
                paddingTop: 26,
                fontSize: 13,
                color: t.textSecondary,
              }}
            >
              Already have an account?{" "}
              <button
                onClick={onSignIn}
                className="ipo-card-btn"
                style={{
                  border: "none",
                  background: "transparent",
                  padding: 0,
                  fontSize: 13,
                  fontWeight: 800,
                  color: t.blue,
                  cursor: "pointer",
                }}
              >
                Sign In
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   FORGOT PASSWORD FLOW
   Same visual language, theme handling (`t`), and field patterns as
   SignInScreen/SignUpScreen. Four internal steps — no backend exists
   yet, so OTP + reset are mocked; swap the setTimeout blocks for
   real API calls when this ships.
----------------------------------------------------------------*/
function ForgotPasswordScreen({ t, onBack, onDone }) {
  const [step, setStep] = useState("mobile"); // "mobile" | "otp" | "reset" | "success"

  // Step 1 — mobile number
  const [mobile, setMobile] = useState("");
  const [mobileTouched, setMobileTouched] = useState(false);
  const [sending, setSending] = useState(false);
  const mobileValid = MOBILE10_RE.test(mobile.trim());
  const mobileError =
    mobileTouched && !mobileValid
      ? mobile.trim()
        ? "Enter a valid 10-digit mobile number."
        : "Mobile number is required."
      : "";

  // Step 2 — OTP
  const [otpDigits, setOtpDigits] = useState(["", "", "", "", "", ""]);
  const [otpStatus, setOtpStatus] = useState(null); // null | "error" | "expired" | "verified"
  const [otpMessage, setOtpMessage] = useState("");
  const [resendSeconds, setResendSeconds] = useState(30);
  const [otpExpiresAt, setOtpExpiresAt] = useState(null);
  const [verifying, setVerifying] = useState(false);
  const otpInputRefs = useRef([]);

  useEffect(() => {
    if (resendSeconds <= 0) return undefined;
    const timer = window.setTimeout(() => setResendSeconds((s) => s - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [resendSeconds]);

  // Step 3 — new password
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [pwTouched, setPwTouched] = useState({});
  const [resetting, setResetting] = useState(false);
  const [resetError, setResetError] = useState("");

  const validatePassword = (v) => {
    if (!v) return "Password is required.";
    if (v.length < 8) return "Use at least 8 characters.";
    if (!/\d/.test(v)) return "Include at least 1 number.";
    if (!/[^A-Za-z0-9]/.test(v)) return "Include at least 1 special character.";
    return "";
  };
  const validateConfirm = (v, pw) => {
    if (!v) return "Please confirm your new password.";
    if (v !== pw) return "Passwords do not match.";
    return "";
  };
  const newPasswordError = pwTouched.newPassword ? validatePassword(newPassword) : "";
  const confirmPasswordError = pwTouched.confirmPassword
    ? validateConfirm(confirmPassword, newPassword)
    : "";
  const canReset =
    !validatePassword(newPassword) && !validateConfirm(confirmPassword, newPassword) && !resetting;

  const fieldWrapStyle = (hasError, isValid) => ({
    display: "flex",
    alignItems: "center",
    width: "100%",
    background: t.surface,
    border: `1px solid ${hasError ? cardColors.red : isValid ? t.blue : t.border}`,
    borderRadius: 14,
    boxSizing: "border-box",
    overflow: "hidden",
  });

  const bareInputStyle = {
    flex: 1,
    minWidth: 0,
    border: "none",
    outline: "none",
    background: "transparent",
    padding: "13px 12px",
    fontSize: 14,
    color: t.textPrimary,
    fontFamily: "inherit",
  };

  const maskedMobile = `******${mobile.trim().slice(-4)}`;

  const startOtp = () => {
    setOtpDigits(["", "", "", "", "", ""]);
    setOtpStatus(null);
    setOtpMessage("OTP sent successfully");
    setOtpExpiresAt(Date.now() + 2 * 60 * 1000);
    setResendSeconds(30);
    window.setTimeout(() => otpInputRefs.current[0]?.focus(), 50);
  };

  const handleSendOtp = () => {
    setMobileTouched(true);
    if (!mobileValid) return;
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setStep("otp");
      startOtp();
    }, 900);
  };

  const handleResendOtp = () => {
    if (resendSeconds > 0) return;
    startOtp();
  };

  const verifyOtp = (code) => {
    if (otpExpiresAt && Date.now() > otpExpiresAt) {
      setOtpStatus("expired");
      setOtpMessage("This OTP has expired. Tap Resend OTP to get a new one.");
      return;
    }
    setVerifying(true);
    setTimeout(() => {
      setVerifying(false);
      if (code === DEMO_OTP) {
        setOtpStatus("verified");
        setOtpMessage("Mobile number verified");
        window.setTimeout(() => setStep("reset"), 700);
      } else {
        setOtpStatus("error");
        setOtpMessage("Incorrect OTP. Please try again.");
      }
    }, 700);
  };

  const handleOtpDigitChange = (index, rawValue) => {
    const digit = rawValue.replace(/\D/g, "").slice(-1);
    const next = [...otpDigits];
    next[index] = digit;
    setOtpDigits(next);
    if (otpStatus === "error" || otpStatus === "expired") {
      setOtpStatus(null);
      setOtpMessage("");
    }
    if (digit && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
    if (next.every((d) => d !== "")) {
      verifyOtp(next.join(""));
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  const handleReset = () => {
    if (resetting) return;
    setPwTouched({ newPassword: true, confirmPassword: true });
    const pwErr = validatePassword(newPassword);
    const confirmErr = validateConfirm(confirmPassword, newPassword);
    if (pwErr || confirmErr) return;

    setResetError("");
    setResetting(true);
    setTimeout(() => {
      setResetting(false);
      setStep("success");
    }, 1000);
  };

  const stepIcon =
    step === "mobile" ? Lock : step === "otp" ? MessageSquare : step === "reset" ? Shield : null;
  const StepIcon = stepIcon;

  return (
    <div
      style={{
        flex: 1,
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        background: t.bg,
      }}
    >
      <div style={{ padding: "18px 16px 0", flexShrink: 0, height: 54, boxSizing: "border-box" }}>
        {(step === "mobile" || step === "otp") && (
          <button
            onClick={() => (step === "otp" ? setStep("mobile") : onBack())}
            aria-label="Back"
            className="ipo-card-btn"
            style={circleBtnStyle(t)}
          >
            <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
          </button>
        )}
      </div>

      <div
        style={{
          flex: 1,
          minHeight: 0,
          overflowY: "auto",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "8px 24px 28px",
          boxSizing: "border-box",
        }}
      >
        {StepIcon && (
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: "50%",
              background: cardColors.blueSoft,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              marginTop: 12,
              marginBottom: 18,
            }}
          >
            <StepIcon size={28} color={t.blue} strokeWidth={2} />
          </div>
        )}

        {step === "mobile" && (
          <>
            <div style={{ width: "100%", textAlign: "center", marginBottom: 26 }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: t.textPrimary }}>
                Forgot Password?
              </div>
              <div style={{ fontSize: 13, color: t.textSecondary, marginTop: 8, lineHeight: 1.5 }}>
                Enter your registered mobile number to reset your password.
              </div>
            </div>

            <div style={{ width: "100%" }}>
              <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                Mobile Number
              </span>
              <div style={{ ...fieldWrapStyle(!!mobileError, mobileTouched && mobileValid), marginTop: 6 }}>
                <span
                  style={{
                    padding: "13px 10px 13px 14px",
                    fontSize: 14,
                    fontWeight: 700,
                    color: t.textSecondary,
                    borderRight: `1px solid ${t.border}`,
                    flexShrink: 0,
                  }}
                >
                  +91
                </span>
                <input
                  type="tel"
                  inputMode="numeric"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
                  onBlur={() => setMobileTouched(true)}
                  placeholder="10-digit mobile number"
                  maxLength={10}
                  style={bareInputStyle}
                />
                <div style={{ paddingRight: 12, display: "flex" }}>
                  <SignUpFieldStatus
                    t={t}
                    state={mobileError ? "error" : mobileTouched && mobileValid ? "valid" : null}
                  />
                </div>
              </div>
              {mobileError && (
                <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                  {mobileError}
                </span>
              )}
            </div>

            <button
              onClick={handleSendOtp}
              disabled={sending}
              className="ipo-card-btn"
              style={{
                width: "100%",
                height: 50,
                border: "none",
                borderRadius: 25,
                background: t.blue,
                color: "#FFFFFF",
                fontSize: 14.5,
                fontWeight: 800,
                cursor: sending ? "default" : "pointer",
                opacity: sending ? 0.75 : 1,
                marginTop: 22,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 10,
              }}
            >
              {sending && <SignUpSpinner size={16} />}
              {sending ? "Sending OTP…" : "Send OTP"}
            </button>
          </>
        )}

        {step === "otp" && (
          <>
            <div style={{ width: "100%", textAlign: "center", marginBottom: 26 }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: t.textPrimary }}>Verify OTP</div>
              <div style={{ fontSize: 13, color: t.textSecondary, marginTop: 8, lineHeight: 1.5 }}>
                Enter the 6-digit code sent to{" "}
                <span style={{ color: t.textPrimary, fontWeight: 700 }}>{maskedMobile}</span>
              </div>
            </div>

            <div style={{ width: "100%" }}>
              {otpMessage && (
                <span
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 6,
                    fontSize: 12,
                    fontWeight: 700,
                    marginBottom: 12,
                    color:
                      otpStatus === "error" || otpStatus === "expired"
                        ? cardColors.red
                        : otpStatus === "verified"
                        ? t.blue
                        : t.textSecondary,
                  }}
                >
                  {otpStatus === "verified" && <CheckCircle2 size={14} color={t.blue} strokeWidth={2.4} />}
                  {(otpStatus === "error" || otpStatus === "expired") && (
                    <AlertTriangle size={14} color={cardColors.red} strokeWidth={2.4} />
                  )}
                  {otpMessage}
                </span>
              )}

              <div style={{ display: "flex", gap: 8, justifyContent: "space-between" }}>
                {otpDigits.map((digit, i) => (
                  <input
                    key={i}
                    ref={(el) => (otpInputRefs.current[i] = el)}
                    value={digit}
                    onChange={(e) => handleOtpDigitChange(i, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(i, e)}
                    onFocus={(e) => e.target.select()}
                    type="tel"
                    inputMode="numeric"
                    maxLength={1}
                    disabled={otpStatus === "verified" || verifying}
                    style={{
                      width: "15%",
                      height: 48,
                      textAlign: "center",
                      fontSize: 19,
                      fontWeight: 700,
                      borderRadius: 12,
                      outline: "none",
                      fontFamily: "inherit",
                      boxSizing: "border-box",
                      background: t.surface,
                      color: t.textPrimary,
                      border: `1.5px solid ${
                        otpStatus === "error" || otpStatus === "expired"
                          ? cardColors.red
                          : otpStatus === "verified"
                          ? t.blue
                          : t.border
                      }`,
                    }}
                  />
                ))}
              </div>
            </div>

            <button
              onClick={() => {
                if (otpDigits.every((d) => d !== "")) verifyOtp(otpDigits.join(""));
              }}
              disabled={verifying || otpStatus === "verified" || otpDigits.some((d) => !d)}
              className="ipo-card-btn"
              style={{
                width: "100%",
                height: 50,
                border: "none",
                borderRadius: 25,
                background: t.blue,
                color: "#FFFFFF",
                fontSize: 14.5,
                fontWeight: 800,
                cursor: verifying ? "default" : "pointer",
                opacity: verifying || otpDigits.some((d) => !d) ? 0.6 : 1,
                marginTop: 22,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 10,
              }}
            >
              {verifying && <SignUpSpinner size={16} />}
              {verifying ? "Verifying…" : "Verify OTP"}
            </button>

            <div
              style={{
                marginTop: 18,
                fontSize: 12.5,
                color: t.textSecondary,
                display: "flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              Didn&apos;t receive OTP?
              <button
                onClick={handleResendOtp}
                disabled={resendSeconds > 0}
                className="ipo-card-btn"
                style={{
                  border: "none",
                  background: "transparent",
                  padding: 0,
                  fontSize: 12.5,
                  fontWeight: 800,
                  color: resendSeconds > 0 ? t.textSecondary : t.blue,
                  cursor: resendSeconds > 0 ? "default" : "pointer",
                }}
              >
                {resendSeconds > 0 ? `Resend in ${resendSeconds}s` : "Resend OTP"}
              </button>
            </div>
          </>
        )}

        {step === "reset" && (
          <>
            <div style={{ width: "100%", textAlign: "center", marginBottom: 26 }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: t.textPrimary }}>
                Create New Password
              </div>
              <div style={{ fontSize: 13, color: t.textSecondary, marginTop: 8, lineHeight: 1.5 }}>
                Your new password must be different from previously used passwords.
              </div>
            </div>

            <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 15 }}>
              <div>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                  New Password
                </span>
                <div
                  style={{
                    ...fieldWrapStyle(!!newPasswordError, pwTouched.newPassword && !newPasswordError && !!newPassword),
                    marginTop: 6,
                  }}
                >
                  <input
                    type={showNewPassword ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      if (resetError) setResetError("");
                    }}
                    onBlur={() => setPwTouched((prev) => ({ ...prev, newPassword: true }))}
                    placeholder="Min. 8 characters"
                    style={bareInputStyle}
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword((v) => !v)}
                    aria-label={showNewPassword ? "Hide password" : "Show password"}
                    className="ipo-card-btn"
                    style={{
                      width: 32,
                      height: 32,
                      marginRight: 8,
                      border: "none",
                      background: "transparent",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                      padding: 0,
                    }}
                  >
                    {showNewPassword ? (
                      <EyeOff size={16} color={t.textSecondary} strokeWidth={2} />
                    ) : (
                      <Eye size={16} color={t.textSecondary} strokeWidth={2} />
                    )}
                  </button>
                </div>
                {newPasswordError ? (
                  <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                    {newPasswordError}
                  </span>
                ) : (
                  <span style={{ display: "block", marginTop: 5, fontSize: 11.5, color: t.textSecondary }}>
                    8+ characters, with 1 number and 1 special character.
                  </span>
                )}
              </div>

              <div>
                <span style={{ fontSize: 12.5, fontWeight: 700, color: t.textPrimary }}>
                  Confirm Password
                </span>
                <div
                  style={{
                    ...fieldWrapStyle(
                      !!confirmPasswordError,
                      pwTouched.confirmPassword && !confirmPasswordError && !!confirmPassword
                    ),
                    marginTop: 6,
                  }}
                >
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      if (resetError) setResetError("");
                    }}
                    onBlur={() => setPwTouched((prev) => ({ ...prev, confirmPassword: true }))}
                    placeholder="Re-enter your new password"
                    style={bareInputStyle}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword((v) => !v)}
                    aria-label={showConfirmPassword ? "Hide password" : "Show password"}
                    className="ipo-card-btn"
                    style={{
                      width: 32,
                      height: 32,
                      marginRight: 8,
                      border: "none",
                      background: "transparent",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      cursor: "pointer",
                      padding: 0,
                    }}
                  >
                    {showConfirmPassword ? (
                      <EyeOff size={16} color={t.textSecondary} strokeWidth={2} />
                    ) : (
                      <Eye size={16} color={t.textSecondary} strokeWidth={2} />
                    )}
                  </button>
                </div>
                {confirmPasswordError && (
                  <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                    {confirmPasswordError}
                  </span>
                )}
              </div>

              {resetError && (
                <div
                  style={{
                    background: cardColors.redSoft,
                    border: `1px solid ${cardColors.red}`,
                    borderRadius: 12,
                    padding: "10px 12px",
                    fontSize: 12.5,
                    fontWeight: 600,
                    color: cardColors.red,
                    textAlign: "center",
                  }}
                >
                  {resetError}
                </div>
              )}

              <button
                onClick={handleReset}
                disabled={!canReset}
                className="ipo-card-btn"
                style={{
                  width: "100%",
                  height: 50,
                  border: "none",
                  borderRadius: 25,
                  background: canReset ? t.blue : cardColors.blueSoft,
                  color: canReset ? "#FFFFFF" : t.blue,
                  fontSize: 14.5,
                  fontWeight: 800,
                  cursor: canReset ? "pointer" : "default",
                  marginTop: 4,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 10,
                }}
              >
                {resetting && <SignUpSpinner size={16} />}
                {resetting ? "Resetting…" : "Reset Password"}
              </button>
            </div>
          </>
        )}

        {step === "success" && (
          <div
            style={{
              flex: 1,
              width: "100%",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 16,
              textAlign: "center",
            }}
          >
            <div
              style={{
                width: 72,
                height: 72,
                borderRadius: "50%",
                background: cardColors.blueSoft,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <CheckCircle2 size={38} color={t.blue} strokeWidth={2} />
            </div>
            <div style={{ fontSize: 19, fontWeight: 800, color: t.textPrimary }}>
              Password Reset Successfully
            </div>
            <div style={{ fontSize: 13, color: t.textSecondary, lineHeight: 1.5 }}>
              Your password has been updated successfully.
            </div>

            <button
              onClick={onDone}
              className="ipo-card-btn"
              style={{
                width: "100%",
                height: 50,
                border: "none",
                borderRadius: 25,
                background: t.blue,
                color: "#FFFFFF",
                fontSize: 14.5,
                fontWeight: 800,
                cursor: "pointer",
                marginTop: 8,
              }}
            >
              Continue to Sign In
            </button>
          </div>
        )}
      </div>
    </div>
  );
}


/* ---------------------------------------------------------------
   REUSABLE: Profile photo editor — large circular avatar with an
   overlapping camera badge that opens a Gallery / Camera / Remove
   action sheet. Shared by the Settings profile card and the Edit
   Profile screen so both stay in sync and behave identically.
----------------------------------------------------------------*/
function ProfileAvatarEditor({
  t,
  avatarUrl,
  avatarLoading,
  onFileSelected,
  onRemove,
  size = 88,
  iconSize = 44,
  editable = true,
}) {
  const [showOptions, setShowOptions] = useState(false);
  const galleryInputRef = useRef(null);
  const cameraInputRef = useRef(null);

  const pickFrom = (ref) => {
    setShowOptions(false);
    if (ref.current) ref.current.click();
  };

  return (
    <>
      <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
        <button
          onClick={() => editable && setShowOptions(true)}
          disabled={!editable}
          aria-label="Change profile photo"
          className="ipo-card-btn"
          style={{
            width: size,
            height: size,
            borderRadius: "50%",
            background: cardColors.blueSoft,
            border: "none",
            padding: 0,
            overflow: "hidden",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: editable ? "pointer" : "default",
            position: "relative",
          }}
        >
          {avatarUrl ? (
            <img
              src={avatarUrl}
              alt="Profile"
              style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: "50%" }}
            />
          ) : (
            <User size={iconSize} color={t.blue} strokeWidth={1.8} />
          )}
          {avatarLoading && (
            <div
              style={{
                position: "absolute",
                inset: 0,
                borderRadius: "50%",
                background: "rgba(15, 23, 42, 0.4)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <div
                style={{
                  width: Math.round(size * 0.25),
                  height: Math.round(size * 0.25),
                  borderRadius: "50%",
                  border: "2.5px solid rgba(255, 255, 255, 0.35)",
                  borderTopColor: "#FFFFFF",
                  animation: "ipoSpin 0.7s linear infinite",
                }}
              />
            </div>
          )}
        </button>

        {editable && (
          <button
            onClick={() => setShowOptions(true)}
            aria-label="Edit profile photo"
            className="ipo-card-btn"
            style={{
              position: "absolute",
              right: -2,
              bottom: -2,
              width: 32,
              height: 32,
              borderRadius: "50%",
              background: t.blue,
              border: `2px solid ${t.bg}`,
              padding: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}
          >
            <Camera size={15} color="#FFFFFF" strokeWidth={2.2} />
          </button>
        )}

        {editable && (
          <>
            <input
              ref={galleryInputRef}
              type="file"
              accept="image/*"
              style={{ display: "none" }}
              onChange={(e) => {
                onFileSelected(e.target.files && e.target.files[0]);
                e.target.value = "";
              }}
            />
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="user"
              style={{ display: "none" }}
              onChange={(e) => {
                onFileSelected(e.target.files && e.target.files[0]);
                e.target.value = "";
              }}
            />
          </>
        )}
      </div>

      {showOptions && (
        <div
          onClick={() => setShowOptions(false)}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 50,
            background: "rgba(15, 23, 42, 0.5)",
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "center",
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "100%",
              maxWidth: 480,
              background: t.surface,
              borderRadius: "22px 22px 0 0",
              padding: "10px 16px calc(18px + env(safe-area-inset-bottom, 0px))",
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <div
              style={{
                width: 36,
                height: 4,
                borderRadius: 2,
                background: t.border,
                alignSelf: "center",
                marginBottom: 10,
              }}
            />
            <span style={{ fontSize: 13, fontWeight: 700, color: t.textSecondary, padding: "0 6px 8px" }}>
              Edit Profile Photo
            </span>

            <button onClick={() => pickFrom(galleryInputRef)} className="ipo-card-btn" style={sheetRowStyle}>
              <span style={sheetIconWrapStyle(cardColors.blueSoft)}>
                <ImageIcon size={17} color={t.blue} strokeWidth={2} />
              </span>
              <span style={{ fontSize: 14, fontWeight: 700, color: t.textPrimary }}>Choose from Gallery</span>
            </button>

            <button onClick={() => pickFrom(cameraInputRef)} className="ipo-card-btn" style={sheetRowStyle}>
              <span style={sheetIconWrapStyle(cardColors.blueSoft)}>
                <Camera size={17} color={t.blue} strokeWidth={2} />
              </span>
              <span style={{ fontSize: 14, fontWeight: 700, color: t.textPrimary }}>Take a Photo</span>
            </button>

            {avatarUrl && (
              <button
                onClick={() => {
                  setShowOptions(false);
                  onRemove();
                }}
                className="ipo-card-btn"
                style={sheetRowStyle}
              >
                <span style={sheetIconWrapStyle(cardColors.redSoft)}>
                  <Trash2 size={17} color={cardColors.red} strokeWidth={2} />
                </span>
                <span style={{ fontSize: 14, fontWeight: 700, color: cardColors.red }}>Remove Photo</span>
              </button>
            )}

            <button
              onClick={() => setShowOptions(false)}
              className="ipo-card-btn"
              style={{
                width: "100%",
                height: 44,
                marginTop: 8,
                border: `1px solid ${t.border}`,
                borderRadius: 22,
                background: "transparent",
                color: t.textPrimary,
                fontSize: 13.5,
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------------------------------------------------------------
   EDIT PROFILE SCREEN
   Lets the signed-in user update their name, email, and photo.
   Mobile number is shown read-only (already verified at sign-up).
   No backend exists yet — onSave just writes the new values back
   into SettingsScreen's profile state.
----------------------------------------------------------------*/
function EditProfileScreen({
  t,
  profile,
  avatarUrl,
  avatarLoading,
  onAvatarFile,
  onAvatarRemove,
  onBack,
  onSave,
}) {
  const initial = {
    name: (profile && profile.name) || "",
    email: (profile && profile.email) || "",
    mobile: (profile && profile.mobile) || "",
  };
  const [form, setForm] = useState(initial);
  const [touched, setTouched] = useState({});
  const [saved, setSaved] = useState(false);

  const validateField = (key, values) => {
    if (key === "name") {
      const v = values.name.trim();
      if (!v) return "Full name is required.";
      if (v.length < 2) return "Enter at least 2 characters.";
      if (/^\d+$/.test(v)) return "Name can't be numbers only.";
      return "";
    }
    if (key === "email") {
      const v = values.email.trim();
      if (!v) return "Email is required.";
      if (!EMAIL_RE.test(v)) return "Enter a valid email address.";
      return "";
    }
    return "";
  };

  const errors = {
    name: validateField("name", form),
    email: validateField("email", form),
  };

  const isDirty = form.name.trim() !== initial.name.trim() || form.email.trim() !== initial.email.trim();
  const canSave = isDirty && !errors.name && !errors.email;

  const handleChange = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (saved) setSaved(false);
  };

  const handleBlur = (key) => setTouched((prev) => ({ ...prev, [key]: true }));

  const fieldState = (key) => {
    if (!touched[key]) return null;
    return errors[key] ? "error" : "valid";
  };

  const fieldWrapStyle = (key, readOnly) => {
    const state = fieldState(key);
    return {
      display: "flex",
      alignItems: "center",
      width: "100%",
      background: readOnly ? t.bg : t.surface,
      border: `1px solid ${
        state === "error" ? cardColors.red : state === "valid" ? t.blue : t.border
      }`,
      borderRadius: 14,
      boxSizing: "border-box",
      overflow: "hidden",
    };
  };

  const bareInputStyle = {
    flex: 1,
    minWidth: 0,
    border: "none",
    outline: "none",
    background: "transparent",
    padding: "13px 14px",
    fontSize: 14,
    color: t.textPrimary,
    fontFamily: "inherit",
  };

  const handleSave = () => {
    if (!canSave) return;
    onSave({ name: form.name.trim(), email: form.email.trim(), mobile: form.mobile });
    setSaved(true);
  };

  return (
    <div style={{ flex: 1, overflowY: "auto", background: t.bg, display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "18px 16px 4px", display: "flex", alignItems: "center", gap: 12 }}>
        <button onClick={onBack} aria-label="Back" className="ipo-card-btn" style={circleBtnStyle(t)}>
          <ArrowLeft size={18} color={t.blue} strokeWidth={2.4} />
        </button>
        <span style={{ fontSize: 20, fontWeight: 800, color: t.textPrimary }}>Edit Profile</span>
      </div>

      <div style={{ padding: "20px 16px 28px", display: "flex", flexDirection: "column", gap: 22 }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <ProfileAvatarEditor
            t={t}
            avatarUrl={avatarUrl}
            avatarLoading={avatarLoading}
            onFileSelected={onAvatarFile}
            onRemove={onAvatarRemove}
            size={100}
            iconSize={50}
          />
          <span style={{ fontSize: 12, color: t.textSecondary }}>Tap the camera icon to change your photo</span>
        </div>

        <SectionCard t={t} title="Profile Information">
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <FormField t={t} label="Full Name" required>
                <div style={fieldWrapStyle("name")}>
                  <input
                    style={bareInputStyle}
                    value={form.name}
                    onChange={(e) => handleChange("name", e.target.value)}
                    onBlur={() => handleBlur("name")}
                    placeholder="Enter your full name"
                  />
                </div>
              </FormField>
              {fieldState("name") === "error" && (
                <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                  {errors.name}
                </span>
              )}
            </div>

            <div>
              <FormField t={t} label="Email Address" required>
                <div style={fieldWrapStyle("email")}>
                  <input
                    style={bareInputStyle}
                    value={form.email}
                    onChange={(e) => handleChange("email", e.target.value)}
                    onBlur={() => handleBlur("email")}
                    placeholder="you@example.com"
                    inputMode="email"
                  />
                </div>
              </FormField>
              {fieldState("email") === "error" && (
                <span style={{ display: "block", marginTop: 5, fontSize: 12, fontWeight: 600, color: cardColors.red }}>
                  {errors.email}
                </span>
              )}
            </div>

            <FormField t={t} label="Mobile Number">
              <div style={fieldWrapStyle("mobile", true)}>
                <span style={{ ...bareInputStyle, color: t.textPrimary }}>
                  {form.mobile || "Not linked"}
                </span>
                <div style={{ display: "flex", alignItems: "center", gap: 4, paddingRight: 12, color: t.textSecondary, flexShrink: 0 }}>
                  <Lock size={13} strokeWidth={2.2} />
                  <span style={{ fontSize: 11, fontWeight: 700 }}>Verified</span>
                </div>
              </div>
            </FormField>
          </div>
        </SectionCard>

        {saved && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              background: cardColors.blueSoft,
              border: `1px solid ${t.blue}`,
              borderRadius: 14,
              padding: "12px 14px",
            }}
          >
            <CheckCircle2 size={16} color={t.blue} strokeWidth={2.2} />
            <span style={{ fontSize: 13, fontWeight: 700, color: t.blue }}>
              Profile updated successfully.
            </span>
          </div>
        )}

        <button
          onClick={handleSave}
          disabled={!canSave}
          className="ipo-card-btn"
          style={{
            width: "100%",
            height: 50,
            border: "none",
            borderRadius: 25,
            background: canSave ? t.blue : t.border,
            color: canSave ? "#FFFFFF" : t.textSecondary,
            fontSize: 14.5,
            fontWeight: 800,
            cursor: canSave ? "pointer" : "not-allowed",
          }}
        >
          Save Changes
        </button>
      </div>
    </div>
  );
}


function SettingsScreen({ t, theme, onToggleTheme, watchlist, onToggleWatchlist }) {
  const [notificationsOn, setNotificationsOn] = useState(true);
  const [showHelp, setShowHelp] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [showDisclaimer, setShowDisclaimer] = useState(false);
  const [showWishlist, setShowWishlist] = useState(false);
  const [showAboutApp, setShowAboutApp] = useState(false);
  const [showSignIn, setShowSignIn] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false);
  // Submitted feedback is kept here for now — this is where it'd be
  // sent to a backend for the Admin Panel to review later.
  const [submittedFeedback, setSubmittedFeedback] = useState([]);
  // Submitted problem reports, same idea — ready for a backend to
  // pick up and surface in the (separate) Admin Panel.
  const [submittedReports, setSubmittedReports] = useState([]);
  // No real backend exists yet — Sign In stores the email/mobile the
  // person entered, and Sign Up stores their name instead, right here.
  const [currentUserId, setCurrentUserId] = useState(null);
  // Full editable profile (name/email/mobile) shown on the Edit
  // Profile screen. Populated on sign-in/sign-up below.
  const [profile, setProfile] = useState({ name: "", email: "", mobile: "" });

  // Profile photo: stored as a data URL in localStorage so it survives
  // reopening the app. No backend yet — swap this for a real upload +
  // persisted profile field whenever one exists.
  const AVATAR_STORAGE_KEY = "ipoBazaarProfileAvatar";
  const [avatarUrl, setAvatarUrl] = useState(null);
  const [avatarLoading, setAvatarLoading] = useState(false);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(AVATAR_STORAGE_KEY);
      if (saved) setAvatarUrl(saved);
    } catch (e) {
      /* localStorage unavailable — fall back to the default icon */
    }
  }, []);

  const handleAvatarFile = (file) => {
    if (!file || !file.type || !file.type.startsWith("image/")) return;
    setAvatarLoading(true);
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      // Brief delay so the loading state is visible even on fast
      // local reads — mirrors what a real upload round-trip would feel like.
      window.setTimeout(() => {
        setAvatarUrl(dataUrl);
        try {
          window.localStorage.setItem(AVATAR_STORAGE_KEY, dataUrl);
        } catch (e) {
          /* storage full or unavailable — photo still shows for this session */
        }
        setAvatarLoading(false);
      }, 500);
    };
    reader.onerror = () => setAvatarLoading(false);
    reader.readAsDataURL(file);
  };

  const handleRemovePhoto = () => {
    setAvatarLoading(true);
    window.setTimeout(() => {
      setAvatarUrl(null);
      try {
        window.localStorage.removeItem(AVATAR_STORAGE_KEY);
      } catch (e) {
        /* ignore */
      }
      setAvatarLoading(false);
    }, 300);
  };

  if (showSignUp) {
    return (
      <SignUpScreen
        t={t}
        onBack={() => setShowSignUp(false)}
        onSignIn={() => {
          setShowSignUp(false);
          setShowSignIn(true);
        }}
        onSignUpComplete={(data) => {
          setCurrentUserId(data.name);
          setProfile({ name: data.name, email: data.email, mobile: data.mobile });
          setShowSignUp(false);
        }}
      />
    );
  }

  if (showForgotPassword) {
    return (
      <ForgotPasswordScreen
        t={t}
        onBack={() => {
          setShowForgotPassword(false);
          setShowSignIn(true);
        }}
        onDone={() => {
          setShowForgotPassword(false);
          setShowSignIn(true);
        }}
      />
    );
  }

  if (showSignIn) {
    return (
      <SignInScreen
        t={t}
        onBack={() => setShowSignIn(false)}
        onSignIn={(identifier) => {
          setCurrentUserId(identifier);
          // No name is captured at sign-in for the demo account — fill
          // in whichever of email/mobile wasn't used to sign in from
          // the same demo record, and leave the name for the user to set.
          const isEmail = identifier.includes("@");
          setProfile({
            name: "",
            email: isEmail ? identifier : DEMO_ACCOUNT.identifiers.find((id) => id.includes("@")) || "",
            mobile: !isEmail ? identifier : DEMO_ACCOUNT.identifiers.find((id) => !id.includes("@")) || "",
          });
          setShowSignIn(false);
        }}
        onSignUp={() => {
          setShowSignIn(false);
          setShowSignUp(true);
        }}
        onForgotPassword={() => {
          setShowSignIn(false);
          setShowForgotPassword(true);
        }}
      />
    );
  }

  if (showEditProfile) {
    return (
      <EditProfileScreen
        t={t}
        profile={profile}
        avatarUrl={avatarUrl}
        avatarLoading={avatarLoading}
        onAvatarFile={handleAvatarFile}
        onAvatarRemove={handleRemovePhoto}
        onBack={() => setShowEditProfile(false)}
        onSave={(updated) => {
          setProfile(updated);
          setCurrentUserId(updated.name);
          setShowEditProfile(false);
        }}
      />
    );
  }

  if (showHelp) {
    return <HelpFAQScreen t={t} onBack={() => setShowHelp(false)} />;
  }
  if (showFeedback) {
    return (
      <FeedbackScreen
        t={t}
        onBack={() => setShowFeedback(false)}
        onSubmit={(text) => setSubmittedFeedback((prev) => [...prev, text])}
      />
    );
  }
  if (showReport) {
    return (
      <ReportProblemScreen
        t={t}
        currentUserId={currentUserId}
        onBack={() => setShowReport(false)}
        onSubmit={(report) => setSubmittedReports((prev) => [...prev, report])}
      />
    );
  }
  if (showDisclaimer) {
    return <DisclaimerScreen t={t} onBack={() => setShowDisclaimer(false)} />;
  }
  if (showAboutApp) {
    return <AboutIPOBazaarScreen t={t} onBack={() => setShowAboutApp(false)} />;
  }
  if (showWishlist) {
    return (
      <WishlistScreen
        t={t}
        watchlist={watchlist}
        onToggleWatchlist={onToggleWatchlist}
        onBack={() => setShowWishlist(false)}
      />
    );
  }

  return (
    <div style={{ flex: 1, overflowY: "auto", padding: "20px 16px 24px" }}>
      <div
        style={{
          width: "100%",
          background: t.surface,
          border: `1px solid ${t.border}`,
          borderRadius: 20,
          padding: "32px 20px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 12,
        }}
      >
        <ProfileAvatarEditor
          t={t}
          avatarUrl={avatarUrl}
          avatarLoading={avatarLoading}
          onFileSelected={handleAvatarFile}
          onRemove={handleRemovePhoto}
          size={currentUserId ? 88 : 72}
          iconSize={currentUserId ? 44 : 36}
          editable={!!currentUserId}
        />
        {currentUserId ? (
          <>
            <span style={{ fontSize: 19, fontWeight: 800, color: t.textPrimary }}>
              {profile.name || currentUserId}
            </span>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 6 }}>
              <button
                onClick={() => setShowEditProfile(true)}
                className="ipo-card-btn"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 7,
                  border: `1px solid ${t.blue}`,
                  fontSize: 13,
                  fontWeight: 700,
                  color: t.blue,
                  background: "transparent",
                  borderRadius: 999,
                  padding: "10px 18px",
                  cursor: "pointer",
                }}
              >
                <Pencil size={14} color={t.blue} strokeWidth={2.2} />
                Edit Profile
              </button>
              <button
                onClick={() => setShowSignOutConfirm(true)}
                className="ipo-card-btn"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 7,
                  border: "none",
                  fontSize: 13,
                  fontWeight: 700,
                  color: "#FFFFFF",
                  background: cardColors.red,
                  borderRadius: 999,
                  padding: "10px 18px",
                  cursor: "pointer",
                }}
              >
                <LogOut size={14} color="#FFFFFF" strokeWidth={2.2} />
                Sign out
              </button>
            </div>
          </>
        ) : (
          <>
            <button
              onClick={() => setShowSignIn(true)}
              className="ipo-card-btn"
              style={{
                border: "none",
                fontSize: 13.5,
                fontWeight: 800,
                color: "#FFFFFF",
                background: t.blue,
                borderRadius: 999,
                padding: "8px 22px",
                cursor: "pointer",
              }}
            >
              Sign in
            </button>
            <button
              onClick={() => setShowSignUp(true)}
              className="ipo-card-btn"
              style={{
                border: "none",
                background: "transparent",
                padding: 0,
                fontSize: 12.5,
                fontWeight: 700,
                color: t.blue,
                cursor: "pointer",
              }}
            >
              Create an account
            </button>
          </>
        )}
      </div>

      <div
        style={{
          fontSize: 15,
          fontWeight: 800,
          letterSpacing: "0.04em",
          textTransform: "uppercase",
          color: t.textPrimary,
          marginTop: 20,
          marginBottom: 8,
          paddingLeft: 2,
        }}
      >
        App Preferences
      </div>
      <div
        style={{
          background: t.surface,
          border: `1px solid ${t.border}`,
          borderRadius: 20,
          padding: "6px 16px",
        }}
      >

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            padding: "14px 0",
            borderBottom: `1px solid ${t.border}`,
          }}
        >
          <div
            style={{
              width: 30,
              height: 30,
              borderRadius: 10,
              background: cardColors.blueSoft,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <Moon size={15} color={t.blue} strokeWidth={2} />
          </div>
          <span style={{ fontSize: 13.5, fontWeight: 700, color: t.textPrimary, flex: 1 }}>
            Dark Mode
          </span>
          <ToggleSwitch t={t} checked={theme === "dark"} onChange={onToggleTheme} />
        </div>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            padding: "14px 0",
            borderBottom: `1px solid ${t.border}`,
          }}
        >
          <div
            style={{
              width: 30,
              height: 30,
              borderRadius: 10,
              background: cardColors.blueSoft,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <Bell size={15} color={t.blue} strokeWidth={2} />
          </div>
          <span style={{ fontSize: 13.5, fontWeight: 700, color: t.textPrimary, flex: 1 }}>
            Notifications
          </span>
          <ToggleSwitch t={t} checked={notificationsOn} onChange={() => setNotificationsOn((v) => !v)} />
        </div>

        <button
          onClick={() => setShowWishlist(true)}
          className="ipo-card-btn"
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center",
            gap: 12,
            padding: "14px 0",
            border: "none",
            background: "none",
            cursor: "pointer",
            textAlign: "left",
          }}
        >
          <div
            style={{
              width: 30,
              height: 30,
              borderRadius: 10,
              background: cardColors.blueSoft,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <Heart size={15} color={t.blue} strokeWidth={2} />
          </div>
          <span style={{ fontSize: 13.5, fontWeight: 700, color: t.textPrimary, flex: 1 }}>
            Wishlist
          </span>
          <ChevronDown
            size={16}
            color={t.textSecondary}
            strokeWidth={2.2}
            style={{ transform: "rotate(-90deg)" }}
          />
        </button>
      </div>

      <SettingsSectionCard t={t} title="Others" items={OTHERS_ITEMS} />

      <SettingsSectionCard
        t={t}
        title="Support"
        items={SUPPORT_ITEMS}
        onItemClick={(title) => {
          if (title === "Help & FAQ") setShowHelp(true);
          if (title === "Feedback") setShowFeedback(true);
          if (title === "Report a Problem") setShowReport(true);
        }}
      />
      <SettingsSectionCard
        t={t}
        title="Legal"
        items={LEGAL_ITEMS}
        onItemClick={(title) => {
          if (title === "Disclaimer") setShowDisclaimer(true);
        }}
      />
      <SettingsSectionCard
        t={t}
        title="About"
        items={ABOUT_ITEMS}
        onItemClick={(title) => {
          if (title === "About IPO Bazaar") setShowAboutApp(true);
        }}
      />

      {showSignOutConfirm && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 50,
            background: "rgba(15, 23, 42, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 24,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "100%",
              maxWidth: 320,
              background: t.surface,
              borderRadius: 20,
              padding: "24px 20px 18px",
              boxShadow: "0 24px 48px rgba(15, 23, 42, 0.28)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              textAlign: "center",
              gap: 6,
            }}
          >
            <div
              style={{
                width: 52,
                height: 52,
                borderRadius: "50%",
                background: cardColors.redSoft,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 6,
              }}
            >
              <LogOut size={24} color={cardColors.red} strokeWidth={2.2} />
            </div>
            <span style={{ fontSize: 16, fontWeight: 800, color: t.textPrimary }}>
              Sign out?
            </span>
            <span style={{ fontSize: 13, color: t.textSecondary, lineHeight: 1.5, marginBottom: 14 }}>
              You'll need to sign in again to view your subscriptions and allotment status.
            </span>
            <div style={{ display: "flex", gap: 10, width: "100%" }}>
              <button
                onClick={() => setShowSignOutConfirm(false)}
                className="ipo-card-btn"
                style={{
                  flex: 1,
                  height: 44,
                  border: `1px solid ${t.border}`,
                  borderRadius: 22,
                  background: "transparent",
                  color: t.textPrimary,
                  fontSize: 13.5,
                  fontWeight: 700,
                  cursor: "pointer",
                }}
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowSignOutConfirm(false);
                  setCurrentUserId(null);
                }}
                className="ipo-card-btn"
                style={{
                  flex: 1,
                  height: 44,
                  border: "none",
                  borderRadius: 22,
                  background: cardColors.red,
                  color: "#FFFFFF",
                  fontSize: 13.5,
                  fontWeight: 700,
                  cursor: "pointer",
                }}
              >
                Sign out
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: Empty state placeholder (other screens)
----------------------------------------------------------------*/
function EmptyState({ t, icon: Icon }) {
  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 14,
        padding: "0 40px",
      }}
    >
      <div
        style={{
          width: 64,
          height: 64,
          borderRadius: 18,
          background: t.surface,
          border: `1px solid ${t.border}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon size={26} color={t.iconMuted} strokeWidth={1.6} />
      </div>
      <span
        style={{
          fontSize: 14.5,
          fontWeight: 500,
          color: t.textSecondary,
          textAlign: "center",
        }}
      >
        Nothing here yet
      </span>
    </div>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: Screen wrapper (handles the fade-in transition)
----------------------------------------------------------------*/
function Screen({ children, activeKey }) {
  return (
    <div
      key={activeKey}
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        minHeight: 0,
        animation: "screenFadeIn 220ms ease",
      }}
    >
      {children}
    </div>
  );
}

/* ---------------------------------------------------------------
   REUSABLE: Bottom navigation
----------------------------------------------------------------*/
function BottomNav({ t, active, onChange }) {
  return (
    <div
      style={{
        flexShrink: 0,
        background: t.nav,
        borderTop: `1px solid ${t.navBorder}`,
        paddingTop: 8,
        paddingBottom: "calc(10px + env(safe-area-inset-bottom, 10px))",
        paddingLeft: 8,
        paddingRight: 8,
        display: "flex",
        justifyContent: "space-between",
        gap: 4,
      }}
    >
      {TABS.map((tab) => {
        const isActive = active === tab.key;
        const Icon = tab.icon;
        return (
          <button
            key={tab.key}
            onClick={() => onChange(tab.key)}
            style={{
              flex: 1,
              border: "none",
              background: "none",
              cursor: "pointer",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 4,
              padding: "6px 2px",
            }}
          >
            <div
              style={{
                width: 42,
                height: 28,
                borderRadius: 10,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: isActive ? t.blueSoft : "transparent",
                transition: "background 0.25s ease",
              }}
            >
              <Icon
                size={19}
                color={isActive ? t.blue : t.iconMuted}
                strokeWidth={isActive ? 2.2 : 1.8}
                style={{ transition: "color 0.2s ease" }}
              />
            </div>
            <span
              style={{
                fontSize: 10.5,
                fontWeight: isActive ? 700 : 500,
                color: isActive ? t.blue : t.textSecondary,
                letterSpacing: "-0.01em",
                transition: "color 0.2s ease",
              }}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------------
   ONBOARDING
   Shown once at launch, always in the light theme regardless of
   the app's own theme setting. Slide 1 content is per spec; slides
   2–4 are placeholders covering the app's other core features —
   worth refining once their exact copy is decided.
----------------------------------------------------------------*/
const ONBOARDING_SLIDES = [
  {
    hero: "track",
    titleLines: [
      { text: "Track IPOs", color: "navy" },
      { text: "Easily", color: "blue" },
    ],
    description:
      "Stay updated with upcoming, open, closed and listed IPOs, all in one simple place.",
  },
  {
    hero: "gmp",
    titleLines: [
      { text: "GMP &", color: "navy" },
      { text: "Subscription", color: "navy" },
      { text: "Updates", color: "blue" },
    ],
    description:
      "Check GMP, QIB, NII and Retail subscription data with the latest updates for ongoing IPOs.",
  },
  {
    hero: "dates",
    titleLines: [
      { text: "Never Miss", color: "navy" },
      { text: "an IPO Date", color: "blue" },
    ],
    description:
      "Keep track of IPO opening, closing, allotment, refund and listing dates in one place.",
  },
  {
    hero: "updates",
    titleLines: [
      { text: "Stay ", color: "navy", inline: true },
      { text: "Updated", color: "blue", inline: true },
    ],
    description:
      "Get important IPO news, subscription updates and allotment alerts when they matter.",
  },
  {
    hero: "disclaimer",
    title: "Important Disclaimer",
    disclaimerParagraphs: [
      "IPO BAZAAR provides IPO-related information for educational and informational purposes only. GMP and other market-related information may be unofficial, indicative, delayed or subject to change. Information displayed in the app should not be considered investment advice or a guarantee of returns.",
      "Please verify important information through official sources before making any financial decision.",
    ],
  },
];

function OnboardingHeroTrack() {
  const bars = [30, 48, 70, 96];
  const candles = [
    { height: 34, top: 18 },
    { height: 46, top: 6 },
    { height: 40, top: 40 },
  ];

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: 300,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* big soft glow circle */}
      <div
        style={{
          position: "absolute",
          width: 290,
          height: 290,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(46,124,255,0.16) 0%, rgba(46,124,255,0.06) 60%, transparent 78%)",
        }}
      />

      {/* small floating dot, top-left of the glow */}
      <div
        style={{
          position: "absolute",
          top: 16,
          left: 22,
          width: 14,
          height: 14,
          borderRadius: "50%",
          background: "#4C86FF",
        }}
      />

      {/* candlesticks, left side */}
      <div
        style={{
          position: "absolute",
          left: 8,
          top: "50%",
          transform: "translateY(-50%)",
          display: "flex",
          alignItems: "flex-end",
          gap: 8,
          opacity: 0.55,
        }}
      >
        {candles.map((c, i) => (
          <div
            key={i}
            style={{
              position: "relative",
              width: 12,
              height: c.height,
              marginTop: c.top,
              borderRadius: 3,
              background: "#8FB4FF",
            }}
          >
            <div
              style={{
                position: "absolute",
                top: -8,
                left: "50%",
                transform: "translateX(-50%)",
                width: 2,
                height: c.height + 16,
                background: "#8FB4FF",
              }}
            />
          </div>
        ))}
      </div>

      {/* document card */}
      <div
        style={{
          position: "relative",
          width: 148,
          height: 172,
          borderRadius: 18,
          background: "#FFFFFF",
          boxShadow: "0 20px 40px rgba(14, 20, 32, 0.14)",
          padding: "16px 14px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 9,
        }}
      >
        <span
          style={{
            fontSize: 17,
            fontWeight: 800,
            color: "#0B3B8C",
            lineHeight: 1.15,
            textAlign: "center",
          }}
        >
          IPO
          <br />
          BAZAAR
        </span>
        <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 6, marginTop: 2 }}>
          <div style={{ width: "100%", height: 6, borderRadius: 3, background: "#DCE7FF" }} />
          <div style={{ width: "75%", height: 6, borderRadius: 3, background: "#E7EEFF" }} />
          <div style={{ width: "55%", height: 6, borderRadius: 3, background: "#EEF2FF" }} />
        </div>

        {/* bar chart, bottom-right of the card, overlapping the edge */}
        <div
          style={{
            position: "absolute",
            right: -18,
            bottom: -14,
            display: "flex",
            alignItems: "flex-end",
            gap: 5,
          }}
        >
          {bars.map((h, i) => (
            <div
              key={i}
              style={{
                width: 15,
                height: h,
                borderRadius: 4,
                background: "linear-gradient(180deg, #4C8DFF 0%, #1653D6 100%)",
                boxShadow: "0 6px 14px rgba(22, 83, 214, 0.35)",
              }}
            />
          ))}
        </div>
      </div>

      {/* growth badge, overlapping bottom-right of the whole cluster */}
      <div
        style={{
          position: "absolute",
          right: "18%",
          bottom: "4%",
          width: 62,
          height: 62,
          borderRadius: "50%",
          background: "linear-gradient(155deg, #4C8DFF 0%, #1653D6 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 14px 28px rgba(22, 83, 214, 0.4)",
        }}
      >
        <TrendingUp size={26} color="#FFFFFF" strokeWidth={2.4} />
      </div>
    </div>
  );
}

function OnboardingHeroGmp() {
  const stats = [
    { label: "QIB", value: "12.4x" },
    { label: "NII", value: "8.6x" },
    { label: "Retail", value: "6.3x" },
  ];
  const bars = [40, 64, 88, 108];

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: 300,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* big soft glow circle */}
      <div
        style={{
          position: "absolute",
          width: 290,
          height: 290,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(46,124,255,0.16) 0%, rgba(46,124,255,0.06) 60%, transparent 78%)",
        }}
      />

      {/* decorative floating rings */}
      <div
        style={{
          position: "absolute",
          top: 8,
          left: 18,
          width: 16,
          height: 16,
          borderRadius: "50%",
          border: "3px solid #C7D9FF",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: 30,
          left: 30,
          width: 12,
          height: 12,
          borderRadius: "50%",
          border: "3px solid #C7D9FF",
        }}
      />

      {/* bar chart card, back-left */}
      <div
        style={{
          position: "absolute",
          left: "6%",
          top: "26%",
          width: 118,
          height: 148,
          borderRadius: 16,
          background: "#FFFFFF",
          boxShadow: "0 16px 34px rgba(14, 20, 32, 0.12)",
          display: "flex",
          alignItems: "flex-end",
          justifyContent: "center",
          gap: 6,
          padding: "0 12px 14px",
        }}
      >
        {bars.map((h, i) => (
          <div
            key={i}
            style={{
              width: 15,
              height: h * 0.72,
              borderRadius: 4,
              background: "linear-gradient(180deg, #6FA6FF 0%, #2E7CFF 100%)",
            }}
          />
        ))}
      </div>

      {/* GMP pill badge, overlapping top of the bar chart */}
      <div
        style={{
          position: "absolute",
          left: "8%",
          top: "16%",
          padding: "9px 20px",
          borderRadius: 999,
          background: "linear-gradient(135deg, #4C8DFF 0%, #1653D6 100%)",
          boxShadow: "0 10px 22px rgba(22, 83, 214, 0.4)",
        }}
      >
        <span style={{ fontSize: 15, fontWeight: 800, color: "#FFFFFF" }}>GMP</span>
      </div>

      {/* subscription stats card, front-right */}
      <div
        style={{
          position: "absolute",
          right: "6%",
          top: "20%",
          width: 168,
          borderRadius: 18,
          background: "#FFFFFF",
          boxShadow: "0 20px 40px rgba(14, 20, 32, 0.16)",
          padding: "16px 16px",
          display: "flex",
          flexDirection: "column",
          gap: 10,
        }}
      >
        {stats.map((s) => (
          <div key={s.label} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: "#5A6478" }}>{s.label}</span>
            <span style={{ fontSize: 17, fontWeight: 800, color: "#0B3B8C" }}>{s.value}</span>
          </div>
        ))}
        <div style={{ height: 1, background: "#E7ECF3" }} />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#5A6478" }}>Overall</span>
          <span style={{ fontSize: 18, fontWeight: 800, color: "#2E7CFF" }}>9.8x</span>
        </div>
      </div>
    </div>
  );
}

function OnboardingHeroDates() {
  const items = ["Open", "Close", "Allotment", "Refund", "Listing"];

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: 300,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* big soft glow circle */}
      <div
        style={{
          position: "absolute",
          width: 290,
          height: 290,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(46,124,255,0.16) 0%, rgba(46,124,255,0.06) 60%, transparent 78%)",
        }}
      />

      {/* small floating dot */}
      <div
        style={{
          position: "absolute",
          top: 14,
          left: 24,
          width: 14,
          height: 14,
          borderRadius: "50%",
          background: "#4C86FF",
        }}
      />

      {/* calendar card, back-left */}
      <div
        style={{
          position: "absolute",
          left: "2%",
          top: "22%",
          width: 128,
          borderRadius: 16,
          background: "#FFFFFF",
          boxShadow: "0 16px 34px rgba(14, 20, 32, 0.14)",
          overflow: "hidden",
        }}
      >
        <div style={{ position: "relative", height: 34, background: "#2E7CFF" }}>
          {[38, 76].map((left) => (
            <div
              key={left}
              style={{
                position: "absolute",
                top: -6,
                left,
                width: 12,
                height: 20,
                borderRadius: 6,
                background: "#1653D6",
              }}
            />
          ))}
        </div>
        <div style={{ padding: "14px 14px 16px", display: "flex", flexDirection: "column", gap: 8 }}>
          <span style={{ fontSize: 18, fontWeight: 800, color: "#0B3B8C" }}>IPO</span>
          <div style={{ width: "80%", height: 6, borderRadius: 3, background: "#DCE7FF" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 2 }}>
            <div
              style={{
                width: 14,
                height: 14,
                borderRadius: 4,
                background: "#2E7CFF",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <Check size={9} color="#FFFFFF" strokeWidth={3.2} />
            </div>
            <div style={{ width: "55%", height: 6, borderRadius: 3, background: "#E7EEFF" }} />
          </div>
        </div>
      </div>

      {/* clock, overlapping bottom of the calendar */}
      <div
        style={{
          position: "absolute",
          left: "18%",
          bottom: "10%",
          width: 46,
          height: 46,
          borderRadius: "50%",
          background: "#FFFFFF",
          border: "4px solid #2E7CFF",
          boxShadow: "0 10px 20px rgba(14, 20, 32, 0.18)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ position: "relative", width: 16, height: 16 }}>
          <div
            style={{
              position: "absolute",
              left: "50%",
              bottom: "50%",
              width: 2,
              height: 7,
              background: "#2E7CFF",
              transformOrigin: "bottom",
              transform: "translateX(-50%) rotate(-25deg)",
            }}
          />
          <div
            style={{
              position: "absolute",
              left: "50%",
              bottom: "50%",
              width: 2,
              height: 5,
              background: "#2E7CFF",
              transformOrigin: "bottom",
              transform: "translateX(-50%) rotate(60deg)",
            }}
          />
        </div>
      </div>

      {/* checklist card, front-right */}
      <div
        style={{
          position: "absolute",
          right: "4%",
          top: "12%",
          width: 168,
          borderRadius: 18,
          background: "#FFFFFF",
          boxShadow: "0 20px 40px rgba(14, 20, 32, 0.16)",
          padding: "14px 16px",
          display: "flex",
          flexDirection: "column",
          gap: 11,
        }}
      >
        {items.map((label) => (
          <div key={label} style={{ display: "flex", alignItems: "center", gap: 9 }}>
            <div
              style={{
                width: 20,
                height: 20,
                borderRadius: 6,
                background: "#2E7CFF",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <Check size={12} color="#FFFFFF" strokeWidth={3} />
            </div>
            <span style={{ fontSize: 13.5, fontWeight: 700, color: "#0B3B8C" }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function OnboardingHeroUpdates() {
  const features = [
    { icon: FileText, label: "IPO News" },
    { icon: BarChart2, label: "Subscription Updates" },
    { icon: Bell, label: "Allotment Alerts" },
  ];

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: 300,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {/* big soft glow circle */}
      <div
        style={{
          position: "absolute",
          width: 290,
          height: 290,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(46,124,255,0.16) 0%, rgba(46,124,255,0.06) 60%, transparent 78%)",
        }}
      />

      {/* decorative candlesticks, bottom-left */}
      <div
        style={{
          position: "absolute",
          left: 10,
          bottom: 46,
          display: "flex",
          alignItems: "flex-end",
          gap: 6,
          opacity: 0.5,
        }}
      >
        {[26, 34].map((h, i) => (
          <div key={i} style={{ width: 10, height: h, borderRadius: 3, background: "#8FB4FF" }} />
        ))}
      </div>

      {/* speech-bubble chart icon, top-left */}
      <div
        style={{
          position: "absolute",
          top: 6,
          left: 14,
          width: 44,
          height: 44,
          borderRadius: "50% 50% 50% 6px",
          background: "#C7D9FF",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <TrendingUp size={18} color="#FFFFFF" strokeWidth={2.4} />
      </div>

      {/* document card, back */}
      <div
        style={{
          position: "absolute",
          left: "10%",
          top: "16%",
          width: 138,
          borderRadius: 16,
          background: "#FFFFFF",
          boxShadow: "0 16px 34px rgba(14, 20, 32, 0.14)",
          padding: "14px 14px",
          display: "flex",
          flexDirection: "column",
          gap: 8,
        }}
      >
        <span style={{ fontSize: 16, fontWeight: 800, color: "#0B3B8C", lineHeight: 1.15 }}>
          IPO
          <br />
          <span style={{ color: "#2E7CFF" }}>BAZAAR</span>
        </span>
        <div style={{ width: "100%", height: 5, borderRadius: 3, background: "#DCE7FF" }} />
        <div style={{ width: "75%", height: 5, borderRadius: 3, background: "#E7EEFF" }} />
        <div style={{ width: "55%", height: 5, borderRadius: 3, background: "#EEF2FF" }} />
      </div>

      {/* bell with unread badge, overlapping top-right of the document */}
      <div
        style={{
          position: "absolute",
          right: "10%",
          top: "18%",
          width: 62,
          height: 62,
          borderRadius: "50%",
          background: "linear-gradient(155deg, #4C8DFF 0%, #1653D6 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 14px 28px rgba(22, 83, 214, 0.4)",
        }}
      >
        <Bell size={26} color="#FFFFFF" strokeWidth={2} />
        <span
          style={{
            position: "absolute",
            top: -3,
            right: -3,
            width: 20,
            height: 20,
            borderRadius: "50%",
            background: cardColors.red,
            color: "#FFFFFF",
            fontSize: 11,
            fontWeight: 800,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            border: "2px solid #FFFFFF",
          }}
        >
          1
        </span>
      </div>

      {/* feature list card, front, overlapping both */}
      <div
        style={{
          position: "absolute",
          left: "12%",
          bottom: "0%",
          width: 210,
          borderRadius: 18,
          background: "#FFFFFF",
          boxShadow: "0 20px 40px rgba(14, 20, 32, 0.16)",
          padding: "14px 16px",
          display: "flex",
          flexDirection: "column",
          gap: 12,
        }}
      >
        {features.map((f) => (
          <div key={f.label} style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div
              style={{
                width: 26,
                height: 26,
                borderRadius: 8,
                background: "#2E7CFF",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <f.icon size={13} color="#FFFFFF" strokeWidth={2.2} />
            </div>
            <span style={{ fontSize: 13, fontWeight: 700, color: "#0B3B8C" }}>{f.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function OnboardingScreen({ onFinish }) {
  const t = themes.light;
  const [index, setIndex] = useState(0);
  const [disclaimerChecked, setDisclaimerChecked] = useState(false);
  const slide = ONBOARDING_SLIDES[index];
  const isLast = index === ONBOARDING_SLIDES.length - 1;
  const isHero = !!slide.hero;
  const isDisclaimer = slide.hero === "disclaimer";

  const handleNext = () => {
    if (isDisclaimer && !disclaimerChecked) return;
    if (isLast) {
      onFinish();
    } else {
      setIndex((i) => i + 1);
    }
  };

  return (
    <div
      style={{
        width: "100%",
        height: "100vh",
        minHeight: 560,
        maxWidth: 480,
        margin: "0 auto",
        background: isHero
          ? "linear-gradient(180deg, #F2F6FF 0%, #FFFFFF 45%)"
          : t.bg,
        display: "flex",
        flexDirection: "column",
        fontFamily:
          '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
      }}
    >
      {isDisclaimer ? (
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            padding: "40px 24px 0",
            gap: 20,
          }}
        >
          <div
            style={{
              width: 128,
              height: 128,
              borderRadius: "50%",
              background: cardColors.blueSoft,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <div
              style={{
                width: 84,
                height: 84,
                borderRadius: "50%",
                background: "linear-gradient(155deg, #4C8DFF 0%, #1653D6 100%)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "0 16px 32px rgba(22, 83, 214, 0.4)",
              }}
            >
              <Shield size={38} color="#FFFFFF" strokeWidth={1.8} fill="none" />
            </div>
          </div>

          <span
            style={{
              fontSize: 24,
              fontWeight: 800,
              color: t.headBlue,
              textAlign: "center",
              letterSpacing: "-0.01em",
            }}
          >
            {slide.title}
          </span>

          <div
            style={{
              width: "100%",
              background: t.surface,
              border: `1px solid ${t.border}`,
              borderRadius: 18,
              padding: 18,
              display: "flex",
              flexDirection: "column",
              gap: 14,
              boxSizing: "border-box",
            }}
          >
            <p style={{ margin: 0, fontSize: 14, lineHeight: 1.6, color: t.headBlue }}>
              {slide.disclaimerParagraphs[0]}
            </p>
            <div style={{ height: 1, background: t.border }} />
            <p style={{ margin: 0, fontSize: 14, lineHeight: 1.6, color: t.headBlue }}>
              {slide.disclaimerParagraphs[1]}
            </p>
          </div>

          <button
            onClick={() => setDisclaimerChecked((v) => !v)}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              gap: 12,
              background: "none",
              border: "none",
              padding: 0,
              cursor: "pointer",
              textAlign: "left",
            }}
          >
            <div
              style={{
                width: 30,
                height: 30,
                borderRadius: 9,
                background: disclaimerChecked ? t.blue : t.bg,
                border: disclaimerChecked ? "none" : `1.5px solid ${t.border}`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
                transition: "background 0.15s ease, border-color 0.15s ease",
              }}
            >
              {disclaimerChecked && <Check size={18} color="#FFFFFF" strokeWidth={3} />}
            </div>
            <span style={{ fontSize: 13.5, fontWeight: 600, color: t.headBlue, lineHeight: 1.4 }}>
              I have read and understood the disclaimer
            </span>
          </button>
        </div>
      ) : isHero ? (
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            padding: "0 32px",
            gap: 20,
          }}
        >
          {slide.hero === "gmp" ? (
            <OnboardingHeroGmp />
          ) : slide.hero === "dates" ? (
            <OnboardingHeroDates />
          ) : slide.hero === "updates" ? (
            <OnboardingHeroUpdates />
          ) : (
            <OnboardingHeroTrack />
          )}

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <span
              style={{
                fontSize: 34,
                fontWeight: 800,
                lineHeight: 1.15,
                letterSpacing: "-0.01em",
              }}
            >
              {slide.titleLines.map((line, i) => (
                <span key={i}>
                  <span style={{ color: line.color === "blue" ? t.blue : t.headBlue }}>
                    {line.text}
                  </span>
                  {i < slide.titleLines.length - 1 && !line.inline && <br />}
                </span>
              ))}
            </span>
            <span style={{ fontSize: 16, color: t.textSecondary, lineHeight: 1.6 }}>
              {slide.description}
            </span>
          </div>
        </div>
      ) : (
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            padding: "0 36px",
            gap: 24,
          }}
        >
          <div
            style={{
              width: 108,
              height: 108,
              borderRadius: "50%",
              background: cardColors.blueSoft,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <slide.icon size={46} color={t.blue} strokeWidth={1.8} />
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <span
              style={{
                fontSize: 23,
                fontWeight: 800,
                color: t.headBlue,
                letterSpacing: "-0.01em",
              }}
            >
              {slide.title}
            </span>
            <span style={{ fontSize: 14.5, color: t.textSecondary, lineHeight: 1.55 }}>
              {slide.description}
            </span>
          </div>
        </div>
      )}

      {isDisclaimer ? (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 18,
            padding: "18px 24px 32px",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            {ONBOARDING_SLIDES.map((_, i) => (
              <div
                key={i}
                style={{
                  width: i === index ? 12 : 8,
                  height: i === index ? 12 : 8,
                  borderRadius: "50%",
                  background: i === index ? t.blue : "#D7E0F5",
                }}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            disabled={!disclaimerChecked}
            className="ipo-card-btn"
            style={{
              width: "100%",
              height: 52,
              border: "none",
              borderRadius: 26,
              background: disclaimerChecked ? t.blue : cardColors.blueSoft,
              color: disclaimerChecked ? "#FFFFFF" : t.blue,
              fontSize: 15,
              fontWeight: 800,
              cursor: disclaimerChecked ? "pointer" : "default",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
            }}
          >
            Continue
            <ArrowRight size={18} strokeWidth={2.6} />
          </button>
        </div>
      ) : (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 28px 36px",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            {ONBOARDING_SLIDES.map((_, i) => (
              <div
                key={i}
                style={{
                  width: i === index ? 12 : 8,
                  height: i === index ? 12 : 8,
                  borderRadius: "50%",
                  background: i === index ? t.blue : "#D7E0F5",
                  transition: "width 0.2s ease, height 0.2s ease, background 0.2s ease",
                }}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            aria-label="Next"
            className="ipo-card-btn"
            style={{
              width: 52,
              height: 52,
              borderRadius: "50%",
              border: "none",
              background: "#2E7CFF",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              boxShadow: isHero
                ? "0 10px 26px rgba(46, 124, 255, 0.55)"
                : `0 8px 18px ${cardColors.blueSoft}`,
            }}
          >
            <ArrowRight size={20} color="#FFFFFF" strokeWidth={2.6} />
          </button>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------
   MAIN APP
----------------------------------------------------------------*/
function App() {
  const [theme, setTheme] = useState("light");
  const [activeTab, setActiveTab] = useState("home");
  const [homeFilter, setHomeFilter] = useState("open");
  const [watchlist, setWatchlist] = useState({});
  const [subTab, setSubTab] = useState("open");
  const [subDetailId, setSubDetailId] = useState(null);
  const [homeDetailId, setHomeDetailId] = useState(null);
  const [allotTab, setAllotTab] = useState("available");
  const [allotDetailId, setAllotDetailId] = useState(null);
  const [allotmentStatus, setAllotmentStatus] = useState({});
  // Single shared selection — only one card/item can be highlighted
  // across the whole app at a time, no matter which tab it's on.
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [showHomeSearch, setShowHomeSearch] = useState(false);
  const [homeSearchQuery, setHomeSearchQuery] = useState("");
  const [showNotificationsScreen, setShowNotificationsScreen] = useState(false);
  const [notificationsOpened, setNotificationsOpened] = useState(false);
  const t = themes[theme];

  const activeMeta = TABS.find((tab) => tab.key === activeTab);

  const counts = STATUS_TABS.reduce((acc, tab) => {
    acc[tab.key] = IPO_DATA.filter((ipo) => ipo.status === tab.key).length;
    return acc;
  }, {});

  const trimmedQuery = homeSearchQuery.trim().toLowerCase();
  const filteredIPOs = trimmedQuery
    ? IPO_DATA.filter((ipo) => ipo.companyName.toLowerCase().includes(trimmedQuery))
    : IPO_DATA.filter((ipo) => ipo.status === homeFilter);

  const homeDetailIPO = homeDetailId
    ? { ...IPO_DATA.find((ipo) => ipo.id === homeDetailId), ...(IPO_DETAILS[homeDetailId] || {}) }
    : null;

  const toggleWatchlist = (id) => {
    setWatchlist((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleTabChange = (key) => {
    setActiveTab(key);
    setShowHomeSearch(false);
    setHomeSearchQuery("");
  };

  const filteredSubs =
    activeTab === "subscription" && trimmedQuery
      ? SUBSCRIPTION_DATA.filter((ipo) => ipo.companyName.toLowerCase().includes(trimmedQuery))
      : SUBSCRIPTION_DATA.filter((ipo) => ipo.status === subTab);
  const subDetailIPO = SUBSCRIPTION_DATA.find((ipo) => ipo.id === subDetailId);

  const subCounts = SUB_TABS.reduce((acc, tab) => {
    acc[tab.key] = SUBSCRIPTION_DATA.filter((ipo) => ipo.status === tab.key).length;
    return acc;
  }, {});

  const openSubDetail = (id) => {
    setSubDetailId(id);
  };

  const filteredAllotments =
    activeTab === "allotment" && trimmedQuery
      ? ALLOTMENT_DATA.filter((item) => item.companyName.toLowerCase().includes(trimmedQuery))
      : ALLOTMENT_DATA.filter((item) => item.status === allotTab);
  const allotDetailItem = ALLOTMENT_DATA.find((item) => item.id === allotDetailId);

  const allotCounts = ALLOT_TABS.reduce((acc, tab) => {
    acc[tab.key] = ALLOTMENT_DATA.filter((item) => item.status === tab.key).length;
    return acc;
  }, {});

  // Per-tab header configuration — Home, Allotment, and Subscription
  // get extra icons/subtitle; other screens keep the plain title.
  const unreadCount = notificationsOpened ? 0 : NOTIFICATIONS.length;
  const handleBellClick = () => {
    setShowNotificationsScreen(true);
    setNotificationsOpened(true);
  };
  // Search now opens in place on whichever tab the user is currently
  // viewing — it never switches the active tab to Home.
  const toggleSearch = () => setShowHomeSearch((v) => !v);

  let headerProps = { title: activeMeta.label };
  if (activeTab === "home") {
    headerProps = {
      showWordmark: true,
      subtitle: "Track IPO opportunities",
      showSearch: true,
      showBell: true,
      unreadCount,
      onSearchClick: toggleSearch,
      onBellClick: handleBellClick,
    };
  } else if (activeTab === "allotment") {
    headerProps = {
      title: "IPO Allotment",
      subtitle: "Track and check your IPO allotment status.",
      showSearch: true,
      showBell: true,
      unreadCount,
      onSearchClick: toggleSearch,
      onBellClick: handleBellClick,
    };
  } else if (activeTab === "subscription") {
    headerProps = {
      title: "IPO Subscription",
      subtitle: "Track IPO subscription",
      showSearch: true,
      showBell: true,
      unreadCount,
      onSearchClick: toggleSearch,
      onBellClick: handleBellClick,
    };
  } else if (activeTab === "calendar") {
    headerProps = {
      title: "IPO Calendar",
      subtitle: "All upcoming IPO events at a glance",
      showSearch: false,
      showBell: true,
      unreadCount,
      onBellClick: handleBellClick,
    };
  }

  return (
    <div
      style={{
        width: "100%",
        height: "100vh",
        minHeight: 560,
        maxWidth: 480,
        margin: "0 auto",
        background: t.bg,
        display: "flex",
        flexDirection: "column",
        position: "relative",
        fontFamily:
          '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
        transition: "background 0.3s ease",
        overflow: "hidden",
      }}
    >
      <style>{`
        @keyframes screenFadeIn {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes ipoSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        * {
          box-sizing: border-box;
          transition: background-color 0.25s ease, border-color 0.25s ease, color 0.25s ease, box-shadow 0.25s ease;
        }
        .ipo-card-btn {
          transition: transform 0.12s ease, opacity 0.12s ease, background-color 0.25s ease, border-color 0.25s ease, color 0.25s ease, box-shadow 0.25s ease;
        }
        .ipo-card-btn:active { transform: scale(0.96); opacity: 0.9; }
      `}</style>

      {!showNotificationsScreen && (
        <Header t={t} {...headerProps} />
      )}

      <Screen activeKey={activeTab}>
        {showNotificationsScreen ? (
          <NotificationsScreen
            t={t}
            notifications={NOTIFICATIONS}
            onBack={() => setShowNotificationsScreen(false)}
          />
        ) : activeTab === "home" ? (
          <div
            style={{
              flex: 1,
              minHeight: 0,
              display: "flex",
              flexDirection: "column",
              background: t.bg,
            }}
          >
            {homeDetailIPO ? (
              <IPODetailScreen
                t={t}
                ipo={homeDetailIPO}
                onBack={() => setHomeDetailId(null)}
              />
            ) : (
              <>
                {showHomeSearch ? (
                  <HomeSearchBar
                    t={t}
                    value={homeSearchQuery}
                    onChange={setHomeSearchQuery}
                    onClose={() => {
                      setShowHomeSearch(false);
                      setHomeSearchQuery("");
                    }}
                  />
                ) : (
                  <FilterTabs
                    t={t}
                    active={homeFilter}
                    onChange={setHomeFilter}
                    counts={counts}
                  />
                )}

                <div
                  style={{
                    flex: 1,
                    overflowY: "auto",
                    padding: "14px 16px 24px",
                    display: "flex",
                    flexDirection: "column",
                    gap: 14,
                  }}
                >
                  {filteredIPOs.length === 0 ? (
                    trimmedQuery ? (
                      <IPOEmptyState t={t} label={`No results for "${homeSearchQuery.trim()}"`} />
                    ) : (
                      <IPOEmptyState t={t} status={homeFilter} />
                    )
                  ) : (
                    filteredIPOs.map((ipo) => (
                      <IPOCard
                        key={ipo.id}
                        t={t}
                        {...ipo}
                        isSaved={!!watchlist[ipo.id]}
                        isSelected={selectedItemId === ipo.id}
                        onSelect={() =>
                          setSelectedItemId((prev) => (prev === ipo.id ? null : ipo.id))
                        }
                        onToggleWatchlist={() => toggleWatchlist(ipo.id)}
                        onView={() => setHomeDetailId(ipo.id)}
                      />
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        ) : activeTab === "subscription" ? (
          <div
            style={{
              flex: 1,
              minHeight: 0,
              display: "flex",
              flexDirection: "column",
              background: t.bg,
            }}
          >
            {subDetailIPO ? (
              <SubscriptionDetails
                t={t}
                ipo={subDetailIPO}
                onBack={() => setSubDetailId(null)}
              />
            ) : (
              <>
                {showHomeSearch ? (
                  <HomeSearchBar
                    t={t}
                    value={homeSearchQuery}
                    onChange={setHomeSearchQuery}
                    onClose={() => {
                      setShowHomeSearch(false);
                      setHomeSearchQuery("");
                    }}
                  />
                ) : (
                  <SubTabs
                    t={t}
                    active={subTab}
                    onChange={setSubTab}
                    counts={subCounts}
                  />
                )}
                <div
                  style={{
                    flex: 1,
                    overflowY: "auto",
                    padding: "14px 16px 24px",
                    display: "flex",
                    flexDirection: "column",
                    gap: 14,
                  }}
                >
                  {filteredSubs.length === 0 ? (
                    <IPOEmptyState
                      t={t}
                      label={
                        trimmedQuery
                          ? `No results for "${homeSearchQuery.trim()}"`
                          : SUB_TABS.find((tab) => tab.key === subTab)?.label
                      }
                    />
                  ) : (
                    filteredSubs.map((ipo) => (
                      <SubscriptionCard
                        key={ipo.id}
                        t={t}
                        ipo={ipo}
                        isSelected={selectedItemId === ipo.id}
                        onSelect={() =>
                          setSelectedItemId((prev) => (prev === ipo.id ? null : ipo.id))
                        }
                        onOpen={() => openSubDetail(ipo.id)}
                      />
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        ) : activeTab === "allotment" ? (
          <div
            style={{
              flex: 1,
              minHeight: 0,
              display: "flex",
              flexDirection: "column",
              background: t.bg,
            }}
          >
            {allotDetailItem ? (
              <AllotmentDetailScreen
                t={t}
                item={allotDetailItem}
                onBack={() => setAllotDetailId(null)}
                savedStatus={allotmentStatus[allotDetailItem.id] || null}
                onSaveStatus={(status) =>
                  setAllotmentStatus((prev) => ({ ...prev, [allotDetailItem.id]: status }))
                }
              />
            ) : (
              <>
                {showHomeSearch ? (
                  <HomeSearchBar
                    t={t}
                    value={homeSearchQuery}
                    onChange={setHomeSearchQuery}
                    onClose={() => {
                      setShowHomeSearch(false);
                      setHomeSearchQuery("");
                    }}
                  />
                ) : (
                  <AllotmentTabs
                    t={t}
                    active={allotTab}
                    onChange={setAllotTab}
                    counts={allotCounts}
                  />
                )}
                <div
                  style={{
                    flex: 1,
                    overflowY: "auto",
                    padding: "14px 16px 24px",
                    display: "flex",
                    flexDirection: "column",
                    gap: 14,
                  }}
                >
                  {filteredAllotments.length === 0 ? (
                    <IPOEmptyState
                      t={t}
                      label={
                        trimmedQuery
                          ? `No results for "${homeSearchQuery.trim()}"`
                          : ALLOT_TABS.find((tab) => tab.key === allotTab)?.label
                      }
                    />
                  ) : (
                    filteredAllotments.map((item) => (
                      <AllotmentCard
                        key={item.id}
                        t={t}
                        item={item}
                        isSelected={selectedItemId === item.id}
                        onSelect={() =>
                          setSelectedItemId((prev) => (prev === item.id ? null : item.id))
                        }
                        resultStatus={allotmentStatus[item.id] || null}
                        onOpen={() => setAllotDetailId(item.id)}
                      />
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        ) : activeTab === "calendar" ? (
          <CalendarScreen
            t={t}
            onOpenIPO={(id) => {
              setActiveTab("home");
              setHomeDetailId(id);
            }}
          />
        ) : activeTab === "settings" ? (
          <SettingsScreen
            t={t}
            theme={theme}
            onToggleTheme={() => setTheme(theme === "light" ? "dark" : "light")}
            watchlist={watchlist}
            onToggleWatchlist={toggleWatchlist}
          />
        ) : (
          <EmptyState t={t} icon={activeMeta.icon} />
        )}
      </Screen>

      <BottomNav t={t} active={activeTab} onChange={handleTabChange} />
    </div>
  );
}

/* ---------------------------------------------------------------
   SPLASH SCREEN
   The very first thing shown on every app open — logo, wordmark,
   tagline, and a progress bar that fills over ~2.7s before handing
   off to onboarding (first run) or straight into the app.
----------------------------------------------------------------*/
function IPOBazaarSplashLogo({ size = 176 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 240 240" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="ipoLogoBg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3E76F2" />
          <stop offset="55%" stopColor="#123B9C" />
          <stop offset="100%" stopColor="#081A48" />
        </linearGradient>
        <linearGradient id="ipoLogoUnderline" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#22CE83" />
          <stop offset="100%" stopColor="#7CF2B0" />
        </linearGradient>
      </defs>
      <rect x="0" y="0" width="240" height="240" rx="54" fill="url(#ipoLogoBg)" />
      <text x="26" y="118" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="66" fill="#FFFFFF">
        IPO
      </text>
      <text
        x="26"
        y="192"
        fontFamily="Arial, sans-serif"
        fontWeight="900"
        fontSize="44"
        letterSpacing="1"
        fill="#FFFFFF"
      >
        BAZAAR
      </text>
      <rect x="26" y="204" width="150" height="6" rx="3" fill="url(#ipoLogoUnderline)" />
      <polyline
        points="116,142 138,120 150,132 178,98"
        fill="none"
        stroke="#22CE83"
        strokeWidth="14"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <polygon points="178,98 157,101 176,117" fill="#22CE83" />
    </svg>
  );
}

function SplashScreen({ onFinish, duration = 2000 }) {
  const [filled, setFilled] = useState(false);

  useEffect(() => {
    // Start at 0% on mount, then flip to 100% on the next frame so the
    // browser has a 0%-width paint to transition *from* — otherwise the
    // fill would jump straight to full instead of animating.
    const raf = requestAnimationFrame(() => setFilled(true));
    const timer = window.setTimeout(() => onFinish(), duration);
    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(timer);
    };
  }, [duration, onFinish]);

  return (
    <div
      style={{
        width: "100%",
        height: "100vh",
        minHeight: 560,
        maxWidth: 480,
        margin: "0 auto",
        position: "relative",
        overflow: "hidden",
        background: "linear-gradient(180deg, #EAF1FF 0%, #F7FAFF 55%, #FFFFFF 100%)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        fontFamily:
          '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
      }}
    >
      {/* soft glow circles behind the logo */}
      <div
        style={{
          position: "absolute",
          width: 460,
          height: 460,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(46,124,255,0.14) 0%, rgba(46,124,255,0) 70%)",
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 300,
          height: 300,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(46,124,255,0.12) 0%, rgba(46,124,255,0) 70%)",
        }}
      />

      {/* decorative candlesticks, left */}
      <div
        style={{
          position: "absolute",
          left: 22,
          top: "27%",
          display: "flex",
          alignItems: "flex-end",
          gap: 10,
        }}
      >
        <div style={{ width: 8, height: 64, borderRadius: 4, background: "rgba(46,124,255,0.30)" }} />
        <div
          style={{
            width: 8,
            height: 104,
            borderRadius: 4,
            background: "rgba(46,124,255,0.42)",
            marginBottom: 22,
          }}
        />
        <div style={{ width: 8, height: 80, borderRadius: 4, background: "rgba(46,124,255,0.30)" }} />
      </div>

      {/* decorative bar chart, right */}
      <div
        style={{
          position: "absolute",
          right: 22,
          top: "30%",
          display: "flex",
          alignItems: "flex-end",
          gap: 8,
        }}
      >
        <div style={{ width: 14, height: 36, borderRadius: 4, background: "rgba(46,124,255,0.22)" }} />
        <div style={{ width: 14, height: 64, borderRadius: 4, background: "rgba(46,124,255,0.32)" }} />
        <div style={{ width: 14, height: 100, borderRadius: 4, background: "rgba(46,124,255,0.42)" }} />
      </div>

      {/* logo + small trend badge */}
      <div style={{ position: "relative", width: 176, height: 176, marginBottom: 26 }}>
        <IPOBazaarSplashLogo size={176} />
        <div
          style={{
            position: "absolute",
            right: -14,
            bottom: 44,
            width: 52,
            height: 52,
            borderRadius: "50%",
            background: "rgba(46,124,255,0.22)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <TrendingUp size={24} color="#2E7CFF" strokeWidth={2.4} />
        </div>
      </div>

      <span style={{ fontSize: 24, fontWeight: 800, color: "#0B1440" }}>Welcome to</span>
      <span
        style={{
          fontSize: 32,
          fontWeight: 900,
          color: "#2E7CFF",
          letterSpacing: "0.02em",
          marginTop: 2,
        }}
      >
        IPO BAZAAR
      </span>
      <span
        style={{
          fontSize: 14.5,
          color: "#5B6478",
          textAlign: "center",
          lineHeight: 1.55,
          marginTop: 14,
          padding: "0 40px",
        }}
      >
        Your trusted companion
        <br />
        for everything IPO
      </span>

      {/* animated progress bar */}
      <div style={{ position: "absolute", bottom: "9%", width: "62%", maxWidth: 300 }}>
        <div
          style={{
            width: "100%",
            height: 6,
            borderRadius: 3,
            background: "rgba(46,124,255,0.18)",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              height: "100%",
              width: filled ? "100%" : "0%",
              borderRadius: 3,
              background: "#2E7CFF",
              transition: `width ${duration - 100}ms cubic-bezier(0.4, 0, 0.2, 1)`,
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default function AppRoot() {
  // Splash shows every time the app opens — a fixed-length, fixed
  // animation, no state to persist. Onboarding should only ever show
  // once — the first time this app is opened on a device. Once
  // finished, we remember that in localStorage so reopening (or
  // refreshing) the app skips straight to the main App.
  const ONBOARDING_STORAGE_KEY = "ipoBazaarOnboardingComplete";

  const [showSplash, setShowSplash] = useState(true);

  const [showOnboarding, setShowOnboarding] = useState(() => {
    try {
      return window.localStorage.getItem(ONBOARDING_STORAGE_KEY) !== "true";
    } catch (e) {
      // localStorage unavailable — fall back to always showing it once
      // per session rather than crashing.
      return true;
    }
  });

  const finishOnboarding = () => {
    try {
      window.localStorage.setItem(ONBOARDING_STORAGE_KEY, "true");
    } catch (e) {
      /* storage unavailable — onboarding will just show again next time */
    }
    setShowOnboarding(false);
  };

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  if (showOnboarding) {
    return <OnboardingScreen onFinish={finishOnboarding} />;
  }

  return <App />;
}
